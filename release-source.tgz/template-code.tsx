type TemplateCategory = 'All' | 'SaaS' | 'Dashboards' | 'Marketing' | 'Tools' | 'Ecommerce' | 'Social';

interface Template {
  id: string;
  title: string;
  description: string;
  category: TemplateCategory;
  tags: string[];
}

const TEMPLATES: Template[] = [
  { id: 'saas-starter', title: 'SaaS Starter', description: 'A complete authentication and billing foundation with an empty dashboard view.', category: 'SaaS', tags: ['Auth', 'Billing', 'Dashboard'] },
  { id: 'marketing-launch', title: 'Launch Page', description: 'High-conversion landing page with waitlist capture and feature sections.', category: 'Marketing', tags: ['Waitlist', 'Hero', 'Conversion'] },
  { id: 'admin-dashboard', title: 'Admin Dashboard', description: 'Data-heavy table layouts and reporting charts for internal metrics.', category: 'Dashboards', tags: ['Tables', 'Charts', 'Analytics'] },
  { id: 'ecommerce-store', title: 'Storefront', description: 'Product grid, shopping cart context, and mock checkout flow.', category: 'Ecommerce', tags: ['Cart', 'Products', 'Checkout'] },
  { id: 'social-feed', title: 'Social Feed', description: 'Infinite scroll post lists with engagement actions and user profiles.', category: 'Social', tags: ['Feed', 'Profiles', 'Interactions'] },
  { id: 'internal-tool', title: 'Internal Tool', description: 'Form-heavy interface for managing database records and settings.', category: 'Tools', tags: ['Forms', 'Validation', 'Mutations'] },
  { id: 'saas-ai', title: 'AI Copywriter', description: 'Generative text interface with a conversational history sidebar.', category: 'SaaS', tags: ['AI', 'Streaming', 'History'] },
  { id: 'marketing-portfolio', title: 'Portfolio Showcase', description: 'Minimalist image-driven gallery for creative and design work.', category: 'Marketing', tags: ['Gallery', 'About', 'Contact'] },
  { id: 'dashboards-metrics', title: 'Metrics Tracker', description: 'KPI cards, trend lines, and data export panels.', category: 'Dashboards', tags: ['KPI', 'Trends', 'Export'] },
];

const TEMPLATE_CATEGORIES: TemplateCategory[] = ['All', 'SaaS', 'Dashboards', 'Marketing', 'Tools', 'Ecommerce', 'Social'];

function TemplatesCatalog({ onBackToBuild }: { onBackToBuild: () => void }) {
  const [searchQuery, setSearchQuery] = useState('');
  const [activeCategory, setActiveCategory] = useState<TemplateCategory>('All');
  const { toast } = useToast();

  const filteredTemplates = useMemo(() => {
    return TEMPLATES.filter((template) => {
      const matchesCategory = activeCategory === 'All' || template.category === activeCategory;
      const matchesSearch =
        template.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        template.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
        template.tags.some(tag => tag.toLowerCase().includes(searchQuery.toLowerCase()));
      return matchesCategory && matchesSearch;
    });
  }, [searchQuery, activeCategory]);

  const handleUseTemplate = (template: Template) => {
    toast({
      title: 'Template applied',
      description: `The workspace has been populated with the ${template.title} files.`,
    });
    onBackToBuild();
  };

  return (
    <div className="templates-catalog">
      <div className="templates-toolbar">
        <div className="templates-search">
          <Search size={15} className="templates-search-icon" />
          <input
            type="text"
            className="templates-search-input"
            placeholder="Search templates..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
        <div className="templates-filters">
          {TEMPLATE_CATEGORIES.map((cat) => (
            <button
              key={cat}
              className={`templates-filter-btn ${activeCategory === cat ? 'active' : ''}`}
              onClick={() => setActiveCategory(cat)}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {filteredTemplates.length > 0 ? (
        <div className="templates-grid">
          {filteredTemplates.map((template) => (
            <div className="template-card" key={template.id}>
              <div className="template-card-header">
                <h3 className="template-card-title">{template.title}</h3>
                <span className="template-card-category">{template.category}</span>
              </div>
              <p className="template-card-description">{template.description}</p>
              <div className="template-card-tags">
                {template.tags.map((tag) => (
                  <span className="template-card-tag" key={tag}>{tag}</span>
                ))}
              </div>
              <button 
                className="template-card-action mt-auto"
                onClick={() => handleUseTemplate(template)}
              >
                Use Template
              </button>
            </div>
          ))}
        </div>
      ) : (
        <div className="templates-empty">
          <PackageSearch size={32} className="templates-empty-icon" />
          <h3 className="templates-empty-title">No templates found</h3>
          <p className="templates-empty-desc">We couldn't find any templates matching "{searchQuery}". Try changing your filters.</p>
        </div>
      )}
    </div>
  );
}

function WorkspaceAreaPage({

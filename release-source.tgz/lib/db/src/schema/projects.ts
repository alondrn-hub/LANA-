import { sql } from "drizzle-orm";
import { jsonb, text, timestamp, pgTable } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const projectsTable = pgTable("projects", {
  userId: text("user_id").primaryKey(),
  name: text("name").notNull(),
  files: jsonb("files").notNull(),
  resources: jsonb("resources")
    .notNull()
    .default(sql`'{"revision":0,"templates":[],"routines":[],"library":[]}'::jsonb`)
    .$default(() => ({ revision: 0, templates: [], routines: [], library: [] })),
  updatedAt: timestamp("updated_at", { withTimezone: true })
    .notNull()
    .defaultNow()
    .$onUpdate(() => new Date()),
});

export const insertProjectSchema = createInsertSchema(projectsTable).omit({
  updatedAt: true,
});
export type InsertProject = z.infer<typeof insertProjectSchema>;
export type Project = typeof projectsTable.$inferSelect;
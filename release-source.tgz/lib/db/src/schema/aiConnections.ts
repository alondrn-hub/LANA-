import { primaryKey, text, timestamp, pgTable } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const aiConnectionsTable = pgTable(
  "ai_connections",
  {
    userId: text("user_id").notNull(),
    provider: text("provider").notNull(),
    encryptedApiKey: text("encrypted_api_key").notNull(),
    keyHint: text("key_hint").notNull(),
    state: text("state").notNull().default("connected"),
    lastTestedAt: timestamp("last_tested_at", { withTimezone: true }),
    error: text("error"),
    updatedAt: timestamp("updated_at", { withTimezone: true })
      .notNull()
      .defaultNow()
      .$onUpdate(() => new Date()),
  },
  (table) => ({
    userProviderPrimaryKey: primaryKey({ columns: [table.userId, table.provider] }),
  }),
);

export const insertAiConnectionSchema = createInsertSchema(aiConnectionsTable).omit({
  updatedAt: true,
});
export type InsertAiConnection = z.infer<typeof insertAiConnectionSchema>;
export type AiConnection = typeof aiConnectionsTable.$inferSelect;
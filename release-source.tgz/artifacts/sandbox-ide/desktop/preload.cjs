const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('lanaDesktop', {
  isDesktop: true,
  getRuntimeState: () => ipcRenderer.invoke('runtime:state'),
  retrySetup: () => ipcRenderer.invoke('runtime:retry'),
  openModelsFolder: () => ipcRenderer.invoke('runtime:models-folder'),
});
const assert = require('node:assert/strict');
const { mkdtemp, mkdir, readFile, rm, writeFile } = require('node:fs/promises');
const os = require('node:os');
const path = require('node:path');
const test = require('node:test');
const { createHash } = require('node:crypto');
const { readIntegrityModule, sealRuntimeManifest, verifyApprovedRuntime, verifyRuntime, verifySourceRuntime } = require('./release.cjs');

const digest = (value) => createHash('sha256').update(value).digest('hex');

async function fixture() {
  const runtime = await mkdtemp(path.join(os.tmpdir(), 'lana-release-test-'));
  await mkdir(path.join(runtime, 'models'));
  const files = {
    'llama-server.exe': 'unsigned launcher',
    'runtime-a.dll': 'runtime dependency',
    'models/Llama-3.2-3B-Instruct-Q4_K_M.gguf': 'approved model',
  };
  await Promise.all(Object.entries(files).map(([name, value]) => writeFile(path.join(runtime, name), value)));
  const approval = {
    runtime: 'llama.cpp',
    runtimeVersion: 'b10507',
    binary: 'llama-server.exe',
    binarySha256: digest(files['llama-server.exe']),
    runtimeFiles: { 'runtime-a.dll': digest(files['runtime-a.dll']) },
    model: 'Llama-3.2-3B-Instruct-Q4_K_M.gguf',
    modelSha256: digest(files['models/Llama-3.2-3B-Instruct-Q4_K_M.gguf']),
  };
  await writeFile(path.join(runtime, 'approved-runtime.json'), `${JSON.stringify(approval)}\n`);
  await writeFile(path.join(runtime, 'runtime-manifest.json'), `${JSON.stringify(approval)}\n`);
  return { runtime, files };
}

test('approved runtime verification covers every required DLL', async (t) => {
  const { runtime } = await fixture();
  t.after(() => rm(runtime, { recursive: true, force: true }));
  await assert.doesNotReject(() => verifyApprovedRuntime(runtime));
  await writeFile(path.join(runtime, 'runtime-a.dll'), 'substituted dependency');
  await assert.rejects(() => verifyApprovedRuntime(runtime), /runtime DLL SHA-256 mismatch/);
});

test('approved runtime verification rejects an unexpected executable', async (t) => {
  const { runtime } = await fixture();
  t.after(() => rm(runtime, { recursive: true, force: true }));
  await writeFile(path.join(runtime, 'unexpected.dll'), 'unapproved payload');
  await assert.rejects(() => verifyApprovedRuntime(runtime), /unapproved runtime executable files/);
});

test('sealing records post-signing DLL hashes for installed verification', async (t) => {
  const { runtime } = await fixture();
  t.after(() => rm(runtime, { recursive: true, force: true }));
  await writeFile(path.join(runtime, 'runtime-a.dll'), 'signed runtime dependency');
  const sealed = await sealRuntimeManifest(runtime);
  assert.equal(sealed.runtimeFiles['runtime-a.dll'], digest('signed runtime dependency'));
  await assert.doesNotReject(() => verifyRuntime(runtime));
  await assert.doesNotReject(() => verifySourceRuntime(runtime));
  const manifest = JSON.parse(await readFile(path.join(runtime, 'runtime-manifest.json'), 'utf8'));
  assert.equal(manifest.runtimeFiles['runtime-a.dll'], digest('signed runtime dependency'));
  assert.deepEqual(readIntegrityModule(runtime), manifest);
});
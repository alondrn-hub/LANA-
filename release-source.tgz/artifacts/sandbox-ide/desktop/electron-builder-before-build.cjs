const { verifySourceRuntime } = require('./release.cjs');

module.exports = async function beforeBuild() {
  await verifySourceRuntime();
  return true;
};
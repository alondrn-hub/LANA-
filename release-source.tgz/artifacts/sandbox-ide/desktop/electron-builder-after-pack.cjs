const path = require('node:path');
const { verifyRuntime } = require('./release.cjs');

module.exports = async function afterPack(context) {
  await verifyRuntime(path.join(context.appOutDir, 'resources', 'runtime'));
};
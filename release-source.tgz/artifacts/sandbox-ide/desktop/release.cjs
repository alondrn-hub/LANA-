const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');

const RUNTIME_DIR = path.join(__dirname, 'runtime');
const APPROVAL_NAME = 'approved-runtime.json';
const MANIFEST_NAME = 'runtime-manifest.json';
const INTEGRITY_NAME = 'runtime-integrity.cjs';
const BINARY_NAME = 'llama-server.exe';
const MODEL_NAME = 'Llama-3.2-3B-Instruct-Q4_K_M.gguf';
const PLACEHOLDER = 'release-pipeline-required';

function readJson(runtimeDir, fileName, label) {
  const filePath = path.join(runtimeDir, fileName);
  try {
    return JSON.parse(fs.readFileSync(filePath, 'utf8'));
  } catch (error) {
    throw new Error(`Cannot read ${label} at ${filePath}: ${error.message}`);
  }
}

function readApproval(runtimeDir = RUNTIME_DIR) {
  return readJson(runtimeDir, APPROVAL_NAME, 'runtime approval');
}

function readManifest(runtimeDir = RUNTIME_DIR) {
  return readJson(runtimeDir, MANIFEST_NAME, 'runtime manifest');
}

function sha256(filePath) {
  return new Promise((resolve, reject) => {
    const hash = crypto.createHash('sha256');
    const stream = fs.createReadStream(filePath);
    stream.on('error', reject);
    stream.on('data', (chunk) => hash.update(chunk));
    stream.on('end', () => resolve(hash.digest('hex')));
  });
}

function requireSha256(value, label) {
  if (!/^[a-f0-9]{64}$/i.test(value ?? '')) {
    throw new Error(`${label} must be a 64-character SHA-256 value in the release manifest.`);
  }
}

function runtimeFileEntries(manifest, label) {
  if (!manifest.runtimeFiles || typeof manifest.runtimeFiles !== 'object' || Array.isArray(manifest.runtimeFiles)) {
    throw new Error(`${label} must list every required runtime DLL.`);
  }
  const entries = Object.entries(manifest.runtimeFiles);
  if (entries.length === 0) throw new Error(`${label} must list at least one runtime DLL.`);
  for (const [fileName, hash] of entries) {
    if (!/^[A-Za-z0-9][A-Za-z0-9._-]*\.dll$/i.test(fileName)) {
      throw new Error(`${label} contains an invalid runtime DLL path: ${fileName}.`);
    }
    requireSha256(hash, `runtimeFiles.${fileName}`);
  }
  return entries.sort(([left], [right]) => left.localeCompare(right));
}

function expectedExecutableNames(manifest, label) {
  return new Set([BINARY_NAME, ...runtimeFileEntries(manifest, label).map(([fileName]) => fileName)]);
}

function assertExactRuntimeExecutables(runtimeDir, manifest, label) {
  const expected = expectedExecutableNames(manifest, label);
  const actual = fs.readdirSync(runtimeDir, { withFileTypes: true })
    .filter((entry) => entry.isFile() && /\.(exe|dll)$/i.test(entry.name))
    .map((entry) => entry.name);
  const unexpected = actual.filter((fileName) => !expected.has(fileName));
  if (unexpected.length > 0) {
    throw new Error(`${label} contains unapproved runtime executable files: ${unexpected.sort().join(', ')}.`);
  }
}

function integrityModulePath(runtimeDir) {
  return path.join(runtimeDir, '..', INTEGRITY_NAME);
}

function writeIntegrityModule(runtimeDir, manifest) {
  fs.writeFileSync(integrityModulePath(runtimeDir), `module.exports = ${JSON.stringify(manifest, null, 2)};\n`);
}

function readIntegrityModule(runtimeDir) {
  const integrityPath = integrityModulePath(runtimeDir);
  let source;
  try {
    source = fs.readFileSync(integrityPath, 'utf8');
  } catch (error) {
    throw new Error(`Cannot read signed runtime integrity module at ${integrityPath}: ${error.message}`);
  }
  const match = /^module\.exports = ([\s\S]+);\s*$/.exec(source);
  if (!match) throw new Error(`Signed runtime integrity module has an invalid format: ${integrityPath}.`);
  try {
    return JSON.parse(match[1]);
  } catch (error) {
    throw new Error(`Signed runtime integrity module contains invalid JSON: ${error.message}`);
  }
}

function requiredFile(filePath, label) {
  if (!fs.existsSync(filePath)) {
    throw new Error(`${label} is missing: ${filePath}`);
  }
  const stat = fs.statSync(filePath);
  if (!stat.isFile() || stat.size === 0) {
    throw new Error(`${label} must be a non-empty file: ${filePath}`);
  }
}

function validateIdentity(manifest, label) {
  if (manifest.runtime !== 'llama.cpp') throw new Error(`${label} must target llama.cpp.`);
  if (manifest.binary !== BINARY_NAME) throw new Error(`${label} binary must be ${BINARY_NAME}.`);
  if (manifest.model !== MODEL_NAME) throw new Error(`${label} model must be ${MODEL_NAME}.`);
  if (!manifest.runtimeVersion || manifest.runtimeVersion === 'pinned-release-required') {
    throw new Error(`runtimeVersion is not pinned. Record the approved release in ${APPROVAL_NAME}.`);
  }
  if (manifest.binarySha256 === PLACEHOLDER || manifest.modelSha256 === PLACEHOLDER) {
    throw new Error(`Runtime asset hashes are not approved in ${label}.`);
  }
  requireSha256(manifest.binarySha256, 'binarySha256');
  requireSha256(manifest.modelSha256, 'modelSha256');
  runtimeFileEntries(manifest, label);
}

async function verifyAssets(runtimeDir, manifest, label) {
  assertExactRuntimeExecutables(runtimeDir, manifest, label);
  const binaryPath = path.join(runtimeDir, BINARY_NAME);
  const modelPath = path.join(runtimeDir, 'models', MODEL_NAME);
  requiredFile(binaryPath, 'llama.cpp Windows x64 runtime');
  requiredFile(modelPath, 'approved GGUF model');
  const runtimeFiles = runtimeFileEntries(manifest, label).map(([fileName, expectedHash]) => ({
    fileName,
    expectedHash,
    filePath: path.join(runtimeDir, fileName),
  }));
  for (const runtimeFile of runtimeFiles) requiredFile(runtimeFile.filePath, `required runtime DLL ${runtimeFile.fileName}`);

  const [binaryHash, modelHash, ...runtimeHashes] = await Promise.all([
    sha256(binaryPath),
    sha256(modelPath),
    ...runtimeFiles.map((runtimeFile) => sha256(runtimeFile.filePath)),
  ]);
  if (binaryHash.toLowerCase() !== manifest.binarySha256.toLowerCase()) {
    throw new Error(`${label} llama-server.exe SHA-256 mismatch. Expected ${manifest.binarySha256}, got ${binaryHash}.`);
  }
  if (modelHash.toLowerCase() !== manifest.modelSha256.toLowerCase()) {
    throw new Error(`${label} GGUF model SHA-256 mismatch. Expected ${manifest.modelSha256}, got ${modelHash}.`);
  }
  for (const [index, runtimeHash] of runtimeHashes.entries()) {
    const runtimeFile = runtimeFiles[index];
    if (runtimeHash.toLowerCase() !== runtimeFile.expectedHash.toLowerCase()) {
      throw new Error(`${label} runtime DLL SHA-256 mismatch for ${runtimeFile.fileName}. Expected ${runtimeFile.expectedHash}, got ${runtimeHash}.`);
    }
  }
  return { manifest, binaryPath, modelPath, binaryHash, modelHash, runtimeFiles, runtimeHashes };
}

async function verifyApprovedRuntime(runtimeDir = RUNTIME_DIR) {
  const approval = readApproval(runtimeDir);
  validateIdentity(approval, 'Runtime approval');
  return verifyAssets(runtimeDir, approval, 'Approved');
}

async function verifyRuntime(runtimeDir = RUNTIME_DIR) {
  const manifest = readManifest(runtimeDir);
  validateIdentity(manifest, 'Runtime manifest');
  return verifyAssets(runtimeDir, manifest, 'Bundled');
}

async function verifySourceRuntime(runtimeDir = RUNTIME_DIR) {
  const result = await verifyRuntime(runtimeDir);
  const integrity = readIntegrityModule(runtimeDir);
  validateIdentity(integrity, 'Signed runtime integrity module');
  if (JSON.stringify(integrity) !== JSON.stringify(result.manifest)) {
    throw new Error('Signed runtime integrity module does not match the sealed runtime manifest.');
  }
  return result;
}

async function sealRuntimeManifest(runtimeDir = RUNTIME_DIR) {
  const approval = readApproval(runtimeDir);
  validateIdentity(approval, 'Runtime approval');
  const manifest = readManifest(runtimeDir);
  const binaryPath = path.join(runtimeDir, BINARY_NAME);
  const modelPath = path.join(runtimeDir, 'models', MODEL_NAME);
  requiredFile(binaryPath, 'signed llama.cpp Windows x64 runtime');
  requiredFile(modelPath, 'approved GGUF model');
  const runtimeFiles = runtimeFileEntries(approval, 'Runtime approval').map(([fileName]) => ({
    fileName,
    filePath: path.join(runtimeDir, fileName),
  }));
  for (const runtimeFile of runtimeFiles) requiredFile(runtimeFile.filePath, `signed runtime DLL ${runtimeFile.fileName}`);
  const [binarySha256, modelSha256, ...runtimeHashes] = await Promise.all([
    sha256(binaryPath),
    sha256(modelPath),
    ...runtimeFiles.map((runtimeFile) => sha256(runtimeFile.filePath)),
  ]);
  if (modelSha256.toLowerCase() !== approval.modelSha256.toLowerCase()) {
    throw new Error(`Approved GGUF model SHA-256 mismatch. Expected ${approval.modelSha256}, got ${modelSha256}.`);
  }
  const sealed = {
    ...manifest,
    runtime: approval.runtime,
    runtimeVersion: approval.runtimeVersion,
    binary: approval.binary,
    binarySha256,
    runtimeFiles: Object.fromEntries(runtimeFiles.map((runtimeFile, index) => [runtimeFile.fileName, runtimeHashes[index]])),
    model: approval.model,
    modelSha256: approval.modelSha256.toLowerCase(),
  };
  fs.writeFileSync(path.join(runtimeDir, MANIFEST_NAME), `${JSON.stringify(sealed, null, 2)}\n`);
  writeIntegrityModule(runtimeDir, sealed);
  console.log(`Sealed ${MANIFEST_NAME} and ${INTEGRITY_NAME} for signed llama.cpp ${approval.runtimeVersion}.`);
  return sealed;
}

async function main() {
  const command = process.argv[2] ?? 'verify';
  if (command === 'verify-approved') {
    const result = await verifyApprovedRuntime();
    console.log(`Verified approved unsigned llama.cpp ${result.manifest.runtimeVersion} and model hashes.`);
    return;
  }
  if (command === 'seal-manifest') {
    await sealRuntimeManifest();
    return;
  }
  if (command === 'verify') {
    const result = await verifyRuntime();
    console.log(`Verified signed llama.cpp ${result.manifest.runtimeVersion}, runtime and model hashes match.`);
    return;
  }
  if (command === 'verify-source') {
    const result = await verifySourceRuntime();
    console.log(`Verified signed source runtime ${result.manifest.runtimeVersion} and app integrity module.`);
    return;
  }
  throw new Error(`Unknown release command "${command}". Use verify-approved, seal-manifest, verify, or verify-source.`);
}

if (require.main === module) {
  main().catch((error) => {
    console.error(`Release check failed: ${error.message}`);
    process.exitCode = 1;
  });
}

module.exports = {
  readApproval,
  readManifest,
  readIntegrityModule,
  sealRuntimeManifest,
  sha256,
  verifyApprovedRuntime,
  verifyRuntime,
  verifySourceRuntime,
};
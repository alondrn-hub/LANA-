module.exports = {
  "runtime": "llama.cpp",
  "runtimeVersion": "pinned-release-required",
  "binary": "llama-server.exe",
  "binarySha256": "release-pipeline-required",
  "runtimeFiles": {},
  "model": "Llama-3.2-3B-Instruct-Q4_K_M.gguf",
  "modelSha256": "release-pipeline-required"
};
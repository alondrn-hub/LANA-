const { spawnSync } = require('node:child_process');
const { verifySourceRuntime } = require('./release.cjs');

async function main() {
  await verifySourceRuntime();
  const result = spawnSync('pnpm', ['run', 'build'], {
    stdio: 'inherit',
    shell: process.platform === 'win32',
    env: { ...process.env, PORT: process.env.PORT || '4173', BASE_PATH: './', NODE_ENV: 'production' },
  });
  if (result.status !== 0) process.exit(result.status || 1);
}

main().catch((error) => {
  console.error(`Desktop build stopped: ${error.message}`);
  process.exitCode = 1;
});
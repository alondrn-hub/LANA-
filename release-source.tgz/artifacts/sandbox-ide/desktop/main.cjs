/* Windows desktop host for LANA DEV. The installer places llama-server.exe and
 * the approved model beside this file; no Ollama, API key, or cloud service is
 * needed. */
const { app, BrowserWindow, ipcMain, shell } = require('electron');
const { spawn } = require('node:child_process');
const { createReadStream, existsSync, readdirSync, statfsSync } = require('node:fs');
const { createHash } = require('node:crypto');
const path = require('node:path');
const http = require('node:http');
const runtimeIntegrity = require('./runtime-integrity.cjs');

const MODEL = 'Llama-3.2-3B-Instruct-Q4_K_M.gguf';
const MODEL_BYTES = 2_100_000_000;
const PORT = 39271;
let serverProcess;
let runtime = { state: 'starting', message: 'Starting the bundled llama.cpp runtime…', model: MODEL, gpu: 'cpu' };

function runtimePaths() {
  const root = app.isPackaged ? process.resourcesPath : path.join(__dirname, 'runtime');
  return {
    root,
    binary: path.join(root, 'llama-server.exe'),
    model: path.join(root, 'models', MODEL),
  };
}

function setRuntime(next) { runtime = { ...runtime, ...next }; }
function sha256(filePath) {
  return new Promise((resolve, reject) => {
    const hash = createHash('sha256');
    const stream = createReadStream(filePath);
    stream.on('error', reject);
    stream.on('data', (chunk) => hash.update(chunk));
    stream.on('end', () => resolve(hash.digest('hex')));
  });
}
function runtimeFileEntries(manifest, root) {
  if (!manifest.runtimeFiles || typeof manifest.runtimeFiles !== 'object' || Array.isArray(manifest.runtimeFiles)) {
    throw new Error('The bundled runtime manifest does not list required runtime DLLs.');
  }
  const entries = Object.entries(manifest.runtimeFiles);
  if (entries.length === 0) throw new Error('The bundled runtime manifest does not list required runtime DLLs.');
  return entries.map(([fileName, expectedHash]) => {
    if (!/^[A-Za-z0-9][A-Za-z0-9._-]*\.dll$/i.test(fileName) || !/^[a-f0-9]{64}$/i.test(expectedHash)) {
      throw new Error('The bundled runtime manifest contains an invalid runtime DLL record.');
    }
    return { fileName, expectedHash, filePath: path.join(root, fileName) };
  });
}
function assertExactRuntimeExecutables(root, runtimeFiles) {
  const expected = new Set(['llama-server.exe', ...runtimeFiles.map(({ fileName }) => fileName)]);
  const unexpected = readdirSync(root, { withFileTypes: true })
    .filter((entry) => entry.isFile() && /\.(exe|dll)$/i.test(entry.name) && !expected.has(entry.name))
    .map((entry) => entry.name);
  if (unexpected.length > 0) throw new Error('The bundled runtime contains unapproved executable files.');
}
async function verifyRuntimeAssets(root, binary, model, manifest) {
  if (manifest.runtime !== 'llama.cpp' || manifest.binary !== 'llama-server.exe' || manifest.model !== MODEL) {
    throw new Error('The bundled runtime manifest does not match this application.');
  }
  if (!/^[a-f0-9]{64}$/i.test(manifest.binarySha256) || !/^[a-f0-9]{64}$/i.test(manifest.modelSha256)) {
    throw new Error('The bundled runtime manifest is not approved.');
  }
  const runtimeFiles = runtimeFileEntries(manifest, root);
  assertExactRuntimeExecutables(root, runtimeFiles);
  if (!runtimeFiles.every(({ filePath }) => existsSync(filePath))) throw new Error('A required runtime DLL is missing.');
  const [binaryHash, modelHash, ...runtimeHashes] = await Promise.all([sha256(binary), sha256(model), ...runtimeFiles.map(({ filePath }) => sha256(filePath))]);
  if (binaryHash.toLowerCase() !== manifest.binarySha256.toLowerCase()) {
    throw new Error('The bundled llama.cpp runtime failed its integrity check.');
  }
  if (modelHash.toLowerCase() !== manifest.modelSha256.toLowerCase()) {
    throw new Error('The bundled Llama model failed its integrity check.');
  }
  if (runtimeHashes.some((hash, index) => hash.toLowerCase() !== runtimeFiles[index].expectedHash.toLowerCase())) {
    throw new Error('A bundled runtime DLL failed its integrity check.');
  }
}
function probe() {
  return new Promise((resolve) => {
    const request = http.get(`http://127.0.0.1:${PORT}/health`, { timeout: 1200 }, (response) => {
      response.resume(); resolve(response.statusCode === 200);
    });
    request.on('error', () => resolve(false)); request.on('timeout', () => { request.destroy(); resolve(false); });
  });
}
async function startRuntime() {
  const { root, binary, model } = runtimePaths();
  if (!existsSync(binary)) return setRuntime({ state: 'error', message: 'The bundled llama.cpp runtime is missing. Re-run the LANA DEV installer.' });
  if (!existsSync(model)) return setRuntime({ state: 'error', message: `The approved Llama model is missing (${MODEL}). Re-run setup to download it.` });
  try {
    await verifyRuntimeAssets(root, binary, model, runtimeIntegrity);
  } catch {
    return setRuntime({ state: 'error', message: 'The bundled local AI files failed their integrity check. Re-run the signed LANA DEV installer.' });
  }
  const free = statfsSync(app.getPath('userData')).bavail * statfsSync(app.getPath('userData')).bsize;
  if (free < MODEL_BYTES * 1.15) return setRuntime({ state: 'error', message: 'Not enough disk space for the local model. Free at least 2.5 GB and retry.', diskFreeBytes: free, requiredBytes: MODEL_BYTES });
  setRuntime({ state: 'starting', message: 'Loading the approved Llama model…' });
  serverProcess = spawn(binary, ['--model', model, '--host', '127.0.0.1', '--port', String(PORT), '--ctx-size', '8192', '--parallel', '3', '--gpu-layers', '999'], { windowsHide: true, stdio: 'ignore' });
  serverProcess.on('error', () => setRuntime({ state: 'error', message: 'The local runtime could not start. This PC will use the CPU-compatible setup after you retry.' }));
  for (let attempt = 0; attempt < 45; attempt += 1) {
    if (await probe()) { setRuntime({ state: 'ready', message: 'Local AI is ready. Copilot, inline suggestions, and AI Factory share this runtime.' }); return; }
    await new Promise((resolve) => setTimeout(resolve, 500));
  }
  setRuntime({ state: 'error', message: 'The model took too long to start. Retry setup; CPU mode is available on every supported Windows PC.' });
}
function createWindow() {
  const window = new BrowserWindow({ width: 1440, height: 920, minWidth: 980, minHeight: 640, backgroundColor: '#202338', webPreferences: { preload: path.join(__dirname, 'preload.cjs'), contextIsolation: true, nodeIntegration: false } });
  window.loadFile(path.join(__dirname, '..', 'dist', 'public', 'index.html'));
}
ipcMain.handle('runtime:state', () => runtime);
ipcMain.handle('runtime:retry', async () => { if (serverProcess) serverProcess.kill(); await startRuntime(); return runtime; });
ipcMain.handle('runtime:models-folder', () => shell.openPath(path.dirname(runtimePaths().model)));
app.whenReady().then(async () => { await startRuntime(); createWindow(); });
app.on('before-quit', () => { if (serverProcess) serverProcess.kill(); });
# LANA DEV Windows runtime bundle

The release bundle contains `llama-server.exe` and its required runtime DLLs
from the pinned llama.cpp Windows x64 release, and
`runtime/models/Llama-3.2-3B-Instruct-Q4_K_M.gguf`. The release manifest stores
the reviewed runtime version and SHA-256 for every executable runtime file and
the model. The build refuses to package missing, empty, unpinned, or
hash-mismatched assets.

The runtime is localhost-only, starts with three concurrent slots, and exposes
the OpenAI-compatible API on port 39271. CPU mode is the compatibility floor;
the launcher requests GPU offload when the bundled binary supports it.

## Release pipeline

1. Run `installer/windows/provision-runtime.ps1` on the clean Windows worker.
   It downloads the approved llama.cpp `b10507` CPU x64 archive and the
   approved GGUF, verifies the upstream archive before extraction, and checks
   every supplied executable/DLL and model hash against
   `runtime/approved-runtime.json`.
2. The approval record contains the reviewed runtime version, archive,
   executable/DLL, and model SHA-256 values. Do not regenerate or edit these
   hashes during release packaging.
3. On a clean Windows machine with Node, pnpm, Electron Builder, and the
   Windows SDK `signtool.exe`, import the code-signing certificate into the
   release account's certificate store using the pipeline secret mechanism,
   then set `LANA_SIGNING_CERTIFICATE_THUMBPRINT`. The signing password is
   never passed on a process command line.
4. Run `pnpm desktop:release` from this package. It builds the relative-base
   web assets, signs every approved llama.cpp executable/DLL, seals
   `runtime-manifest.json` with their final signed hashes, checks the runtime
   again after electron-builder stages it, creates the per-user x64 NSIS
   installer, signs the packaged app and installer with the same
   certificate-store identity, verifies all runtime, app, and installer
   signatures, and writes `dist/LANA-DEV-Setup.exe.sha256` beside the
   installer. Publish both files as the release artifacts.

The installer creates a Start Menu and desktop shortcut and includes the
runtime under `resources/runtime`. Its NSIS install hook refuses to complete if
the runtime, manifest, or model is absent. On every launch, the host checks the
installed executable, every required DLL, and the model against the bundled
signed manifest before starting llama.cpp, then checks free disk space.
Missing, substituted, or damaged assets and insufficient space are shown in the
IDE instead of silently switching to cloud AI. No user model credential is
read.

`pnpm desktop:verify-approved-runtime` validates the clean unsigned inputs.
`pnpm desktop:verify-runtime` validates the sealed signed bundle. The checked-in
approval contains only reviewed public hashes; no binary, model, or signing
certificate is committed.
# Android local model contract

The Android companion is a single native build: the Expo host owns model
storage and llama.cpp, while the shared workspace UI talks to it through the
`window.lanaAndroid` bridge.

The native host must expose:

- `getRuntimeStatus()` and `retrySetup()` for first-run model provisioning.
- `chat({ messages, signal })` using the bundled approved quantized model.
- `state` values of `starting`, `downloading`, `ready`, `memory-pressure`,
  `offline`, `unsupported`, or `error`.
- `model`, `acceleration`, and optional download/memory counters.

The host should copy the quantized model from the APK to app-private storage
on first launch, verify it before loading llama.cpp, and never send workspace
content to a cloud provider. When memory is below the model's required
threshold, return `memory-pressure` without starting a native inference
request. `unsupported` is reserved for devices that cannot run the approved
runtime; `offline` means the model is not currently loaded, not that a cloud
fallback is allowed.

The bridge follows the same `LocalModelClient` request and response shape used
by Copilot, inline suggestions, and AI Factory workers. The Factory already
uses `Promise.all` for independent workers, so native llama.cpp must support
concurrent requests or queue them while preserving request cancellation.

## Packaged companion

The implementation lives in `artifacts/lana-android`. It installs this exact
bridge contract from `runtime/lanaAndroidBridge.ts`, compiles a pinned
llama.cpp release through the local Expo module, and provisions the approved
GGUF into Android app-private storage with disk, memory, ABI, API-level,
file-size, and SHA-256 checks. Build and device requirements are documented in
`artifacts/lana-android/ANDROID_BUILD.md`.
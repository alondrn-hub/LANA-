# Local model setup

Sandbox IDE never sends workspace content to a cloud model. It connects to an
Ollama-compatible server using `VITE_OLLAMA_BASE_URL` when configured, or
`http://localhost:11434` by default.

## Development preview

The Replit development preview uses a same-origin `/__ollama` proxy to the
local Ollama port. Start Ollama and install the configured model:

```sh
ollama pull qwen2.5-coder
ollama serve
```

## Published IDE

A published IDE is served from HTTPS, so the browser connects directly to
Ollama and Ollama must allow the published IDE origin. Set `OLLAMA_ORIGINS` to
the exact origin shown in the browser address bar before starting Ollama. Add
multiple origins as a comma-separated list when you use both a published
domain and local development:

```sh
OLLAMA_ORIGINS="https://your-published-ide.example,http://localhost:5173" ollama serve
```

If Ollama is running on another host, set `VITE_OLLAMA_BASE_URL` to that
server's `/`-less base URL when building the IDE. That server must also allow
the published IDE origin through CORS. The IDE reports the required local
setup and never falls back to a cloud provider when the connection is
unavailable.
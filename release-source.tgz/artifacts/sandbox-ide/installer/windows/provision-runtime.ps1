$ErrorActionPreference = "Stop"
$ProgressPreference = "SilentlyContinue"

$packageDir = (Resolve-Path (Join-Path $PSScriptRoot "..\..")).Path
$runtimeDir = Join-Path $packageDir "desktop\runtime"
$modelDir = Join-Path $runtimeDir "models"
$approvalPath = Join-Path $runtimeDir "approved-runtime.json"
$stagingDir = Join-Path ([IO.Path]::GetTempPath()) ("lana-runtime-" + [guid]::NewGuid().ToString("N"))

function Get-Sha256([string]$Path) {
  return (Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToLowerInvariant()
}

try {
  $approval = Get-Content -LiteralPath $approvalPath -Raw | ConvertFrom-Json
  if ($approval.runtimeVersion -ne "b10507" -or -not $approval.upstreamArchive.url -or -not $approval.upstreamArchive.sha256) {
    throw "The approved runtime record is incomplete."
  }

  New-Item -ItemType Directory -Force -Path $stagingDir, $modelDir | Out-Null
  $archivePath = Join-Path $stagingDir "llama-runtime.zip"
  Invoke-WebRequest -Uri $approval.upstreamArchive.url -OutFile $archivePath
  if ((Get-Sha256 $archivePath) -ne $approval.upstreamArchive.sha256.ToLowerInvariant()) {
    throw "The downloaded llama.cpp archive does not match its approved SHA-256."
  }

  $archiveDir = Join-Path $stagingDir "archive"
  Expand-Archive -LiteralPath $archivePath -DestinationPath $archiveDir
  $requiredNames = @($approval.binary) + @($approval.runtimeFiles.psobject.Properties.Name)
  Get-ChildItem -LiteralPath $runtimeDir -File | Where-Object { $_.Extension -in ".exe", ".dll" } | Remove-Item -Force
  foreach ($name in $requiredNames) {
    $source = Join-Path $archiveDir $name
    $destination = Join-Path $runtimeDir $name
    if (-not (Test-Path -LiteralPath $source -PathType Leaf)) {
      throw "The approved llama.cpp archive is missing $name."
    }
    Copy-Item -LiteralPath $source -Destination $destination -Force
  }

  $modelPath = Join-Path $modelDir $approval.model
  Invoke-WebRequest -Uri "https://huggingface.co/unsloth/Llama-3.2-3B-Instruct-GGUF/resolve/main/Llama-3.2-3B-Instruct-Q4_K_M.gguf" -OutFile $modelPath
  if ((Get-Sha256 $modelPath) -ne $approval.modelSha256.ToLowerInvariant()) {
    throw "The downloaded GGUF model does not match its approved SHA-256."
  }

  Push-Location $packageDir
  try {
    node desktop\release.cjs verify-approved
    if ($LASTEXITCODE -ne 0) { throw "Approved runtime verification failed." }
  } finally {
    Pop-Location
  }
} finally {
  Remove-Item -LiteralPath $stagingDir -Recurse -Force -ErrorAction SilentlyContinue
}
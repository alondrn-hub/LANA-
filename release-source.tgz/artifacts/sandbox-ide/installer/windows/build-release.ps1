$ErrorActionPreference = "Stop"

$packageDir = (Resolve-Path (Join-Path $PSScriptRoot "..\..")).Path
$releaseDir = Join-Path $packageDir "dist"
$installerPath = Join-Path $releaseDir "LANA-DEV-Setup.exe"
$appExecutablePath = Join-Path $releaseDir "win-unpacked\LANA DEV.exe"
$sourceRuntimePath = Join-Path $packageDir "desktop\runtime\llama-server.exe"
$packagedRuntimePath = Join-Path $releaseDir "win-unpacked\resources\runtime\llama-server.exe"
$checksumPath = "$installerPath.sha256"

Push-Location $packageDir
try {
  if (-not $env:LANA_SIGNING_CERTIFICATE_THUMBPRINT) {
    throw "Import the signing certificate into the release account certificate store and supply LANA_SIGNING_CERTIFICATE_THUMBPRINT."
  }

  $signTool = $env:LANA_SIGNTOOL_PATH
  if (-not $signTool) {
    $signTool = (Get-Command signtool.exe -ErrorAction Stop).Source
  }

  node desktop\release.cjs verify-approved
  if ($LASTEXITCODE -ne 0) { throw "Approved runtime verification failed before signing." }

  $approval = Get-Content -LiteralPath (Join-Path $packageDir "desktop\runtime\approved-runtime.json") -Raw | ConvertFrom-Json
  $runtimeFileNames = @($approval.binary) + @($approval.runtimeFiles.psobject.Properties.Name)
  $runtimeDirectory = Join-Path $packageDir "desktop\runtime"
  $runtimeFiles = @($runtimeFileNames | ForEach-Object {
    $path = Join-Path $runtimeDirectory $_
    if (-not (Test-Path -LiteralPath $path -PathType Leaf)) { throw "Expected approved runtime file is missing: $_" }
    Get-Item -LiteralPath $path
  })
  $unexpectedRuntimeFiles = Get-ChildItem -LiteralPath $runtimeDirectory -File | Where-Object {
    $_.Extension -in ".exe", ".dll" -and $_.Name -notin $runtimeFileNames
  }
  if ($unexpectedRuntimeFiles.Count -gt 0) { throw "Unapproved runtime executable files are present: $($unexpectedRuntimeFiles.Name -join ', ')" }
  foreach ($runtimeFile in $runtimeFiles) {
    & $signTool sign /fd SHA256 /tr http://timestamp.digicert.com /td SHA256 /d "LANA DEV local runtime" /sha1 $env:LANA_SIGNING_CERTIFICATE_THUMBPRINT $runtimeFile.FullName
    if ($LASTEXITCODE -ne 0) { throw "Bundled llama.cpp signing failed for $($runtimeFile.Name)." }
    & $signTool verify /pa /all $runtimeFile.FullName
    if ($LASTEXITCODE -ne 0) { throw "Bundled llama.cpp signature verification failed for $($runtimeFile.Name)." }
  }

  node desktop\release.cjs seal-manifest
  if ($LASTEXITCODE -ne 0) { throw "Signed runtime manifest sealing failed." }
  node desktop\release.cjs verify-source
  if ($LASTEXITCODE -ne 0) { throw "Signed source runtime verification failed." }

  node desktop\build.cjs
  if ($LASTEXITCODE -ne 0) { throw "Desktop asset build failed." }

  $certificateArgument = "--config.win.certificateSha1=$($env:LANA_SIGNING_CERTIFICATE_THUMBPRINT)"
  pnpm exec electron-builder --win nsis $certificateArgument
  if ($LASTEXITCODE -ne 0) { throw "Signed Electron NSIS build failed." }
  if (-not (Test-Path -LiteralPath $installerPath -PathType Leaf)) {
    throw "Expected installer was not produced: $installerPath"
  }
  if (-not (Test-Path -LiteralPath $appExecutablePath -PathType Leaf)) {
    throw "Expected packaged application was not produced: $appExecutablePath"
  }
  if (-not (Test-Path -LiteralPath $packagedRuntimePath -PathType Leaf)) {
    throw "Expected packaged llama.cpp runtime was not produced: $packagedRuntimePath"
  }

  & $signTool verify /pa /all $packagedRuntimePath
  if ($LASTEXITCODE -ne 0) { throw "Packaged llama.cpp signature verification failed." }
  $packagedRuntimeDirectory = Split-Path -Parent $packagedRuntimePath
  $unexpectedPackagedRuntimeFiles = Get-ChildItem -LiteralPath $packagedRuntimeDirectory -File | Where-Object {
    $_.Extension -in ".exe", ".dll" -and $_.Name -notin $runtimeFileNames
  }
  if ($unexpectedPackagedRuntimeFiles.Count -gt 0) { throw "Unapproved packaged runtime executable files are present: $($unexpectedPackagedRuntimeFiles.Name -join ', ')" }
  foreach ($runtimeFile in ($runtimeFileNames | ForEach-Object { Get-Item -LiteralPath (Join-Path $packagedRuntimeDirectory $_) })) {
    & $signTool verify /pa /all $runtimeFile.FullName
    if ($LASTEXITCODE -ne 0) { throw "Packaged runtime signature verification failed for $($runtimeFile.Name)." }
  }
  & $signTool verify /pa /all $appExecutablePath
  if ($LASTEXITCODE -ne 0) { throw "Packaged application signature verification failed." }
  & $signTool verify /pa /all $installerPath
  if ($LASTEXITCODE -ne 0) { throw "Signed installer verification failed." }

  $hash = (Get-FileHash -LiteralPath $installerPath -Algorithm SHA256).Hash.ToLowerInvariant()
  "$hash *$([IO.Path]::GetFileName($installerPath))" | Set-Content -LiteralPath $checksumPath -Encoding ascii
  Write-Host "Created $installerPath"
  Write-Host "Created $checksumPath"
} finally {
  Pop-Location
}
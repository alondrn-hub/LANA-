; This file is included by electron-builder's generated NSIS installer.
; The Electron runtime, app files, and extraResources are managed by
; electron-builder. Keep the release asset gate in desktop/release.cjs too:
; an NSIS hook is not a substitute for checking files before packaging.
Unicode True

!macro customInstall
  IfFileExists "$INSTDIR\resources\runtime\llama-server.exe" runtime_binary_present
    MessageBox MB_ICONSTOP "The bundled llama.cpp runtime is missing. This installer is incomplete."
    Abort
  runtime_binary_present:

  IfFileExists "$INSTDIR\resources\runtime\runtime-manifest.json" runtime_manifest_present
    MessageBox MB_ICONSTOP "The local runtime approval manifest is missing. This installer is incomplete."
    Abort
  runtime_manifest_present:

  IfFileExists "$INSTDIR\resources\runtime\models\Llama-3.2-3B-Instruct-Q4_K_M.gguf" runtime_model_present
    MessageBox MB_ICONSTOP "The approved Llama model is missing. This installer is incomplete."
    Abort
  runtime_model_present:
!macroend
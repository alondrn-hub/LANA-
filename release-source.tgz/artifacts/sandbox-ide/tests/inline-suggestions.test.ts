import assert from 'node:assert/strict';
import test from 'node:test';
import {
  applyInlineSuggestion,
  canRequestInlineSuggestion,
  getInlineSuggestionKeyboardAction,
  type InlineAcceptance,
  type InlineSuggestion,
} from '../src/lib/ai/inlineSuggestion.ts';

const filePath = 'src/App.tsx';
const baseContent = 'const result = existingValue;';
const position = baseContent.indexOf('existingValue');
const suggestion: InlineSuggestion = {
  text: 'buildValue() + fallback\n  .trim()',
  position,
  baseContent,
  filePath,
};

function apply(acceptance: InlineAcceptance) {
  return applyInlineSuggestion({
    content: baseContent,
    filePath,
    suggestion,
    acceptance,
  });
}

test('word acceptance inserts only the next word at the saved cursor', () => {
  const result = apply('word');
  assert.equal(result.kind, 'applied');
  if (result.kind !== 'applied') return;

  assert.equal(result.acceptedText, 'buildValue() ');
  assert.equal(result.content, 'const result = buildValue() existingValue;');
  assert.deepEqual(result.remaining, {
    ...suggestion,
    text: '+ fallback\n  .trim()',
    position: position + 'buildValue() '.length,
    baseContent: result.content,
  });
});

test('line acceptance inserts only the first line at the saved cursor', () => {
  const result = apply('line');
  assert.equal(result.kind, 'applied');
  if (result.kind !== 'applied') return;

  assert.equal(result.acceptedText, 'buildValue() + fallback\n');
  assert.equal(result.content, 'const result = buildValue() + fallback\nexistingValue;');
  assert.equal(result.remaining?.text, '  .trim()');
});

test('full acceptance inserts the complete suggestion without replacing surrounding work', () => {
  const result = apply('all');
  assert.equal(result.kind, 'applied');
  if (result.kind !== 'applied') return;

  assert.equal(result.content, 'const result = buildValue() + fallback\n  .trim()existingValue;');
  assert.equal(result.nextPosition, position + suggestion.text.length);
  assert.equal(result.remaining, null);
});

test('Escape dismisses while the acceptance shortcuts map to word, line, and full actions', () => {
  assert.equal(getInlineSuggestionKeyboardAction({ key: 'Escape' }), 'dismiss');
  assert.equal(getInlineSuggestionKeyboardAction({ key: 'ArrowRight', ctrlKey: true }), 'word');
  assert.equal(getInlineSuggestionKeyboardAction({ key: 'ArrowRight', metaKey: true }), 'word');
  assert.equal(getInlineSuggestionKeyboardAction({ key: 'Enter' }), 'line');
  assert.equal(getInlineSuggestionKeyboardAction({ key: 'Enter', shiftKey: true }), null);
  assert.equal(getInlineSuggestionKeyboardAction({ key: 'Tab' }), 'all');
});

test('a suggestion is rejected after the user edits the file', () => {
  const editedContent = 'const userWork = true;\nconst result = existingValue;';
  const result = applyInlineSuggestion({
    content: editedContent,
    filePath,
    suggestion,
    acceptance: 'all',
  });

  assert.deepEqual(result, { kind: 'stale', reason: 'content-changed' });
  assert.equal(editedContent, 'const userWork = true;\nconst result = existingValue;');
});

test('a suggestion is rejected after switching files even when their content matches', () => {
  const result = applyInlineSuggestion({
    content: baseContent,
    filePath: 'src/main.tsx',
    suggestion,
    acceptance: 'all',
  });

  assert.deepEqual(result, { kind: 'stale', reason: 'file-switched' });
});

test('an offline local model blocks inline requests regardless of other ready state', () => {
  assert.equal(canRequestInlineSuggestion({
    isSignedIn: true,
    userId: 'user-fixture',
    hydratedUserId: 'user-fixture',
    isSuggesting: false,
    localModelAvailable: false,
  }), false);
});
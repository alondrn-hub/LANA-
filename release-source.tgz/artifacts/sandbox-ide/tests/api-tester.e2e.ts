import { expect, Page, test } from '@playwright/test';

type CapturedRequest = {
  method: string;
  url: string;
  headers: Record<string, string>;
  body: string | null;
};

async function openApiTester(page: Page) {
  await page.goto('/');
  await page.getByTestId('button-free-tool-api-tester').click();
  await expect(page.getByTestId('input-api-url')).toBeVisible();
}

async function captureApiRequests(page: Page, urlPrefix: string) {
  const requests: CapturedRequest[] = [];

  await page.route(`${urlPrefix}**`, async (route) => {
    const request = route.request();
    const headers = request.headers();
    const capturedHeaders = Object.fromEntries(
      Object.keys(headers)
        .filter((name) => ['accept', 'content-type', 'x-trace', 'x-read'].includes(name))
        .map((name) => [name, headers[name]]),
    );

    requests.push({
      method: request.method(),
      url: request.url(),
      headers: capturedHeaders,
      body: request.postData(),
    });

    await route.fulfill({
      status: 200,
      headers: {
        'access-control-allow-origin': '*',
        'content-type': 'application/json',
      },
      body: JSON.stringify({ ok: true }),
    });
  });

  return requests;
}

test('review and cancel keep the request inside the browser, then confirmation sends the reviewed snapshot', async ({ page }) => {
  const url = 'https://api.example.test/v1/users';
  const requests = await captureApiRequests(page, 'https://api.example.test/');

  await openApiTester(page);
  await page.getByTestId('select-api-method').selectOption('POST');
  await page.getByTestId('input-api-url').fill(url);
  await page.getByTestId('input-api-headers').fill(JSON.stringify({
    'Content-Type': 'application/json',
    'X-Trace': 'reviewed-header',
  }));
  await page.getByTestId('input-api-body').fill('{"name":"reviewed-body"}');

  await page.getByTestId('button-api-review').click();
  await expect(page.getByTestId('dialog-api-review')).toBeVisible();
  await expect(page.getByTestId('text-api-preview-method')).toHaveText('POST');
  await expect(page.getByTestId('text-api-preview-url')).toHaveText(url);
  await expect(page.getByTestId('text-api-preview-body-content')).toHaveText('{"name":"reviewed-body"}');
  expect(requests).toHaveLength(0);

  await page.getByTestId('button-api-review-cancel').click();
  await expect(page.getByTestId('dialog-api-review')).toBeHidden();
  expect(requests).toHaveLength(0);

  await page.getByTestId('button-api-review').click();
  await expect(page.getByTestId('dialog-api-review')).toBeVisible();
  await page.getByTestId('button-api-confirm').click();

  await expect(page.getByTestId('text-api-status')).toHaveText('200 OK');
  await expect.poll(() => requests).toHaveLength(1);
  expect(requests[0]).toEqual({
    method: 'POST',
    url,
    headers: {
      accept: '*/*',
      'content-type': 'application/json',
      'x-trace': 'reviewed-header',
    },
    body: '{"name":"reviewed-body"}',
  });
});

test('reviewing a GET with editor text still sends no request body', async ({ page }) => {
  const url = 'https://api.example.test/v1/read-only';
  const requests = await captureApiRequests(page, 'https://api.example.test/');

  await openApiTester(page);
  await page.getByTestId('select-api-method').selectOption('GET');
  await page.getByTestId('input-api-url').fill(url);
  await page.getByTestId('input-api-headers').fill(JSON.stringify({
    Accept: 'application/json',
    'X-Read': 'reviewed-get',
  }));
  await page.getByTestId('input-api-body').fill('editor text that must not be sent');

  await page.getByTestId('button-api-review').click();
  await expect(page.getByTestId('dialog-api-review')).toBeVisible();
  await expect(page.getByTestId('text-api-preview-body')).toContainText('No body will be sent');
  expect(requests).toHaveLength(0);

  await page.getByTestId('button-api-confirm').click();

  await expect(page.getByTestId('text-api-status')).toHaveText('200 OK');
  await expect.poll(() => requests).toHaveLength(1);
  expect(requests[0]).toEqual({
    method: 'GET',
    url,
    headers: {
      accept: 'application/json',
      'x-read': 'reviewed-get',
    },
    body: null,
  });
});
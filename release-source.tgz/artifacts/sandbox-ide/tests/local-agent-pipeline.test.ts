import assert from 'node:assert/strict';
import test from 'node:test';
import { buildPromptContext } from '../src/lib/ai/promptContext.ts';
import { applyEditProposal, createHunks, type EditProposal } from '../src/lib/ai/editProposal.ts';
import { LocalModelError, OllamaLocalModelClient } from '../src/lib/ai/localModelClient.ts';
import { runAgentPipeline } from '../src/lib/ai/orchestrator.ts';
import { routeRequest } from '../src/lib/ai/router.ts';
import type {
  LocalModelClient,
  LocalModelRequest,
  LocalModelResponse,
  WorkspaceContext,
} from '../src/lib/ai/types.ts';

const context: WorkspaceContext = {
  activeFile: 'src/App.tsx',
  activeContent: 'export default function App() {}',
  files: [
    { path: 'src/App.tsx', content: 'export default function App() {}', kind: 'code' },
    { path: 'src/api.ts', content: 'export const api = () => fetch("/api");', kind: 'code' },
  ],
  previewState: 'idle',
  terminalOutput: 'No diagnostics.',
};

class FakeLocalModelClient implements LocalModelClient {
  model = 'test-local';
  requests: LocalModelRequest[] = [];

  async chat(request: LocalModelRequest): Promise<LocalModelResponse> {
    this.requests.push(request);
    return {
      content: `Response ${this.requests.length}`,
      model: this.model,
      done: true,
    };
  }
}

test('routes specialist requests and broad reviews deterministically', () => {
  assert.equal(routeRequest({ message: 'Fix this API error', context }).primary, 'pulse');
  assert.equal(routeRequest({ message: 'Improve the responsive UI', context }).primary, 'pixel');
  assert.equal(routeRequest({ message: 'Review the whole workspace', context }).pipeline.join(','), 'nova,pixel,core,pulse,shield');
});

test('includes bounded related file context', () => {
  const prompt = buildPromptContext(context);
  assert.match(prompt, /--- src\/api\.ts \(code\) ---/);
  assert.match(prompt, /fetch\("\/api"\)/);
  assert.match(prompt, /--- end src\/api\.ts ---/);
});

test('runs a full review in order and hands earlier results forward', async () => {
  const client = new FakeLocalModelClient();
  const result = await runAgentPipeline(
    { message: 'Review the whole workspace', context },
    client,
  );

  assert.deepEqual(
    result.results.map((agent) => agent.agent),
    ['nova', 'pixel', 'core', 'pulse', 'shield'],
  );
  assert.equal(client.requests.length, 5);
  assert.match(client.requests[1].messages[1].content, /Nova/);
  assert.match(result.content, /### Shield/);
});

test('applies only approved edit hunks and refuses stale proposals', () => {
  const original = [
    'const first = "old";',
    'const keepOne = "exact";',
    'const second = "old";',
    'const keepTwo = "exact";',
    'const third = "old";',
    'const keepThree = "exact";',
  ].join('\n');
  const updated = [
    'const first = "new";',
    'const firstDetail = "inserted";',
    'const keepOne = "exact";',
    'const second = "new";',
    'const keepTwo = "exact";',
    'const keepThree = "exact";',
  ].join('\n');
  const untouched = '# Preserve this file byte-for-byte.\r\n\nNo hidden changes.';
  const proposal: EditProposal = {
    summary: 'Update three independent values.',
    changes: [{
      path: 'src/App.tsx',
      original,
      updated,
      hunks: createHunks(original, updated, 'src/App.tsx'),
    }],
  };
  assert.equal(proposal.changes[0].hunks.length, 3);

  const workspaceFiles = { 'src/App.tsx': original, 'README.md': untouched };
  const acceptedAll = applyEditProposal(workspaceFiles, proposal);
  assert.equal(acceptedAll.kind, 'applied');
  if (acceptedAll.kind === 'applied') {
    assert.equal(acceptedAll.hunkCount, 3);
    assert.equal(acceptedAll.files['src/App.tsx'], updated);
    assert.equal(acceptedAll.files['README.md'], untouched);
  }

  const rejectedAllProposal: EditProposal = {
    ...proposal,
    changes: proposal.changes.map((change) => ({
      ...change,
      hunks: change.hunks.map((hunk) => ({ ...hunk, selected: false })),
    })),
  };
  const rejectedAll = applyEditProposal(workspaceFiles, rejectedAllProposal);
  assert.deepEqual(rejectedAll, { kind: 'no-selection' });
  assert.equal(workspaceFiles['src/App.tsx'], original);
  assert.equal(workspaceFiles['README.md'], untouched);

  const acceptedOneProposal: EditProposal = {
    ...proposal,
    changes: proposal.changes.map((change) => ({
      ...change,
      hunks: change.hunks.map((hunk, index) => ({ ...hunk, selected: index === 1 })),
    })),
  };
  const acceptedOne = applyEditProposal(workspaceFiles, acceptedOneProposal);
  assert.equal(acceptedOne.kind, 'applied');
  if (acceptedOne.kind === 'applied') {
    assert.equal(acceptedOne.hunkCount, 1);
    assert.equal(acceptedOne.files['src/App.tsx'], [
      'const first = "old";',
      'const keepOne = "exact";',
      'const second = "new";',
      'const keepTwo = "exact";',
      'const third = "old";',
      'const keepThree = "exact";',
    ].join('\n'));
    assert.equal(acceptedOne.files['README.md'], untouched);
  }

  const changedWhileOpen = {
    ...workspaceFiles,
    'src/App.tsx': original.replace('const keepTwo = "exact";', 'const keepTwo = "builder work";'),
  };
  const stale = applyEditProposal(changedWhileOpen, proposal);
  assert.deepEqual(stale, { kind: 'stale', paths: ['src/App.tsx'] });
  assert.equal(changedWhileOpen['src/App.tsx'], original.replace('const keepTwo = "exact";', 'const keepTwo = "builder work";'));
  assert.equal(changedWhileOpen['README.md'], untouched);
});

test('keeps CRLF proposal hunks independent and preserves unselected bytes', () => {
  const original = [
    'const first = "old";',
    'const keepOne = "exact";',
    'const second = "old";',
    'const keepTwo = "exact";',
    'const third = "old";',
    'const keepThree = "exact";',
  ].join('\r\n');
  const updated = [
    'const first = "new";',
    'const keepOne = "exact";',
    'const second = "new";',
    'const keepTwo = "exact";',
    'const third = "new";',
    'const keepThree = "exact";',
  ].join('\n');
  const hunks = createHunks(original, updated, 'src/windows.ts');
  assert.equal(hunks.length, 3);

  const proposal: EditProposal = {
    summary: 'Update three independent values.',
    changes: [{
      path: 'src/windows.ts',
      original,
      updated,
      hunks: hunks.map((hunk, index) => ({ ...hunk, selected: index === 1 })),
    }],
  };
  const workspaceFiles = { 'src/windows.ts': original };
  const acceptedOne = applyEditProposal(workspaceFiles, proposal);
  assert.equal(acceptedOne.kind, 'applied');
  if (acceptedOne.kind === 'applied') {
    assert.equal(acceptedOne.hunkCount, 1);
    assert.equal(
      acceptedOne.files['src/windows.ts'],
      original.replace('const second = "old";', 'const second = "new";'),
    );
  }

  const changedWhileOpen = {
    'src/windows.ts': original.replace('const keepTwo = "exact";', 'const keepTwo = "builder work";'),
  };
  const stale = applyEditProposal(changedWhileOpen, proposal);
  assert.deepEqual(stale, { kind: 'stale', paths: ['src/windows.ts'] });
  assert.equal(
    changedWhileOpen['src/windows.ts'],
    original.replace('const keepTwo = "exact";', 'const keepTwo = "builder work";'),
  );
});

test('parses successful and failing Ollama responses', async () => {
  const originalFetch = globalThis.fetch;
  const client = new OllamaLocalModelClient();

  try {
    globalThis.fetch = async () => new Response(JSON.stringify({
      model: 'qwen2.5-coder',
      message: { content: 'Local answer' },
      done: true,
    }), { status: 200 });
    const success = await client.chat({ messages: [{ role: 'user', content: 'Hello' }] });
    assert.equal(success.content, 'Local answer');

    globalThis.fetch = async () => new Response('model not found', { status: 404 });
    await assert.rejects(
      client.chat({ messages: [{ role: 'user', content: 'Hello' }] }),
      (error: unknown) => error instanceof LocalModelError && error.code === 'unavailable',
    );

    globalThis.fetch = async () => new Response(JSON.stringify({ message: {} }), { status: 200 });
    await assert.rejects(
      client.chat({ messages: [{ role: 'user', content: 'Hello' }] }),
      (error: unknown) => error instanceof LocalModelError && error.code === 'invalid-response',
    );

    globalThis.fetch = async (_input, init) => new Promise<Response>((_resolve, reject) => {
      init?.signal?.addEventListener('abort', () => reject(new DOMException('Aborted', 'AbortError')));
    });
    const controller = new AbortController();
    const abortedRequest = client.chat({
      messages: [{ role: 'user', content: 'Hello' }],
      signal: controller.signal,
    });
    controller.abort();
    await assert.rejects(
      abortedRequest,
      (error: unknown) => error instanceof LocalModelError && error.code === 'unavailable',
    );
  } finally {
    globalThis.fetch = originalFetch;
  }
});
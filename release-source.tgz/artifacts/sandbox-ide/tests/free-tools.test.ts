import assert from 'node:assert/strict';
import test from 'node:test';
import React from 'react';
import { renderToStaticMarkup } from 'react-dom/server';
import { ToolWorkspace } from '../src/components/ToolWorkspace.tsx';
import {
  API_SAFETY_NOTICE,
  createApiRequestReview,
  buildApiRequestPreview,
  buildApiRequestInit,
  decodeJwt,
  findRegexMatches,
  formatJson,
  formatSql,
  optimizeSvg,
  parseApiHeaders,
  sendReviewedApiRequest,
  validateApiUrl,
} from '../src/lib/freeTools.ts';

function encodeBase64Url(value: string) {
  return Buffer.from(value, 'utf8').toString('base64')
    .replace(/\+/g, '-')
    .replace(/\//g, '_')
    .replace(/=+$/g, '');
}

test('JSON formatter pretty-prints valid JSON', () => {
  assert.equal(
    formatJson('{"name":"Lana","enabled":true,"nested":{"count":2}}'),
    '{\n  "name": "Lana",\n  "enabled": true,\n  "nested": {\n    "count": 2\n  }\n}',
  );
});

test('JSON formatter rejects blank and malformed input with clear errors', () => {
  assert.throws(
    () => formatJson('   '),
    { message: 'Paste JSON into the input area before formatting.' },
  );
  assert.throws(() => formatJson('{"name":}'), SyntaxError);
});

test('SQL formatter preserves quoted literals and formats multi-word clauses', () => {
  const input = "SELECT u.id, 'ORDER BY ignored' AS label FROM users AS u INNER JOIN teams t ON t.id = u.team_id WHERE u.name = 'O''Reilly' ORDER BY u.id DESC";
  const formatted = formatSql(input);

  assert.equal(
    formatted,
    [
      "SELECT  u.id, 'ORDER BY ignored' AS label",
      'FROM  users AS u',
      'INNER JOIN  teams t',
      'ON  t.id = u.team_id',
      "WHERE  u.name = 'O''Reilly'",
      'ORDER BY  u.id DESC',
    ].join('\n'),
  );
  assert.equal(formatSql(' \n\t '), '');
});

test('SVG optimizer removes removable markup and whitespace', () => {
  assert.equal(
    optimizeSvg('<?xml version="1.0"?>\n<!-- icon -->\n<svg viewBox="0 0 10 10"> \n <path d="M0 0"/> \n</svg>'),
    '<svg viewBox="0 0 10 10"><path d="M0 0"/></svg>',
  );
});

test('SVG optimizer rejects blank and incomplete documents', () => {
  assert.throws(
    () => optimizeSvg(''),
    { message: 'Paste SVG markup into the input area before optimizing.' },
  );
  assert.throws(
    () => optimizeSvg('<svg><path /></svgx>'),
    { message: 'This does not look like a complete SVG document. Include an opening and closing <svg> tag.' },
  );
});

test('JWT decoder reads URL-safe header and payload JSON', () => {
  const header = { alg: 'HS256', typ: 'JWT' };
  const payload = { sub: 'user-42', name: 'Zoë', admin: false };
  const token = [
    encodeBase64Url(JSON.stringify(header)),
    encodeBase64Url(JSON.stringify(payload)),
    'signature',
  ].join('.');

  assert.deepEqual(decodeJwt(token), { header, payload });
});

test('JWT decoder rejects missing segments and invalid JSON', () => {
  assert.throws(
    () => decodeJwt('one.two'),
    { message: 'Must have exactly 3 parts separated by dots.' },
  );
  assert.throws(
    () => decodeJwt(`${encodeBase64Url('{}')}.${encodeBase64Url('not json')}.signature`),
    SyntaxError,
  );
});

test('regex visualizer returns global and single matches with indexes', () => {
  assert.deepEqual(
    findRegexMatches('cat', 'g', 'cat scat catalog'),
    [
      { match: 'cat', index: 0 },
      { match: 'cat', index: 5 },
      { match: 'cat', index: 9 },
    ],
  );
  assert.deepEqual(
    findRegexMatches('cat', '', 'cat scat'),
    [{ match: 'cat', index: 0 }],
  );
  assert.deepEqual(findRegexMatches('dog', 'g', 'cat'), []);
});

test('regex visualizer rejects blank and invalid patterns', () => {
  assert.throws(
    () => findRegexMatches('', 'g', 'anything'),
    { message: 'Enter a pattern before testing it.' },
  );
  assert.throws(() => findRegexMatches('[', 'g', 'anything'), SyntaxError);
});

test('API Tester renders its browser-safety notice', () => {
  const markup = renderToStaticMarkup(
    React.createElement(ToolWorkspace, {
      toolId: 'api-tester',
      onBack: () => undefined,
      onChooseTool: () => undefined,
    }),
  );

  assert.match(markup, /data-testid="notice-api-safety"/);
  assert.match(markup, new RegExp(API_SAFETY_NOTICE.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')));
});

test('API Tester accepts HTTP(S) URLs and rejects other protocols', () => {
  assert.equal(validateApiUrl(' https://api.example.com/v1/users ').toString(), 'https://api.example.com/v1/users');
  assert.equal(validateApiUrl('http://localhost:3000/health').protocol, 'http:');
  assert.throws(
    () => validateApiUrl('ftp://files.example.com/data'),
    { message: 'Only HTTP and HTTPS URLs are supported.' },
  );
  assert.throws(
    () => validateApiUrl('javascript:alert(1)'),
    { message: 'Only HTTP and HTTPS URLs are supported.' },
  );
  assert.throws(() => validateApiUrl('not a URL'), TypeError);
});

test('API request headers reject malformed and non-object JSON clearly', () => {
  assert.deepEqual(parseApiHeaders('{"Accept":"application/json"}'), { Accept: 'application/json' });
  assert.deepEqual(parseApiHeaders(''), {});
  assert.throws(
    () => parseApiHeaders('{"Accept":}'),
    { message: 'Headers must be valid JSON.' },
  );
  assert.throws(
    () => parseApiHeaders('["Accept", "application/json"]'),
    { message: 'Headers must be a JSON object.' },
  );
  assert.throws(
    () => parseApiHeaders('"Accept: application/json"'),
    { message: 'Headers must be a JSON object.' },
  );
});

test('API request setup omits GET and HEAD bodies', () => {
  const getRequest = buildApiRequestInit('GET', '{}', '{"ignored":true}');
  const headRequest = buildApiRequestInit('HEAD', '{}', '{"ignored":true}');
  const postRequest = buildApiRequestInit('POST', '{}', '{"sent":true}');

  assert.equal('body' in getRequest, false);
  assert.equal('body' in headRequest, false);
  assert.equal(postRequest.body, '{"sent":true}');
});

test('API request preview resolves the request and masks sensitive headers', () => {
  const preview = buildApiRequestPreview(
    'post',
    ' https://api.example.com/v1/users ',
    '{"Accept":"application/json","Authorization":"Bearer private-token","X-Trace":"safe"}',
    '{"name":"Lana"}',
  );

  assert.equal(preview.method, 'POST');
  assert.equal(preview.url, 'https://api.example.com/v1/users');
  assert.deepEqual(preview.headers, [
    { name: 'Accept', value: 'application/json', sensitive: false },
    { name: 'Authorization', value: 'Bearer private-token', sensitive: true },
    { name: 'X-Trace', value: 'safe', sensitive: false },
  ]);
  assert.deepEqual(preview.body, {
    willSend: true,
    characterCount: 15,
    content: '{"name":"Lana"}',
  });
});

test('API request preview clearly reports no body for GET and HEAD', () => {
  const getPreview = buildApiRequestPreview('GET', 'https://api.example.com', '{}', '{"ignored":true}');
  const headPreview = buildApiRequestPreview('HEAD', 'https://api.example.com', '{}', '{"ignored":true}');

  assert.deepEqual(getPreview.body, { willSend: false, characterCount: 0, content: null });
  assert.deepEqual(headPreview.body, { willSend: false, characterCount: 0, content: null });
});

test('API request review makes no request until confirmation and sends the reviewed snapshot', async () => {
  const review = createApiRequestReview(
    'POST',
    'https://api.example.com/v1/users',
    '{"Content-Type":"application/json","X-Trace":"safe"}',
    '{"name":"Lana"}',
  );
  const calls: Array<{ url: string; init?: RequestInit }> = [];

  assert.equal(calls.length, 0);
  await sendReviewedApiRequest(review, async (input, init) => {
    calls.push({ url: input.toString(), init });
    return new Response(null, { status: 204 });
  });

  assert.equal(calls.length, 1);
  assert.equal(calls[0].url, review.preview.url);
  assert.equal(calls[0].init?.method, review.preview.method);
  assert.deepEqual(calls[0].init?.headers, {
    'Content-Type': 'application/json',
    'X-Trace': 'safe',
  });
  assert.equal(calls[0].init?.body, review.preview.body.content);
});
import assert from 'node:assert/strict';
import test from 'node:test';
import { createFactoryPlan, runAgentPipeline } from '../src/lib/ai_factory/index.ts';
import type {
  AgentRequest,
  LocalModelClient,
  LocalModelRequest,
  LocalModelResponse,
} from '../src/lib/ai/types.ts';

const context: AgentRequest['context'] = {
  activeFile: 'src/App.tsx',
  activeContent: 'export function App() { return null; }',
  files: [
    { path: 'src/App.tsx', content: 'export function App() { return null; }', kind: 'code' },
  ],
  previewState: 'idle',
};

class FactoryFixtureClient implements LocalModelClient {
  readonly model = 'factory-fixture';
  readonly requests: LocalModelRequest[] = [];

  async chat(request: LocalModelRequest): Promise<LocalModelResponse> {
    this.requests.push(request);
    const system = request.messages.find((message) => message.role === 'system')?.content ?? '';
    return {
      content: system.match(/^You are ([^,]+)/)?.[1] ?? 'Unknown',
      model: this.model,
      done: true,
    };
  }
}

test('splits the existing agents across the four factory workers', () => {
  const plan = createFactoryPlan({
    message: 'Review the whole workspace',
    context,
  });

  assert.deepEqual(
    plan.tasks.map(({ agentId, workerId, phase, parallel }) => [agentId, workerId, phase, parallel]),
    [
      ['nova', 'llama8b_devops', 0, false],
      ['pixel', 'phi3_ui', 1, true],
      ['core', 'qwen_tiny_backend', 1, true],
      ['pulse', 'llama8b_devops', 1, true],
      ['shield', 'mistral7b_tools', 2, false],
    ],
  );
  assert.deepEqual(plan.tasks[0].dependsOn, []);
  assert.deepEqual(plan.tasks[2].dependsOn, ['nova']);
  assert.deepEqual(plan.tasks[4].dependsOn, ['pixel', 'core', 'pulse']);
});

test('treats a customer project brief as a factory request', () => {
  const plan = createFactoryPlan({
    message: 'Build a scheduling app for a small clinic',
    context,
  });

  assert.deepEqual(plan.route.pipeline, ['nova', 'pixel', 'core', 'pulse', 'shield']);
  assert.match(plan.route.reason, /project brief/);
});

test('routes developer utility requests to the tools worker', () => {
  const plan = createFactoryPlan({
    message: 'Format this JSON and decode the JWT',
    context,
  });

  assert.equal(plan.route.primary, 'shield');
  assert.equal(plan.tasks[0].workerId, 'mistral7b_tools');
});

test('passes the assigned worker context to each existing AI', async () => {
  const client = new FactoryFixtureClient();
  const result = await runAgentPipeline({
    message: 'Improve the responsive UI',
    context,
  }, client);

  assert.equal(result.results[0].agent, 'pixel');
  assert.equal(result.results[0].workerId, 'phi3_ui');
  assert.match(client.requests[0].messages[0].content, /UI Worker/);
  assert.match(client.requests[0].messages[0].content, /Frontend and interaction work/);
});

test('runs independent specialist roles in parallel before final validation', async () => {
  let active = 0;
  let maximumActive = 0;
  const client: LocalModelClient = {
    model: 'parallel-fixture',
    async chat(request: LocalModelRequest): Promise<LocalModelResponse> {
      active += 1;
      maximumActive = Math.max(maximumActive, active);
      await new Promise((resolve) => setTimeout(resolve, 5));
      active -= 1;
      const system = request.messages.find((message) => message.role === 'system')?.content ?? '';
      return {
        content: system.match(/^You are ([^,]+)/)?.[1] ?? 'Unknown',
        model: 'parallel-fixture',
        done: true,
      };
    },
  };

  const result = await runAgentPipeline({
    message: 'Review the whole workspace',
    context,
  }, client);

  assert.equal(maximumActive, 3);
  assert.deepEqual(result.results.map(({ agent }) => agent), [
    'nova',
    'pixel',
    'core',
    'pulse',
    'shield',
  ]);
});
import assert from 'node:assert/strict';
import test from 'node:test';
import {
  buildSecurityReview,
  shouldInvalidateReleasePreflight,
} from '../src/lib/securityReview.ts';

test('flags outbound request and credential-like source signals without exposing values', () => {
  const secretValue = 'super-private-value';
  const review = buildSecurityReview({
    files: [
      {
        path: 'src/client.ts',
        content: `fetch('https://api.example.test');\nconst apiKey = '${secretValue}';`,
      },
    ],
    saveState: 'saved',
    previewState: 'ready',
    releaseState: 'idle',
    connections: [],
  });

  const requestCheck = review.checks.find((check) => check.id === 'requests');
  const credentialCheck = review.checks.find((check) => check.id === 'credentials');

  assert.equal(requestCheck?.status, 'attention');
  assert.deepEqual(requestCheck?.evidence, ['src/client.ts · fetch']);
  assert.equal(credentialCheck?.status, 'attention');
  assert.deepEqual(credentialCheck?.evidence, ['src/client.ts']);
  assert.doesNotMatch(JSON.stringify(review), new RegExp(secretValue));
  assert.equal(review.securityReady, false);
});

test('allows reviewed request code and requires a fresh approval after source edits', () => {
  const reviewed = buildSecurityReview({
    files: [{ path: 'src/client.ts', content: "fetch('https://api.example.test');" }],
    saveState: 'saved',
    previewState: 'ready',
    releaseState: 'idle',
    connections: [],
    requestReviewApproved: true,
  });
  const afterEdit = buildSecurityReview({
    files: [{ path: 'src/client.ts', content: "fetch('https://api.example.test/v2');" }],
    saveState: 'saved',
    previewState: 'ready',
    releaseState: 'idle',
    connections: [],
    requestReviewApproved: false,
  });

  assert.equal(reviewed.checks.find((check) => check.id === 'requests')?.status, 'ready');
  assert.equal(reviewed.securityReady, true);
  assert.equal(afterEdit.checks.find((check) => check.id === 'requests')?.status, 'attention');
  assert.equal(afterEdit.securityReady, false);
});

test('does not block release for credential guidance in documentation', () => {
  const review = buildSecurityReview({
    files: [{ path: 'README.md', content: 'Set your API key or password in your deployment secret manager.' }],
    saveState: 'saved',
    previewState: 'ready',
    releaseState: 'ready',
    connections: [],
  });

  assert.equal(review.checks.find((check) => check.id === 'requests')?.status, 'ready');
  assert.equal(review.checks.find((check) => check.id === 'credentials')?.status, 'ready');
  assert.equal(review.publishReady, true);
});

test('reports a publish-ready local workspace when review checks are complete', () => {
  const review = buildSecurityReview({
    files: [{ path: 'src/App.tsx', content: 'export default function App() { return null; }' }],
    saveState: 'saved',
    previewState: 'ready',
    releaseState: 'ready',
    connections: [],
  });

  assert.equal(review.securityReady, true);
  assert.equal(review.publishReady, true);
  assert.equal(review.issues.length, 0);
  assert.equal(review.checks.find((check) => check.id === 'requests')?.status, 'ready');
  assert.equal(review.checks.find((check) => check.id === 'credentials')?.status, 'ready');
});

test('blocks release until provider credential status finishes loading', () => {
  const review = buildSecurityReview({
    files: [{ path: 'src/App.tsx', content: 'export default function App() { return null; }' }],
    saveState: 'saved',
    previewState: 'ready',
    releaseState: 'idle',
    connections: [],
    connectionsLoading: true,
  });

  assert.equal(review.securityReady, false);
  assert.equal(review.publishReady, false);
  assert.equal(review.checks.find((check) => check.id === 'credentials')?.status, 'checking');
  assert.deepEqual(review.issues.map((issue) => issue.id), ['credentials']);
});

test('blocks release when provider credential status is unavailable', () => {
  const review = buildSecurityReview({
    files: [{ path: 'src/App.tsx', content: 'export default function App() { return null; }' }],
    saveState: 'saved',
    previewState: 'ready',
    releaseState: 'idle',
    connections: [],
    connectionsUnavailable: true,
  });

  assert.equal(review.securityReady, false);
  assert.equal(review.publishReady, false);
  assert.equal(review.checks.find((check) => check.id === 'credentials')?.status, 'attention');
  assert.match(review.checks.find((check) => check.id === 'credentials')?.summary ?? '', /Could not load/);
  assert.deepEqual(review.issues.map((issue) => issue.id), ['credentials']);
});

test('invalidates an in-flight or completed preflight when credentials become unknown', () => {
  const securityUnavailable = buildSecurityReview({
    files: [{ path: 'src/App.tsx', content: 'export default function App() { return null; }' }],
    saveState: 'saved',
    previewState: 'ready',
    releaseState: 'ready',
    connections: [],
    connectionsUnavailable: true,
  });

  assert.equal(shouldInvalidateReleasePreflight('building', securityUnavailable.securityReady), true);
  assert.equal(shouldInvalidateReleasePreflight('ready', securityUnavailable.securityReady), true);
  assert.equal(shouldInvalidateReleasePreflight('idle', securityUnavailable.securityReady), false);
});

test('explains that an unchecked preview and unsaved files block release', () => {
  const review = buildSecurityReview({
    files: [{ path: 'src/App.tsx', content: 'export default function App() { return null; }' }],
    saveState: 'error',
    previewState: 'idle',
    releaseState: 'idle',
    connections: [],
  });

  assert.deepEqual(
    review.issues.map((issue) => issue.id).sort(),
    ['preview', 'save'],
  );
  assert.equal(review.publishReady, false);
  assert.match(
    review.checks.find((check) => check.id === 'publish')?.detail ?? '',
    /Resolve the highlighted checks/,
  );
});
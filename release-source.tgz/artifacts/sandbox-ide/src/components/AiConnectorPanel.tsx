import { useMemo, useState } from 'react';
import { useAuth } from '@clerk/react';
import { useQueryClient } from '@tanstack/react-query';
import {
  Check,
  Cloud,
  Eye,
  EyeOff,
  KeyRound,
  LoaderCircle,
  LockKeyhole,
  Trash2,
  Wifi,
  WifiOff,
} from 'lucide-react';
import {
  AiProvider,
  getListAiConnectionsQueryKey,
  useListAiConnections,
  useRemoveAiConnection,
  useSaveAiConnection,
  useTestAiConnection,
} from '@workspace/api-client-react';

const providerCopy: Record<AiProvider, {
  name: string;
  description: string;
  accountLabel: string;
  accountUrl: string;
  guidance: string;
}> = {
  openai: {
    name: 'OpenAI',
    description: 'GPT models for coding, analysis, and everyday assistance.',
    accountLabel: 'OpenAI API key',
    accountUrl: 'https://platform.openai.com/api-keys',
    guidance: 'Create an API key in the OpenAI developer platform. A ChatGPT consumer subscription is separate and does not include API access or credits.',
  },
  anthropic: {
    name: 'Anthropic',
    description: 'Claude models for careful reasoning and long-context work.',
    accountLabel: 'Anthropic API key',
    accountUrl: 'https://console.anthropic.com/settings/keys',
    guidance: 'Use a key from the Anthropic Console with API billing enabled. A Claude.ai consumer subscription is separate and does not grant API access.',
  },
  xai: {
    name: 'xAI',
    description: 'Grok models through your own xAI developer account.',
    accountLabel: 'xAI API key',
    accountUrl: 'https://console.x.ai/',
    guidance: 'Create a key in the xAI developer console. A Grok or X consumer subscription is not an API account and cannot be used here.',
  },
};

const providers = [AiProvider.openai, AiProvider.anthropic, AiProvider.xai] as AiProvider[];

function errorFrom(error: unknown) {
  if (typeof error === 'object' && error !== null && 'data' in error) {
    const data = (error as { data?: unknown }).data;
    if (typeof data === 'object' && data !== null && 'error' in data && typeof data.error === 'string') return data.error;
  }
  return error instanceof Error ? error.message : 'Something went wrong. Try again.';
}

export function AiConnectorPanel({
  isSignedIn,
  selectedProvider,
  onSelectProvider,
  variant = 'workspace',
}: {
  isSignedIn: boolean;
  selectedProvider: AiProvider | 'local';
  onSelectProvider: (provider: AiProvider | 'local') => void;
  variant?: 'home' | 'workspace';
}) {
  const { userId } = useAuth();
  const queryClient = useQueryClient();
  const connectionsQueryKey = useMemo(
    () => [...getListAiConnectionsQueryKey(), userId ?? 'signed-out'],
    [userId],
  );
  const { data: connections = [], isLoading } = useListAiConnections({
    query: { enabled: isSignedIn, retry: false, queryKey: connectionsQueryKey },
  });
  const saveConnection = useSaveAiConnection();
  const testConnection = useTestAiConnection();
  const removeConnection = useRemoveAiConnection();
  const [openProvider, setOpenProvider] = useState<AiProvider | null>(null);
  const [apiKey, setApiKey] = useState('');
  const [showKey, setShowKey] = useState(false);
  const [notice, setNotice] = useState('');

  const connectionByProvider = useMemo(
    () => new Map(connections.map((connection) => [connection.provider, connection])),
    [connections],
  );

  const openEntry = (provider: AiProvider) => {
    setOpenProvider(provider);
    setApiKey('');
    setShowKey(false);
    setNotice('');
  };

  const save = async (provider: AiProvider) => {
    if (apiKey.trim().length < 12) {
      setNotice('Enter a valid API key. It is encrypted before it is stored.');
      return;
    }
    setNotice('');
    try {
      await saveConnection.mutateAsync({ provider, data: { apiKey: apiKey.trim() } });
      await queryClient.invalidateQueries({ queryKey: connectionsQueryKey });
      setApiKey('');
      setOpenProvider(null);
      setNotice(`${providerCopy[provider].name} connected. Test it before sending cloud requests.`);
    } catch (error) {
      setNotice(errorFrom(error));
    }
  };

  const test = async (provider: AiProvider) => {
    setNotice('');
    try {
      const result = await testConnection.mutateAsync({ provider });
      setNotice(result.message);
    } catch (error) {
      setNotice(errorFrom(error));
    } finally {
      await queryClient.invalidateQueries({ queryKey: connectionsQueryKey });
    }
  };

  const remove = async (provider: AiProvider) => {
    setNotice('');
    try {
      await removeConnection.mutateAsync({ provider });
      await queryClient.invalidateQueries({ queryKey: connectionsQueryKey });
      if (selectedProvider === provider) onSelectProvider('local');
      setNotice(`${providerCopy[provider].name} removed. Its API key is no longer stored.`);
    } catch (error) {
      setNotice(errorFrom(error));
    }
  };

  return (
    <section className={`ai-connector-panel ${variant === 'home' ? 'ai-connector-panel-home' : ''}`} data-testid="panel-ai-connectors">
      <div className="ai-connector-intro">
        <div>
          <div className="eyebrow"><Cloud size={12} /> Cloud AI / your account</div>
          <h2>Local by default. Cloud when you choose.</h2>
          <p>Ollama runs locally and stays the default. Add your own provider API account only when you want cloud inference; LANA DEV never pays for or shares these requests.</p>
        </div>
        <div className="ai-connector-policy"><LockKeyhole size={13} /> Keys stay server-side and are never shown again.</div>
      </div>

      <div className="ai-mode-choice" role="group" aria-label="AI request mode">
        <button className={selectedProvider === 'local' ? 'active' : ''} onClick={() => onSelectProvider('local')} data-testid="button-ai-mode-local">
          <WifiOff size={14} /><span><strong>Local only</strong><small>Ollama on this device</small></span>
        </button>
        {providers.map((provider) => {
          const connection = connectionByProvider.get(provider);
          const available = connection?.state === 'connected';
          return (
            <button
              className={selectedProvider === provider ? 'active' : ''}
              onClick={() => available ? onSelectProvider(provider) : openEntry(provider)}
              key={provider}
              disabled={!isSignedIn && selectedProvider !== provider}
              data-testid={`button-ai-mode-${provider}`}
            >
              <Cloud size={14} /><span><strong>{providerCopy[provider].name}</strong><small>{available ? 'Connected · use cloud' : 'Not connected'}</small></span>
            </button>
          );
        })}
      </div>

      {!isSignedIn ? (
        <div className="ai-connector-signin" data-testid="state-ai-signin">
          <KeyRound size={18} />
          <div><strong>Sign in to connect a personal API account.</strong><p>Your keys belong to you and are isolated from every other workspace.</p></div>
        </div>
      ) : isLoading ? (
        <div className="ai-connector-loading" data-testid="state-ai-loading"><LoaderCircle size={16} className="animate-spin" /> Loading connection states…</div>
      ) : (
        <div className="ai-provider-grid">
          {providers.map((provider) => {
            const connection = connectionByProvider.get(provider);
            const copy = providerCopy[provider];
            const isSaving = saveConnection.isPending && saveConnection.variables?.provider === provider;
            const isTesting = testConnection.isPending && testConnection.variables?.provider === provider;
            const isRemoving = removeConnection.isPending && removeConnection.variables?.provider === provider;
            return (
              <article className={`ai-provider-card ${connection?.state ?? 'not_configured'}`} key={provider} data-testid={`card-ai-provider-${provider}`}>
                <div className="ai-provider-card-head">
                  <div><span className="ai-provider-mark">{copy.name.slice(0, 1)}</span><div><strong>{copy.name}</strong><small>{copy.description}</small></div></div>
                  <span className={`ai-provider-state ${connection?.state ?? 'not_configured'}`}>
                    {connection?.state === 'connected' ? <Check size={11} /> : connection?.state === 'error' ? <WifiOff size={11} /> : <Wifi size={11} />}
                    {connection?.state === 'connected' ? 'Connected' : connection?.state === 'error' ? 'Needs attention' : 'Not connected'}
                  </span>
                </div>
                {connection?.keyHint && <div className="ai-key-hint"><KeyRound size={12} /> {connection.keyHint} <span>encrypted storage</span></div>}
                {connection?.error && <div className="ai-provider-error" role="alert">{connection.error}</div>}
                {openProvider === provider ? (
                  <form className="ai-key-entry" onSubmit={(event) => { event.preventDefault(); void save(provider); }}>
                    <label htmlFor={`ai-key-${provider}`}>{copy.accountLabel}</label>
                    <div className="ai-key-input-wrap">
                      <input id={`ai-key-${provider}`} type={showKey ? 'text' : 'password'} value={apiKey} onChange={(event) => setApiKey(event.target.value)} placeholder="Paste your API key" autoComplete="off" spellCheck={false} data-testid={`input-ai-key-${provider}`} />
                      <button type="button" onClick={() => setShowKey((value) => !value)} aria-label={showKey ? 'Hide API key' : 'Show API key'}>{showKey ? <EyeOff size={14} /> : <Eye size={14} />}</button>
                    </div>
                    <p>{copy.guidance} <a href={copy.accountUrl} target="_blank" rel="noreferrer">Open provider console</a></p>
                    <div className="ai-card-actions"><button className="resource-button" type="submit" disabled={isSaving} data-testid={`button-save-ai-${provider}`}>{isSaving ? 'Saving…' : connection ? 'Replace key' : 'Connect account'} <Check size={13} /></button><button className="text-link-button" type="button" onClick={() => setOpenProvider(null)}>Cancel</button></div>
                  </form>
                ) : (
                  <div className="ai-card-actions">
                    <button className="resource-button secondary" onClick={() => openEntry(provider)} data-testid={`button-enter-ai-${provider}`}>{connection ? 'Replace key' : 'Add API key'} <KeyRound size={13} /></button>
                    {connection && <><button className="resource-button secondary" onClick={() => void test(provider)} disabled={isTesting} data-testid={`button-test-ai-${provider}`}>{isTesting ? 'Testing…' : 'Test connection'} <Wifi size={13} /></button><button className="ai-remove-button" onClick={() => void remove(provider)} disabled={isRemoving} aria-label={`Remove ${copy.name} connection`} data-testid={`button-remove-ai-${provider}`}><Trash2 size={14} /></button></>}
                  </div>
                )}
              </article>
            );
          })}
        </div>
      )}
      {notice && <div className="ai-connector-notice" role="status" data-testid="status-ai-connector">{notice}</div>}
    </section>
  );
}
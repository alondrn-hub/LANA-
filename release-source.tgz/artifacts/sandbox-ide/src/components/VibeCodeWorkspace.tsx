import React, { useEffect, useRef } from 'react';
import { 
  ArrowLeft, 
  Check, 
  ChevronRight,
  Code2, 
  MonitorPlay,
  Play,
  RotateCcw,
  Send, 
  Sparkles,
  Zap,
} from 'lucide-react';

export type ChatMessage = { 
  id: number; 
  role: 'you' | 'model'; 
  text: string; 
  agentLabel?: string 
};

export type VibeCodeWorkspaceProps = {
  messages: ChatMessage[];
  chatDraft: string;
  isModelThinking: boolean;
  assistantStatusText: string;
  isModelAvailable: boolean;
  previewState: 'idle' | 'running' | 'ready' | 'error';
  onChatDraftChange: (draft: string) => void;
  onSubmitChat: () => void;
  onBack: () => void;
  onRunPreview: () => void;
};

export function VibeCodeWorkspace({
  messages,
  chatDraft,
  isModelThinking,
  assistantStatusText,
  isModelAvailable,
  previewState,
  onChatDraftChange,
  onSubmitChat,
  onBack,
  onRunPreview,
}: VibeCodeWorkspaceProps) {
  const streamRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (streamRef.current) {
      streamRef.current.scrollTop = streamRef.current.scrollHeight;
    }
  }, [messages, isModelThinking]);

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      onSubmitChat();
    }
  };

  const runLabel = previewState === 'running' ? 'Starting' : previewState === 'ready' ? 'Running' : 'Run';

  return (
    <div className="vibe-workspace">
      <div className="vibe-chat-zone">
        <header className="vibe-chat-header">
          <button 
            className="vibe-back-button" 
            onClick={onBack}
            data-testid="button-vibe-back"
          >
            <ArrowLeft size={14} /> Back
          </button>
          <div className="vibe-model-status" data-testid="status-vibe-model">
            <Sparkles size={12} className={isModelAvailable ? 'text-[#83cfb9]' : 'text-[#898471]'} />
            {assistantStatusText}
          </div>
        </header>

        <div className="vibe-chat-stream" ref={streamRef} data-testid="panel-vibe-chat-stream">
          {messages.map((msg) => (
            <div key={msg.id} className={`vibe-message ${msg.role}`} data-testid={`message-${msg.role}`}>
              {msg.role === 'model' && (
                <div className="vibe-message-label">
                  <Zap size={11} className="mr-1 inline -mt-0.5" /> 
                  {msg.agentLabel || 'Vibe Code'}
                </div>
              )}
              <div className="vibe-message-content">
                {msg.text.split('\n').map((line, i) => (
                  <p key={i}>{line}</p>
                ))}
              </div>
            </div>
          ))}
          {isModelThinking && (
            <div className="vibe-message model" data-testid="message-thinking">
              <div className="vibe-message-label">
                <Zap size={11} className="mr-1 inline -mt-0.5" /> 
                Vibe Code
              </div>
              <div className="vibe-message-content">
                <div className="flex gap-1 py-1">
                  <div className="vibe-dot-bounce" style={{ animationDelay: '0ms' }} />
                  <div className="vibe-dot-bounce" style={{ animationDelay: '150ms' }} />
                  <div className="vibe-dot-bounce" style={{ animationDelay: '300ms' }} />
                </div>
              </div>
            </div>
          )}
        </div>

        <div className="vibe-composer-zone">
          <div className="vibe-composer">
            <textarea
              className="vibe-chat-input"
              value={chatDraft}
              onChange={(e) => onChatDraftChange(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="Describe what you want to build..."
              disabled={isModelThinking || !isModelAvailable}
              data-testid="input-vibe-chat"
            />
            <div className="vibe-composer-actions">
              <span className="vibe-composer-hint">Press Enter to send</span>
              <button 
                className="vibe-send-button"
                onClick={onSubmitChat}
                disabled={!chatDraft.trim() || isModelThinking || !isModelAvailable}
                data-testid="button-vibe-send"
              >
                Send <Send size={12} className="ml-1" />
              </button>
            </div>
          </div>
        </div>
      </div>

      <div className="vibe-canvas-zone">
        <header className="vibe-canvas-header">
          <div className="flex items-center gap-4">
            <div className="vibe-canvas-title">
              <MonitorPlay size={14} className="text-[#9b6511]" />
              <span>Canvas</span>
            </div>
            <div className="flex items-center gap-1.5 text-[11px] font-mono text-[#898471]">
              <span>Preview</span>
              <ChevronRight size={11} />
              <span className="text-[#24283c]">Live</span>
            </div>
          </div>
          <div className="flex items-center gap-3">
             <div className={`preview-pill ${previewState === 'ready' ? 'running' : ''}`} data-testid="status-vibe-preview">
                <span className={`status-dot ${previewState === 'running' ? 'busy' : ''}`} />
                <span>{previewState === 'ready' ? 'Live' : previewState === 'running' ? 'Starting' : 'Idle'}</span>
              </div>
            <button 
              className="vibe-run-button" 
              onClick={onRunPreview}
              disabled={previewState === 'running'}
              data-testid="button-vibe-run"
            >
              <Play size={12} fill="currentColor" /> {runLabel}
            </button>
          </div>
        </header>

        <div className="vibe-canvas-body">
          <div className="vibe-canvas-progress">
             <div className="vibe-progress-step complete">
                <div className="vibe-progress-icon"><Check size={12} /></div>
                <div className="vibe-progress-text">Project initialized</div>
             </div>
             <div className="vibe-progress-step complete">
                <div className="vibe-progress-icon"><Check size={12} /></div>
                <div className="vibe-progress-text">Vite development server ready</div>
             </div>
             <div className={`vibe-progress-step ${previewState === 'ready' ? 'complete' : previewState === 'running' ? 'active' : ''}`}>
                <div className="vibe-progress-icon">
                  {previewState === 'ready' ? <Check size={12} /> : previewState === 'running' ? <RotateCcw size={12} className="animate-spin" /> : <div className="w-1.5 h-1.5 rounded-full bg-[#d5cec0]" />}
                </div>
                <div className="vibe-progress-text">Building frontend preview</div>
             </div>
          </div>
          
          <div className="vibe-canvas-browser">
             <div className="vibe-browser-chrome">
                <div className="flex gap-1.5">
                  <div className="browser-dot red" />
                  <div className="browser-dot yellow" />
                  <div className="browser-dot green" />
                </div>
                <div className="vibe-browser-address">
                  {previewState === 'ready' ? 'localhost:5173' : 'Server not running'}
                </div>
             </div>
             <div className="vibe-browser-viewport">
                {previewState === 'ready' ? (
                  <div className="vibe-preview-placeholder">
                    <Code2 size={32} className="text-[#d8d2c5] mb-4" />
                    <h3>Preview Ready</h3>
                    <p>The workspace is running. Ask the assistant to start building your components.</p>
                  </div>
                ) : (
                  <div className="vibe-preview-placeholder">
                     <MonitorPlay size={32} className="text-[#d8d2c5] mb-4" />
                     <h3>Preview Offline</h3>
                     <p>Click Run to start the development server.</p>
                  </div>
                )}
             </div>
          </div>
        </div>
      </div>
    </div>
  );
}

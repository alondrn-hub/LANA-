import { useEffect, useState } from 'react';
import { Sparkles, ArrowRight, Wrench, Terminal, Cpu, FileJson, Layout, Database, Code, Shield, Home, PanelsTopLeft, History, Plug2 } from 'lucide-react';
import { useAuth } from '@clerk/react';
import type { AiProvider } from '@workspace/api-client-react';
import { AiConnectorPanel } from './AiConnectorPanel';

export type HomeArea = 'home' | 'templates' | 'history' | 'connector';

interface LanaHomeProps {
  onOpenVibeCode: () => void;
  onOpenIDE: () => void;
  selectedTool: string;
  onSelectTool: (toolId: string) => void;
  activeArea: HomeArea;
  onNavigateArea: (area: HomeArea) => void;
  selectedAiProvider: AiProvider | 'local';
  onSelectAiProvider: (provider: AiProvider | 'local') => void;
}

const tools = [
  { id: 'api-tester', name: 'API Tester', desc: 'Send browser-safe HTTP requests and inspect the response.', icon: Database },
  { id: 'regex-vis', name: 'Regex Visualizer', desc: 'Test a pattern against text and inspect every match.', icon: Code },
  { id: 'jwt-decode', name: 'JWT Decoder', desc: 'Inspect token headers and payloads without uploading them.', icon: Shield },
  { id: 'json-format', name: 'JSON Formatter', desc: 'Format and validate JSON directly in your browser.', icon: FileJson },
  { id: 'sql-format', name: 'SQL Formatter', desc: 'Turn dense SQL into a readable, structured query.', icon: Layout },
  { id: 'svg-opt', name: 'SVG Optimizer', desc: 'Minify SVG markup before you ship it.', icon: Cpu },
];

const homeNavItems: Array<{
  id: HomeArea;
  label: string;
  description: string;
  icon: typeof Home;
}> = [
  { id: 'home', label: 'Home', description: 'Choose your path', icon: Home },
  { id: 'templates', label: 'Templates', description: 'Start from a pattern', icon: PanelsTopLeft },
  { id: 'history', label: 'App History', description: 'Recent workspaces', icon: History },
  { id: 'connector', label: 'Connector', description: 'Connect approved services', icon: Plug2 },
];

export function LanaHome({ onOpenVibeCode, onOpenIDE, selectedTool, onSelectTool, activeArea, onNavigateArea, selectedAiProvider, onSelectAiProvider }: LanaHomeProps) {
  const [mounted, setMounted] = useState(false);
  const nonHomeArea: Exclude<HomeArea, 'home'> | null =
    activeArea === 'templates' || activeArea === 'history' || activeArea === 'connector'
      ? activeArea
      : null;

  useEffect(() => {
    // Small delay to ensure the mount animation plays nicely
    const timer = setTimeout(() => setMounted(true), 50);
    return () => clearTimeout(timer);
  }, []);

  return (
    <div className={`lana-home ${mounted ? 'mounted' : ''}`}>
      <header className="lana-header">
        <div className="lana-brand">
          <img className="lana-logo" src={`${import.meta.env.BASE_URL}logo.svg`} alt="LANA DEV logo" />
          <span>LANA DEV</span>
        </div>
        <div className="lana-nav">
          <span className="hidden sm:inline">WORKSPACE</span>
          <span>v1.0.0</span>
        </div>
      </header>

      <div className="lana-home-layout">
        <aside className="lana-home-sidebar" aria-label="LANA DEV home navigation">
          <div className="lana-home-sidebar-inner">
            <div className="lana-home-sidebar-kicker">Workspace</div>
            <nav className="lana-home-sidebar-nav" aria-label="Home sections">
              {homeNavItems.map(({ id, label, description, icon: Icon }) => (
                <button
                  className={`lana-home-nav-item ${activeArea === id ? 'active' : ''}`}
                  key={id}
                  onClick={() => onNavigateArea(id)}
                  aria-current={activeArea === id ? 'page' : undefined}
                  data-testid={`button-home-sidebar-${id}`}
                >
                  <span className="lana-home-nav-icon"><Icon size={15} /></span>
                  <span className="lana-home-nav-copy">
                    <strong>{label}</strong>
                    <small>{description}</small>
                  </span>
                  {activeArea === id && <span className="lana-home-nav-dot" aria-hidden="true" />}
                </button>
              ))}
            </nav>
            <div className="lana-home-sidebar-foot">
              <span className="lana-home-nav-dot" />
              <span>Local-first workspace</span>
            </div>
          </div>
        </aside>

        {nonHomeArea === null ? <main className="lana-main">
        <section className="lana-hero">
          <h1 className="lana-title">
            CREATE <br className="hidden sm:block" />
            WITHOUT <br className="hidden sm:block" />
            FRICTION.
          </h1>
          <p className="lana-subtitle">A professional browser workspace for building software. Choose your approach.</p>
        </section>

        <section className="lana-paths">
          <button className="lana-path-card" onClick={onOpenVibeCode} data-testid="button-open-vibe-code">
            <div className="lana-path-icon vibe-icon">
              <Sparkles size={28} strokeWidth={1.5} />
            </div>
            <div className="lana-path-content">
              <span className="lana-path-kicker">For idea-first builders</span>
              <h3>Vibe Code</h3>
              <p>Describe what you want to make in chat, shape the first frontend with guidance, then move into the IDE when you are ready.</p>
            </div>
            <div className="lana-path-arrow">
              <ArrowRight size={24} />
            </div>
          </button>

          <button className="lana-path-card" onClick={onOpenIDE} data-testid="button-open-ide">
            <div className="lana-path-icon ide-icon">
              <Terminal size={28} strokeWidth={1.5} />
            </div>
            <div className="lana-path-content">
              <span className="lana-path-kicker">For experienced developers</span>
              <h3>Open IDE</h3>
              <p>Start with direct, unconstrained control over the files, terminal, local dev server, and implementation details.</p>
            </div>
            <div className="lana-path-arrow">
              <ArrowRight size={24} />
            </div>
          </button>
        </section>

        <section className="lana-tools">
          <div className="lana-tools-header">
            <h2><Wrench size={16} /> FREE TOOLS</h2>
            <div className="lana-line"></div>
          </div>
          <div className="lana-tools-grid">
            {tools.map((tool, i) => (
              <button 
                key={tool.id} 
                className="lana-tool-card" 
                onClick={() => onSelectTool(tool.id)}
                data-testid={`button-free-tool-${tool.id}`}
                style={{ transitionDelay: `${i * 0.05}s` }}
              >
                <div className="lana-tool-icon">
                  <tool.icon size={20} strokeWidth={1.5} />
                </div>
                <div className="lana-tool-info">
                  <h4>{tool.name}</h4>
                  <p>{tool.desc}</p>
                  <span className="lana-tool-status">AVAILABLE NOW</span>
                </div>
              </button>
            ))}
          </div>
          {selectedTool && <p className="lana-tool-selection" data-testid="text-selected-free-tool">Last opened: {tools.find((tool) => tool.id === selectedTool)?.name ?? selectedTool}. These tools run locally in your browser.</p>}
        </section>
        </main> : <HomeAreaView area={nonHomeArea} selectedAiProvider={selectedAiProvider} onSelectAiProvider={onSelectAiProvider} />}
      </div>

      <footer className="lana-footer">
        <div>SYSTEM STATUS: ONLINE</div>
        <div>ALL SYSTEMS NOMINAL</div>
      </footer>
    </div>
  );
}

function HomeAreaView({
  area,
  selectedAiProvider,
  onSelectAiProvider,
}: {
  area: Exclude<HomeArea, 'home'>;
  selectedAiProvider: AiProvider | 'local';
  onSelectAiProvider: (provider: AiProvider | 'local') => void;
}) {
  const { isSignedIn } = useAuth();
  const content: Record<Exclude<HomeArea, 'home'>, {
    label: string;
    title: string;
    description: string;
    detail: string;
  }> = {
    templates: {
      label: 'Templates',
      title: 'Start with a pattern that fits.',
      description: 'Browse reusable project directions before opening a full workspace.',
      detail: 'Templates will help you move from a rough idea to a focused starting point without losing control of the files.',
    },
    history: {
      label: 'App History',
      title: 'Your recent builds, in one place.',
      description: 'Return to previous workspaces and keep your build thread easy to follow.',
      detail: 'App History will surface the projects and sessions you have opened recently, with local-first persistence.',
    },
    connector: {
      label: 'Connector',
      title: 'Choose where your AI requests run.',
      description: 'Keep Ollama local, or connect an API account you own for cloud models.',
      detail: 'Cloud requests use only the provider account you connect. Consumer ChatGPT, Claude, Grok, or X subscriptions are not API credentials.',
    },
  };
  const safeArea = area in content ? area : 'templates';
  const page = content[safeArea];

  return (
    <main className="lana-home-area" data-testid={`page-home-sidebar-${safeArea}`}>
      <div className="lana-home-area-inner">
        <div className="lana-home-area-kicker">{page.label} / LANA DEV</div>
        <h1>{page.title}</h1>
        <p className="lana-home-area-description">{page.description}</p>
        <section className="lana-home-area-card">
          <span className="lana-home-area-status"><span className="lana-home-nav-dot" /> Workspace area</span>
          <p>{page.detail}</p>
        </section>
        {area === 'connector' && <AiConnectorPanel isSignedIn={Boolean(isSignedIn)} selectedProvider={selectedAiProvider} onSelectProvider={onSelectAiProvider} variant="home" />}
      </div>
    </main>
  );
}

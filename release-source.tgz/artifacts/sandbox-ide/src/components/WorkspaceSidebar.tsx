import {
  ArrowLeft,
  Code2,
  Home,
  LibraryBig,
  MonitorPlay,
  PanelsTopLeft,
  Plug2,
  Rocket,
  ShieldCheck,
  Sparkles,
  Terminal,
  Workflow,
} from 'lucide-react';

export type WorkspacePage = 'build' | 'preview' | 'publish';
export type WorkspaceArea = 'templates' | 'routines' | 'library' | 'integrations' | 'security';
export type WorkspaceMode = 'vibe' | 'ide';

interface WorkspaceSidebarProps {
  activePage: WorkspacePage;
  activeArea?: WorkspaceArea | null;
  mode: WorkspaceMode;
  securityNeedsAttention?: boolean;
  onNavigate: (page: WorkspacePage) => void;
  onNavigateArea: (area: WorkspaceArea) => void;
  onHome: () => void;
}

const pageItems: Array<{
  id: WorkspacePage;
  label: string;
  description: string;
  icon: typeof Code2;
}> = [
  { id: 'build', label: 'Build', description: 'Shape the project', icon: Code2 },
  { id: 'preview', label: 'Preview', description: 'See it live', icon: MonitorPlay },
  { id: 'publish', label: 'Publish', description: 'Share the release', icon: Rocket },
];

const areaGroups: Array<{
  label: string;
  items: Array<{
    id: WorkspaceArea;
    label: string;
    description: string;
    icon: typeof PanelsTopLeft;
  }>;
}> = [
  {
    label: 'Resources',
    items: [
      { id: 'templates', label: 'Templates', description: 'Start from a pattern', icon: PanelsTopLeft },
      { id: 'routines', label: 'Project routines', description: 'Repeatable build steps', icon: Workflow },
      { id: 'library', label: 'Library', description: 'Saved project pieces', icon: LibraryBig },
    ],
  },
  {
    label: 'Connections',
    items: [
      { id: 'integrations', label: 'Integrations', description: 'Connect services', icon: Plug2 },
      { id: 'security', label: 'Security', description: 'Pre-flight before publish', icon: ShieldCheck },
    ],
  },
];

export function WorkspaceSidebar({
  activePage,
  activeArea,
  mode,
  securityNeedsAttention = false,
  onNavigate,
  onNavigateArea,
  onHome,
}: WorkspaceSidebarProps) {
  return (
    <aside className="workspace-sidebar" aria-label="Workspace navigation">
      <div className="workspace-sidebar-inner">
        <button
          className="sidebar-project"
          onClick={onHome}
          title="Back to LANA DEV home"
          data-testid="button-sidebar-home"
        >
          <span className="sidebar-project-mark">L</span>
          <span className="sidebar-project-copy">
            <strong>LANA DEV</strong>
            <small>Workspace</small>
          </span>
          <ArrowLeft size={14} className="sidebar-project-arrow" />
        </button>

        <div className="sidebar-divider" />

        <div className="sidebar-section-label">Workspace</div>
        <nav className="sidebar-nav" aria-label="Project sections">
          {pageItems.map(({ id, label, description, icon: Icon }) => (
            <button
              className={`sidebar-nav-item ${activePage === id ? 'active' : ''}`}
              key={id}
              onClick={() => onNavigate(id)}
              aria-current={activePage === id ? 'page' : undefined}
              data-testid={`button-page-${id}`}
            >
              <span className="sidebar-nav-icon"><Icon size={15} /></span>
              <span className="sidebar-nav-copy">
                <strong>{label}</strong>
                <small>{description}</small>
              </span>
              {activePage === id && <span className="sidebar-active-dot" aria-hidden="true" />}
            </button>
          ))}
        </nav>

        {areaGroups.map((group) => (
          <div className="sidebar-group" key={group.label}>
            <div className="sidebar-section-label">{group.label}</div>
            <nav className="sidebar-nav" aria-label={`${group.label} sections`}>
              {group.items.map(({ id, label, description, icon: Icon }) => (
                <button
                  className={`sidebar-nav-item ${activeArea === id ? 'active' : ''}`}
                  key={id}
                  onClick={() => onNavigateArea(id)}
                  aria-current={activeArea === id ? 'page' : undefined}
                  data-testid={`button-sidebar-${id}`}
                >
                  <span className="sidebar-nav-icon"><Icon size={15} /></span>
                  <span className="sidebar-nav-copy">
                    <strong>{label}</strong>
                    <small>{description}</small>
                  </span>
                  {id === 'security' && securityNeedsAttention && (
                    <span className="sidebar-warning-dot" title="Security review needs attention" aria-label="Security review needs attention" />
                  )}
                  {activeArea === id && <span className="sidebar-active-dot" aria-hidden="true" />}
                </button>
              ))}
            </nav>
          </div>
        ))}

        <div className="sidebar-mode-card">
          <div className="sidebar-mode-icon">
            {mode === 'vibe' ? <Sparkles size={14} /> : <Terminal size={14} />}
          </div>
          <div>
            <div className="sidebar-section-label">Current mode</div>
            <strong>{mode === 'vibe' ? 'Vibe Code' : 'Open IDE'}</strong>
          </div>
        </div>

        <div className="sidebar-footer">
          <Home size={13} />
          <span>Local-first workspace</span>
          <span className="sidebar-status-dot" aria-label="Online" />
        </div>
      </div>
    </aside>
  );
}
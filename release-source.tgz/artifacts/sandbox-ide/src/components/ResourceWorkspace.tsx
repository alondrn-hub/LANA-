import { useMemo, useState } from 'react';
import {
  Check,
  ChevronRight,
  Code2,
  Copy,
  Edit3,
  FileCode2,
  FileImage,
  FilePlus2,
  Play,
  Plus,
  Search,
  Trash2,
  Workflow,
  X,
} from 'lucide-react';
import type {
  LibraryItem,
  ProjectFile,
  ProjectResources,
  ProjectRoutine,
  ProjectTemplate,
} from '@workspace/api-client-react';
import type { WorkspaceArea } from './WorkspaceSidebar';

type ResourceFile = ProjectFile;

const BUILT_IN_TEMPLATES: ProjectTemplate[] = [
  {
    id: 'starter-dashboard',
    name: 'Starter dashboard',
    description: 'A calm dashboard foundation with a home page, navigation, and a small data surface.',
    category: 'Product',
    files: [
      { path: 'src/App.tsx', kind: 'code', content: `import { useState } from 'react';

export default function App() {
  const [ready, setReady] = useState(false);

  return (
    <main className="app-shell">
      <h1>Build something useful.</h1>
      <button onClick={() => setReady(true)}>
        {ready ? 'Workspace ready' : 'Start building'}
      </button>
    </main>
  );
}` },
      { path: 'src/main.tsx', kind: 'code', content: `import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import App from './App';
import './index.css';

createRoot(document.getElementById('root')!).render(
  <StrictMode><App /></StrictMode>,
);` },
      { path: 'src/index.css', kind: 'code', content: `:root { font-family: system-ui, sans-serif; color: #202338; }
body { margin: 0; background: #f3f0e9; }
button { padding: 10px 14px; }` },
      { path: 'package.json', kind: 'json', content: `{
  "name": "starter-dashboard",
  "private": true,
  "scripts": { "dev": "vite", "build": "vite build" }
}` },
      { path: 'README.md', kind: 'text', content: `# Starter dashboard

A focused starting point for a useful product workspace.` },
    ],
  },
  {
    id: 'landing-page',
    name: 'Landing page',
    description: 'A sharp marketing page shape with a hero, proof points, and a clear call to action.',
    category: 'Marketing',
    files: [
      { path: 'src/App.tsx', kind: 'code', content: `export default function App() {
  return (
    <main className="landing">
      <nav><strong>YOUR PRODUCT</strong><span>About · Work · Contact</span></nav>
      <section className="hero">
        <p className="eyebrow">A better way forward</p>
        <h1>Make the next idea impossible to ignore.</h1>
        <p>Tell a clear story, show the value, and give people a simple next step.</p>
        <button>Start a conversation →</button>
      </section>
    </main>
  );
}` },
      { path: 'src/main.tsx', kind: 'code', content: `import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import App from './App';
import './index.css';
createRoot(document.getElementById('root')!).render(<StrictMode><App /></StrictMode>);` },
      { path: 'src/index.css', kind: 'code', content: `body { margin: 0; background: #101010; color: #f5f5f0; font-family: system-ui; }
.landing { max-width: 1100px; margin: auto; padding: 32px; }
.hero { max-width: 720px; padding: 16vh 0; }
h1 { font-size: clamp(48px, 8vw, 96px); line-height: .95; }` },
      { path: 'package.json', kind: 'json', content: `{
  "name": "landing-page",
  "private": true,
  "scripts": { "dev": "vite", "build": "vite build" }
}` },
      { path: 'README.md', kind: 'text', content: `# Landing page

Lead with the user outcome and one decisive action.` },
    ],
  },
  {
    id: 'tool-workbench',
    name: 'Tool workbench',
    description: 'A compact utility interface for a focused tool, with room for inputs, output, and history.',
    category: 'Utility',
    files: [
      { path: 'src/App.tsx', kind: 'code', content: `import { useState } from 'react';

export default function App() {
  const [input, setInput] = useState('');
  return (
    <main className="workbench">
      <aside><strong>TOOLBOX</strong><p>One focused utility.</p></aside>
      <section><h1>Turn an input into an answer.</h1>
        <textarea value={input} onChange={(event) => setInput(event.target.value)} />
        <button onClick={() => setInput((value) => value.trim())}>Process input</button>
        <pre>{input || 'Your output will appear here.'}</pre>
      </section>
    </main>
  );
}` },
      { path: 'src/main.tsx', kind: 'code', content: `import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import App from './App';
import './index.css';
createRoot(document.getElementById('root')!).render(<StrictMode><App /></StrictMode>);` },
      { path: 'src/index.css', kind: 'code', content: `.workbench { display: grid; grid-template-columns: 220px 1fr; min-height: 100vh; }
aside { padding: 28px; background: #24283c; color: #fff; }
section { max-width: 720px; padding: 12vh 8vw; }
textarea { width: 100%; min-height: 150px; }` },
      { path: 'package.json', kind: 'json', content: `{
  "name": "tool-workbench",
  "private": true,
  "scripts": { "dev": "vite", "build": "vite build" }
}` },
      { path: 'README.md', kind: 'text', content: `# Tool workbench

Keep the input, output, and next action in one focused loop.` },
    ],
  },
];

const RESOURCE_LABELS: Record<WorkspaceArea, { eyebrow: string; title: string; description: string }> = {
  templates: {
    eyebrow: 'Templates',
    title: 'Start with a strong first shape.',
    description: 'Browse foundations, then bring the one that fits into this workspace.',
  },
  routines: {
    eyebrow: 'Project routines',
    title: 'Make the build loop repeatable.',
    description: 'Save the steps you use again and again, then run them without rebuilding the checklist.',
  },
  library: {
    eyebrow: 'Library',
    title: 'Keep your best project pieces nearby.',
    description: 'Save snippets, components, and local asset references so useful work stays portable.',
  },
  integrations: { eyebrow: 'Integrations', title: 'Connect the tools your project needs.', description: 'Keep external services discoverable without losing the local-first build loop.' },
  security: { eyebrow: 'Security', title: 'Know what leaves the workspace.', description: 'Review the guardrails around code, requests, credentials, and release readiness.' },
};

function idFor(prefix: string) {
  return `${prefix}-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
}

function ResourceHeader({ area, count, onBackToBuild }: { area: WorkspaceArea; count: number; onBackToBuild: () => void }) {
  const copy = RESOURCE_LABELS[area];
  return (
    <div className="resource-heading">
      <div className="eyebrow">{copy.eyebrow}</div>
      <div className="resource-heading-meta"><span className="sidebar-status-dot" /> {count} saved in this workspace</div>
      <h1>{copy.title}</h1>
      <p>{copy.description}</p>
      <button className="text-link-button" onClick={onBackToBuild} data-testid="button-area-back-to-build"><ChevronRight size={13} className="rotate-180" /> Back to Build</button>
    </div>
  );
}

function SignInHint({ onBackToBuild }: { onBackToBuild: () => void }) {
  return (
    <section className="resource-signin-card">
      <div className="resource-icon"><FilePlus2 size={18} /></div>
      <div>
        <div className="eyebrow">Personal resources</div>
        <h2>Sign in to keep this collection.</h2>
        <p>These saved tools follow your project across sessions. You can browse the built-in templates now, then sign in to save your own.</p>
        <button className="resource-button secondary" onClick={onBackToBuild}>Back to Build <ChevronRight size={13} /></button>
      </div>
    </section>
  );
}

export function ResourceWorkspace({
  area,
  resources,
  isLoading,
  isSaving,
  isSignedIn,
  userId,
  isCurrentUser,
  currentFiles,
  activeFile,
  activeContent,
  onSaveResources,
  onApplyTemplate,
  onInsertLibraryItem,
  onBackToBuild,
  onNotice,
}: {
  area: WorkspaceArea;
  resources: ProjectResources;
  isLoading: boolean;
  isSaving: boolean;
  isSignedIn: boolean;
  userId: string | null;
  isCurrentUser: (candidateUserId: string) => boolean;
  currentFiles: ResourceFile[];
  activeFile: string;
  activeContent: string;
  onSaveResources: (changes: Partial<Pick<ProjectResources, 'templates' | 'routines' | 'library'>>) => Promise<boolean>;
  onApplyTemplate: (template: ProjectTemplate) => void;
  onInsertLibraryItem: (item: LibraryItem) => void;
  onBackToBuild: () => void;
  onNotice: (text: string) => void;
}) {
  const count = area === 'templates'
    ? BUILT_IN_TEMPLATES.length + resources.templates.length
    : area === 'routines' || area === 'library'
      ? resources[area].length
      : 0;
  return (
    <main className="workspace-area-page resource-page" data-testid={`page-sidebar-${area}`}>
      <ResourceHeader area={area} count={count} onBackToBuild={onBackToBuild} />
      {isLoading ? <div className="resource-loading" data-testid="state-resource-loading"><span /><span /><span /></div> : (
        <>
          {area === 'templates' && <TemplatesPanel savedTemplates={resources.templates} isSignedIn={isSignedIn} currentFiles={currentFiles} onApplyTemplate={onApplyTemplate} onSaveResources={onSaveResources} onNotice={onNotice} />}
          {area === 'routines' && <RoutinesPanel routines={resources.routines} isSignedIn={isSignedIn} userId={userId} isCurrentUser={isCurrentUser} isSaving={isSaving} onSaveResources={onSaveResources} onNotice={onNotice} />}
          {area === 'library' && <LibraryPanel items={resources.library} isSignedIn={isSignedIn} activeFile={activeFile} activeContent={activeContent} onInsertLibraryItem={onInsertLibraryItem} onSaveResources={onSaveResources} onNotice={onNotice} />}
          {(area === 'integrations' || area === 'security') && <SignInHint onBackToBuild={onBackToBuild} />}
        </>
      )}
    </main>
  );
}

function TemplatesPanel({
  savedTemplates, isSignedIn, currentFiles, onApplyTemplate, onSaveResources, onNotice,
}: {
  savedTemplates: ProjectTemplate[];
  isSignedIn: boolean;
  currentFiles: ResourceFile[];
  onApplyTemplate: (template: ProjectTemplate) => void;
  onSaveResources: (changes: Partial<Pick<ProjectResources, 'templates' | 'routines' | 'library'>>) => Promise<boolean>;
  onNotice: (text: string) => void;
}) {
  const [showForm, setShowForm] = useState(false);
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState('My workspace');
  const templates = [...BUILT_IN_TEMPLATES, ...savedTemplates];

  const saveTemplate = async () => {
    if (!name.trim()) return onNotice('Add a name for this template first.');
    if (!isSignedIn) return onNotice('Sign in to save personal templates.');
    const template: ProjectTemplate = {
      id: idFor('template'),
      name: name.trim(),
      description: description.trim() || `Saved from ${currentFiles[0]?.path ?? 'this workspace'}.`,
      category: category.trim() || 'My workspace',
      files: currentFiles,
    };
    const didSave = await onSaveResources({ templates: [...savedTemplates, template] });
    if (!didSave) return;
    setName('');
    setDescription('');
    setShowForm(false);
    onNotice('Template saved to this workspace.');
  };

  return (
    <div className="resource-content">
      <div className="resource-toolbar">
        <div><div className="eyebrow">Project foundations</div><strong>{templates.length} templates ready to use</strong></div>
        <button className="resource-button" onClick={() => isSignedIn ? setShowForm((value) => !value) : onNotice('Sign in to save personal templates.')} data-testid="button-save-template"><Plus size={14} /> Save current as template</button>
      </div>
      {showForm && <div className="resource-form resource-form-wide" data-testid="form-save-template">
        <div className="resource-form-header"><div><div className="eyebrow">New template</div><strong>Save this workspace as a reusable starting point.</strong></div><button className="resource-icon-button" onClick={() => setShowForm(false)} aria-label="Close template form"><X size={15} /></button></div>
        <div className="resource-form-grid"><label>Name<input value={name} onChange={(event) => setName(event.target.value)} placeholder="e.g. Client dashboard" /></label><label>Category<input value={category} onChange={(event) => setCategory(event.target.value)} placeholder="My workspace" /></label></div>
        <label>Description<textarea value={description} onChange={(event) => setDescription(event.target.value)} placeholder="What makes this a useful starting point?" rows={2} /></label>
        <button className="resource-button" onClick={saveTemplate}>Save template <Check size={13} /></button>
      </div>}
      <div className="resource-grid template-grid">
        {templates.map((template) => <article className="resource-card template-card" key={template.id} data-testid={`card-template-${template.id}`}>
          <div className="resource-card-top"><span className="resource-card-icon"><Code2 size={16} /></span><span className="resource-tag">{savedTemplates.some((item) => item.id === template.id) ? 'Saved' : template.category}</span></div>
          <h2>{template.name}</h2><p>{template.description}</p>
          <div className="resource-card-foot"><span className="resource-meta">{template.files.length} files · editable</span><button className="resource-button secondary" onClick={() => onApplyTemplate(template)} data-testid={`button-use-template-${template.id}`}>Use template <ChevronRight size={13} /></button></div>
        </article>)}
      </div>
    </div>
  );
}

function RoutinesPanel({
  routines, isSignedIn, userId, isCurrentUser, isSaving, onSaveResources, onNotice,
}: {
  routines: ProjectRoutine[];
  isSignedIn: boolean;
  userId: string | null;
  isCurrentUser: (candidateUserId: string) => boolean;
  isSaving: boolean;
  onSaveResources: (changes: Partial<Pick<ProjectResources, 'templates' | 'routines' | 'library'>>) => Promise<boolean>;
  onNotice: (text: string) => void;
}) {
  const [editingId, setEditingId] = useState<string | null>(null);
  const [showForm, setShowForm] = useState(false);
  const [runningId, setRunningId] = useState<string | null>(null);
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [steps, setSteps] = useState('');
  const openForm = (routine?: ProjectRoutine) => {
    setEditingId(routine?.id ?? null);
    setName(routine?.name ?? '');
    setDescription(routine?.description ?? '');
    setSteps(routine?.steps.join('\n') ?? '');
    setShowForm(true);
  };
  const saveRoutine = async () => {
    if (!name.trim() || !steps.trim()) return onNotice('Add a routine name and at least one step.');
    if (!isSignedIn) return onNotice('Sign in to save project routines.');
    const nextRoutine: ProjectRoutine = { id: editingId ?? idFor('routine'), name: name.trim(), description: description.trim() || 'A repeatable project routine.', steps: steps.split('\n').map((step) => step.trim()).filter(Boolean), lastRunAt: editingId ? routines.find((item) => item.id === editingId)?.lastRunAt ?? null : null };
    const next = editingId ? routines.map((item) => item.id === editingId ? nextRoutine : item) : [...routines, nextRoutine];
    const didSave = await onSaveResources({ routines: next });
    if (!didSave) return;
    setShowForm(false);
    onNotice(editingId ? 'Routine updated.' : 'Routine saved.');
  };
  const runRoutine = async (routine: ProjectRoutine) => {
    const initiatingUserId = userId;
    if (!initiatingUserId) return onNotice('Sign in to run project routines.');
    setRunningId(routine.id);
    const next = routines.map((item) => item.id === routine.id ? { ...item, lastRunAt: new Date().toISOString() } : item);
    const didSave = await onSaveResources({ routines: next });
    if (!didSave) {
      setRunningId(null);
      return;
    }
    window.setTimeout(() => {
      if (!isCurrentUser(initiatingUserId)) return;
      setRunningId(null);
      onNotice(`${routine.name} finished — ${routine.steps.length} steps checked.`);
    }, Math.max(700, routine.steps.length * 250));
  };
  const deleteRoutine = async (id: string) => {
    if (!isSignedIn) return onNotice('Sign in to manage project routines.');
    const didSave = await onSaveResources({ routines: routines.filter((routine) => routine.id !== id) });
    if (!didSave) return;
    onNotice('Routine removed.');
  };

  return (
    <div className="resource-content">
      <div className="resource-toolbar"><div><div className="eyebrow">Saved sequences</div><strong>{routines.length ? 'Run a routine when the build loop needs structure.' : 'Your first routine can turn a habit into a button.'}</strong></div><button className="resource-button" onClick={() => isSignedIn ? openForm() : onNotice('Sign in to save project routines.')} data-testid="button-new-routine"><Plus size={14} /> New routine</button></div>
      {showForm && <div className="resource-form resource-form-wide" data-testid="form-routine">
        <div className="resource-form-header"><div><div className="eyebrow">{editingId ? 'Edit routine' : 'New routine'}</div><strong>{editingId ? 'Tune the steps for this repeatable flow.' : 'Capture the steps you want to run again.'}</strong></div><button className="resource-icon-button" onClick={() => setShowForm(false)} aria-label="Close routine form"><X size={15} /></button></div>
        <div className="resource-form-grid"><label>Name<input value={name} onChange={(event) => setName(event.target.value)} placeholder="e.g. Ship a small change" /></label><label>Description<input value={description} onChange={(event) => setDescription(event.target.value)} placeholder="When should you use it?" /></label></div>
        <label>Steps <span className="resource-label-hint">one step per line</span><textarea value={steps} onChange={(event) => setSteps(event.target.value)} placeholder={'Run the local checks\nReview the preview\nWrite the release note'} rows={5} /></label>
        <button className="resource-button" onClick={saveRoutine} disabled={isSaving}>Save routine <Check size={13} /></button>
      </div>}
      <div className="routine-list">
        {routines.length === 0 && <div className="resource-empty"><Workflow size={22} /><strong>No saved routines yet.</strong><span>Make a project habit reusable with a short list of steps.</span></div>}
        {routines.map((routine) => <article className="routine-card" key={routine.id} data-testid={`card-routine-${routine.id}`}>
          <div className="routine-main"><span className="resource-card-icon"><Workflow size={16} /></span><div><h2>{routine.name}</h2><p>{routine.description}</p></div></div>
          <div className="routine-steps">{routine.steps.map((step, index) => <div className={`routine-step ${runningId === routine.id ? 'running' : ''}`} key={`${routine.id}-${step}`}><span>{runningId === routine.id ? <Play size={10} fill="currentColor" /> : index + 1}</span>{step}</div>)}</div>
          <div className="resource-card-foot"><span className="resource-meta">{routine.lastRunAt ? `Last run ${new Date(routine.lastRunAt).toLocaleDateString()}` : 'Not run yet'}</span><div className="resource-actions"><button className="resource-icon-button" onClick={() => openForm(routine)} title="Edit routine" aria-label={`Edit ${routine.name}`}><Edit3 size={14} /></button><button className="resource-icon-button danger" onClick={() => deleteRoutine(routine.id)} title="Delete routine" aria-label={`Delete ${routine.name}`}><Trash2 size={14} /></button><button className="resource-button secondary" onClick={() => runRoutine(routine)} disabled={runningId === routine.id} data-testid={`button-run-routine-${routine.id}`}><Play size={12} fill="currentColor" /> {runningId === routine.id ? 'Running…' : 'Run routine'}</button></div></div>
        </article>)}
      </div>
    </div>
  );
}

function LibraryPanel({
  items, isSignedIn, activeFile, activeContent, onInsertLibraryItem, onSaveResources, onNotice,
}: {
  items: LibraryItem[];
  isSignedIn: boolean;
  activeFile: string;
  activeContent: string;
  onInsertLibraryItem: (item: LibraryItem) => void;
  onSaveResources: (changes: Partial<Pick<ProjectResources, 'templates' | 'routines' | 'library'>>) => Promise<boolean>;
  onNotice: (text: string) => void;
}) {
  const [query, setQuery] = useState('');
  const [showForm, setShowForm] = useState(false);
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [type, setType] = useState<LibraryItem['type']>('snippet');
  const [tags, setTags] = useState('');
  const [content, setContent] = useState('');
  const filteredItems = useMemo(() => {
    const normalized = query.trim().toLowerCase();
    if (!normalized) return items;
    return items.filter((item) => [item.name, item.description, item.type, ...item.tags].some((value) => value.toLowerCase().includes(normalized)));
  }, [items, query]);
  const openForm = () => {
    setName('');
    setDescription('');
    setType('snippet');
    setTags('');
    setContent(activeContent);
    setShowForm(true);
  };
  const saveItem = async () => {
    if (!name.trim() || !content.trim()) return onNotice('Add a name and some content before saving.');
    if (!isSignedIn) return onNotice('Sign in to save library items.');
    const item: LibraryItem = { id: idFor('library'), name: name.trim(), description: description.trim() || `Saved from ${activeFile}.`, type, content, tags: tags.split(',').map((tag) => tag.trim()).filter(Boolean), updatedAt: new Date().toISOString() };
    const didSave = await onSaveResources({ library: [...items, item] });
    if (!didSave) return;
    setShowForm(false);
    onNotice('Saved to your library.');
  };
  const deleteItem = async (id: string) => {
    if (!isSignedIn) return onNotice('Sign in to manage library items.');
    const didSave = await onSaveResources({ library: items.filter((item) => item.id !== id) });
    if (!didSave) return;
    onNotice('Library item removed.');
  };
  const typeIcon = (itemType: LibraryItem['type']) => itemType === 'asset' ? <FileImage size={16} /> : itemType === 'component' ? <Copy size={16} /> : <FileCode2 size={16} />;

  return (
    <div className="resource-content">
      <div className="resource-toolbar library-toolbar"><div><div className="eyebrow">Saved project pieces</div><strong>{filteredItems.length} {filteredItems.length === 1 ? 'item' : 'items'} in your library</strong></div><div className="resource-toolbar-actions"><label className="resource-search"><Search size={14} /><input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Search name, type, tag…" aria-label="Search library" data-testid="input-search-library" /></label><button className="resource-button" onClick={() => isSignedIn ? openForm() : onNotice('Sign in to save library items.')} data-testid="button-save-library"><Plus size={14} /> Save current file</button></div></div>
      {showForm && <div className="resource-form resource-form-wide" data-testid="form-library">
        <div className="resource-form-header"><div><div className="eyebrow">New library item</div><strong>Save a useful piece from {activeFile}.</strong></div><button className="resource-icon-button" onClick={() => setShowForm(false)} aria-label="Close library form"><X size={15} /></button></div>
        <div className="resource-form-grid"><label>Name<input value={name} onChange={(event) => setName(event.target.value)} placeholder="e.g. Empty state card" /></label><label>Type<select value={type} onChange={(event) => setType(event.target.value as LibraryItem['type'])}><option value="snippet">Snippet</option><option value="component">Component</option><option value="asset">Local asset</option></select></label></div>
        <div className="resource-form-grid"><label>Description<input value={description} onChange={(event) => setDescription(event.target.value)} placeholder="What is this useful for?" /></label><label>Tags <span className="resource-label-hint">comma separated</span><input value={tags} onChange={(event) => setTags(event.target.value)} placeholder="ui, forms, starter" /></label></div>
        <label>Content<textarea value={content} onChange={(event) => setContent(event.target.value)} rows={7} spellCheck={false} /></label>
        <button className="resource-button" onClick={saveItem}>Save to library <Check size={13} /></button>
      </div>}
      <div className="library-list">
        {filteredItems.length === 0 && <div className="resource-empty"><Search size={22} /><strong>{items.length ? 'No library items match that search.' : 'Your library is ready for its first useful piece.'}</strong><span>{items.length ? 'Try a different name, type, or tag.' : 'Save the active file or add a local asset reference to reuse it later.'}</span></div>}
        {filteredItems.map((item) => <article className="library-card" key={item.id} data-testid={`card-library-${item.id}`}>
          <div className="library-card-icon">{typeIcon(item.type)}</div><div className="library-card-main"><div className="library-card-heading"><div><span className="resource-tag">{item.type}</span><h2>{item.name}</h2></div><span className="resource-meta">{new Date(item.updatedAt).toLocaleDateString()}</span></div><p>{item.description}</p><div className="library-card-foot"><div className="resource-tags">{item.tags.map((tag) => <span key={tag}>#{tag}</span>)}</div><div className="resource-actions"><button className="resource-icon-button danger" onClick={() => deleteItem(item.id)} title="Delete library item" aria-label={`Delete ${item.name}`}><Trash2 size={14} /></button><button className="resource-button secondary" onClick={() => onInsertLibraryItem(item)} data-testid={`button-reuse-library-${item.id}`}><Copy size={12} /> Reuse in {activeFile}</button></div></div></div>
        </article>)}
      </div>
    </div>
  );
}
import React, { useState } from 'react';
import {
  ArrowLeft, Database, Code, Shield, FileJson, Layout, Cpu, ChevronRight,
  Play, Copy, CheckCircle2, AlertCircle
} from 'lucide-react';
import {
  API_SAFETY_NOTICE,
  decodeJwt,
  findRegexMatches,
  formatJson,
  formatSql,
  optimizeSvg,
  createApiRequestReview,
  sendReviewedApiRequest,
  type ApiRequestReview,
} from '../lib/freeTools';

interface ToolWorkspaceProps {
  toolId: string;
  onBack: () => void;
  onChooseTool: (toolId: string) => void;
}

const TOOLS = [
  { id: 'api-tester', name: 'API Tester', description: 'Test HTTP requests from the browser.', icon: Database },
  { id: 'regex-vis', name: 'Regex Visualizer', description: 'Understand patterns through real matches.', icon: Code },
  { id: 'jwt-decode', name: 'JWT Decoder', description: 'Read token claims without sending them anywhere.', icon: Shield },
  { id: 'json-format', name: 'JSON Formatter', description: 'Validate and format structured data.', icon: FileJson },
  { id: 'sql-format', name: 'SQL Formatter', description: 'Make queries easier to scan and share.', icon: Layout },
  { id: 'svg-opt', name: 'SVG Optimizer', description: 'Reduce SVG markup before production.', icon: Cpu },
];

function WorkspaceSplit({ left, right }: { left: React.ReactNode, right: React.ReactNode }) {
  return (
    <div className="h-full flex flex-col lg:flex-row min-h-0">
      <div className="flex-1 border-b lg:border-b-0 lg:border-r border-[#1a1a1a] bg-[#050505] flex flex-col min-h-0">
        {left}
      </div>
      <div className="flex-1 bg-[#0a0a0a] flex flex-col min-h-0">
        {right}
      </div>
    </div>
  );
}

function JsonFormatter() {
  const [input, setInput] = useState('');
  const [output, setOutput] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);

  const format = () => {
    if (!input.trim()) {
      setOutput('');
      setError('Paste JSON into the input area before formatting.');
      return;
    }
    try {
      setOutput(formatJson(input));
      setError(null);
    } catch (e: any) {
      setOutput('');
      setError(e.message);
    }
  };

  const handleCopy = () => {
    if (!output) return;
    navigator.clipboard.writeText(output);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <WorkspaceSplit
      left={
        <>
          <div className="p-4 border-b border-[#1a1a1a] flex justify-between items-center bg-[#050505]">
            <label className="text-xs font-mono text-[#888] uppercase tracking-widest">Input JSON</label>
            <button 
              onClick={format}
              className="bg-[#333] hover:bg-[#444] text-white px-3 py-1 rounded font-mono text-[11px] transition-colors"
              data-testid="button-format-json"
            >
              Format JSON
            </button>
          </div>
          <textarea
            className="flex-1 w-full bg-transparent border-none outline-none p-6 font-mono text-[13px] text-[#ddd] resize-none"
            placeholder="Paste JSON here..."
            value={input}
            onChange={e => setInput(e.target.value)}
            spellCheck={false}
            data-testid="input-json"
          />
        </>
      }
      right={
        <>
          <div className="p-4 border-b border-[#1a1a1a] flex justify-between items-center bg-[#0a0a0a]">
            <label className="text-xs font-mono text-[#888] uppercase tracking-widest">Formatted Output</label>
            <button 
              onClick={handleCopy} 
              disabled={!output}
              className="text-[#888] hover:text-white disabled:opacity-50 transition-colors"
              data-testid="button-copy"
            >
              {copied ? <CheckCircle2 size={16} className="text-[#dbff00]" /> : <Copy size={16} />}
            </button>
          </div>
          <div className="flex-1 p-6 overflow-auto relative bg-[#0a0a0a]">
            {error ? (
              <div className="text-[#ff4f4f] bg-[#ff4f4f]/10 p-4 border border-[#ff4f4f]/20 rounded font-mono text-[13px]" data-testid="error-json">
                <div className="flex items-center gap-2 mb-2 font-bold"><AlertCircle size={16} /> Parse Error</div>
                {error}
              </div>
            ) : (
              <pre className="font-mono text-[13px] text-[#dbff00] whitespace-pre-wrap break-all" data-testid="output-json">
                {output}
              </pre>
            )}
          </div>
        </>
      }
    />
  );
}

function SqlFormatter() {
  const [input, setInput] = useState('');
  const [output, setOutput] = useState('');
  const [copied, setCopied] = useState(false);

  const format = () => {
    if (!input.trim()) return;
    setOutput(formatSql(input));
  };

  const handleCopy = () => {
    if (!output) return;
    navigator.clipboard.writeText(output);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <WorkspaceSplit
      left={
        <>
          <div className="p-4 border-b border-[#1a1a1a] flex justify-between items-center bg-[#050505]">
            <label className="text-xs font-mono text-[#888] uppercase tracking-widest">Raw SQL</label>
            <button 
              onClick={format}
              className="bg-[#333] hover:bg-[#444] text-white px-3 py-1 rounded font-mono text-[11px] transition-colors"
              data-testid="button-format-sql"
            >
              Format SQL
            </button>
          </div>
          <textarea
            className="flex-1 w-full bg-transparent border-none outline-none p-6 font-mono text-[13px] text-[#ddd] resize-none"
            placeholder="SELECT * FROM users WHERE active = true..."
            value={input}
            onChange={e => setInput(e.target.value)}
            spellCheck={false}
            data-testid="input-sql"
          />
        </>
      }
      right={
        <>
          <div className="p-4 border-b border-[#1a1a1a] flex justify-between items-center bg-[#0a0a0a]">
            <label className="text-xs font-mono text-[#888] uppercase tracking-widest">Formatted SQL</label>
            <button 
              onClick={handleCopy} 
              disabled={!output}
              className="text-[#888] hover:text-white disabled:opacity-50 transition-colors"
              data-testid="button-copy"
            >
              {copied ? <CheckCircle2 size={16} className="text-[#dbff00]" /> : <Copy size={16} />}
            </button>
          </div>
          <div className="flex-1 p-6 overflow-auto bg-[#0a0a0a]">
            <pre className="font-mono text-[13px] text-[#a55eea] whitespace-pre-wrap break-all" data-testid="output-sql">
              {output}
            </pre>
          </div>
        </>
      }
    />
  );
}

function SvgOptimizer() {
  const [input, setInput] = useState('');
  const [output, setOutput] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);
  
  const optimize = () => {
    try {
      setOutput(optimizeSvg(input));
      setError(null);
    } catch (e: any) {
      setOutput('');
      setError(e.message);
    }
  };

  const originalSize = new Blob([input]).size;
  const optimizedSize = new Blob([output]).size;
  const savings = (originalSize > 0 && output) ? ((1 - (optimizedSize / originalSize)) * 100).toFixed(1) : '0.0';

  const handleCopy = () => {
    if (!output) return;
    navigator.clipboard.writeText(output);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <WorkspaceSplit
      left={
        <>
          <div className="p-4 border-b border-[#1a1a1a] flex justify-between items-center bg-[#050505]">
            <label className="text-xs font-mono text-[#888] uppercase tracking-widest">Input SVG</label>
            <button 
              onClick={optimize}
              className="bg-[#333] hover:bg-[#444] text-white px-3 py-1 rounded font-mono text-[11px] transition-colors"
              data-testid="button-optimize-svg"
            >
              Optimize
            </button>
          </div>
          <textarea
            className="flex-1 w-full bg-transparent border-none outline-none p-6 font-mono text-[13px] text-[#ddd] resize-none"
            placeholder="<svg>...</svg>"
            value={input}
            onChange={e => setInput(e.target.value)}
            spellCheck={false}
            data-testid="input-svg"
          />
        </>
      }
      right={
        <>
          <div className="p-4 border-b border-[#1a1a1a] flex justify-between items-center bg-[#0a0a0a]">
            <label className="text-xs font-mono text-[#888] uppercase tracking-widest">Optimized Output</label>
            <div className="flex items-center gap-4">
            {output && !error && (
                <span className="text-xs font-mono text-[#888]" data-testid="text-svg-savings">
                  Saved: <span className="text-[#dbff00] font-bold">{savings}%</span>
                </span>
              )}
              <button 
                onClick={handleCopy} 
                disabled={!output}
                className="text-[#888] hover:text-white disabled:opacity-50 transition-colors"
                data-testid="button-copy"
              >
                {copied ? <CheckCircle2 size={16} className="text-[#dbff00]" /> : <Copy size={16} />}
              </button>
            </div>
          </div>
          <div className="flex-1 p-6 overflow-auto bg-[#0a0a0a]">
            {error ? (
              <div className="text-[#ff4f4f] bg-[#ff4f4f]/10 p-4 border border-[#ff4f4f]/20 rounded font-mono text-[13px]" data-testid="error-svg">
                <div className="flex items-center gap-2 mb-2 font-bold"><AlertCircle size={16} /> SVG Error</div>
                {error}
              </div>
            ) : (
              <pre className="font-mono text-[13px] text-[#ededed] whitespace-pre-wrap break-all" data-testid="output-svg">
                {output}
              </pre>
            )}
          </div>
        </>
      }
    />
  );
}

function JwtDecoder() {
  const [token, setToken] = useState('');
  const [decoded, setDecoded] = useState<{ header: any, payload: any } | null>(null);
  const [error, setError] = useState<string | null>(null);

  const decode = () => {
    try {
      setDecoded(decodeJwt(token));
      setError(null);
    } catch (e: any) {
      setDecoded(null);
      setError('Malformed token or invalid signature format. ' + e.message);
    }
  };

  return (
    <WorkspaceSplit
      left={
        <>
          <div className="p-4 border-b border-[#1a1a1a] flex justify-between items-center bg-[#050505]">
            <label className="text-xs font-mono text-[#888] uppercase tracking-widest">JWT String</label>
            <button 
              onClick={decode}
              className="bg-[#333] hover:bg-[#444] text-white px-3 py-1 rounded font-mono text-[11px] transition-colors"
              data-testid="button-decode-jwt"
            >
              Decode
            </button>
          </div>
          <textarea
            className="flex-1 w-full bg-transparent border-none outline-none p-6 font-mono text-[13px] text-[#dbff00] resize-none break-all"
            placeholder="eyJhbGciOiJIUzI1NiIsInR5cCI..."
            value={token}
            onChange={e => setToken(e.target.value)}
            spellCheck={false}
            data-testid="input-jwt"
          />
        </>
      }
      right={
        <>
          <div className="p-4 border-b border-[#1a1a1a] flex justify-between items-center bg-[#0a0a0a]">
            <label className="text-xs font-mono text-[#888] uppercase tracking-widest">Decoded Data</label>
          </div>
          <div className="flex-1 p-6 overflow-auto">
            {error ? (
              <div className="text-[#ff4f4f] bg-[#ff4f4f]/10 p-4 border border-[#ff4f4f]/20 rounded font-mono text-[13px]" data-testid="error-jwt">
                <div className="flex items-center gap-2 mb-2 font-bold"><AlertCircle size={16} /> Decode Error</div>
                {error}
              </div>
            ) : decoded ? (
              <div className="space-y-6">
                <div>
                  <div className="text-[10px] text-[#ff4f4f] font-mono mb-2 uppercase font-bold tracking-wider">Header (Algorithm & Type)</div>
                  <pre className="font-mono text-[13px] text-[#ededed] bg-[#111] p-4 rounded overflow-x-auto border border-[#1a1a1a]" data-testid="output-jwt-header">
                    {JSON.stringify(decoded.header, null, 2)}
                  </pre>
                </div>
                <div>
                  <div className="text-[10px] text-[#a55eea] font-mono mb-2 uppercase font-bold tracking-wider">Payload (Data)</div>
                  <pre className="font-mono text-[13px] text-[#ededed] bg-[#111] p-4 rounded overflow-x-auto border border-[#1a1a1a]" data-testid="output-jwt-payload">
                    {JSON.stringify(decoded.payload, null, 2)}
                  </pre>
                </div>
              </div>
            ) : null}
          </div>
        </>
      }
    />
  );
}

function RegexVisualizer() {
  const [pattern, setPattern] = useState('');
  const [flags, setFlags] = useState('g');
  const [testString, setTestString] = useState('');
  const [matches, setMatches] = useState<Array<{match: string, index: number}>>([]);
  const [error, setError] = useState<string | null>(null);

  const testRegex = () => {
    try {
      setMatches(findRegexMatches(pattern, flags, testString));
      setError(null);
    } catch (e: any) {
      setMatches([]);
      setError(e.message);
    }
  };

  return (
    <div className="h-full flex flex-col min-h-0 bg-[#0a0a0a]">
      <div className="p-4 border-b border-[#1a1a1a] bg-[#050505] flex gap-3 flex-wrap items-center">
        <div className="flex-1 flex items-center bg-[#111] border border-[#333] rounded h-10 px-3 focus-within:border-[#dbff00] min-w-[200px]">
          <span className="text-[#888] font-mono select-none">/</span>
          <input 
            className="flex-1 bg-transparent text-[#dbff00] font-mono text-[13px] outline-none px-2 py-2"
            placeholder="pattern"
            value={pattern}
            onChange={e => setPattern(e.target.value)}
            spellCheck={false}
            data-testid="input-regex-pattern"
          />
          <span className="text-[#888] font-mono select-none">/</span>
          <input 
            className="w-16 bg-transparent text-[#a55eea] font-mono text-[13px] outline-none pl-2 py-2"
            placeholder="gim"
            value={flags}
            onChange={e => setFlags(e.target.value)}
            spellCheck={false}
            data-testid="input-regex-flags"
          />
        </div>
        <button 
          onClick={testRegex}
          className="bg-[#333] hover:bg-[#444] text-white px-6 h-10 rounded font-mono text-[13px] transition-colors whitespace-nowrap"
          data-testid="button-regex-test"
        >
          Test Regex
        </button>
      </div>
      
      <div className="flex-1 flex flex-col lg:flex-row min-h-0">
        <div className="flex-1 border-b lg:border-b-0 lg:border-r border-[#1a1a1a] bg-[#050505] flex flex-col">
          <div className="p-4 border-b border-[#1a1a1a] flex justify-between items-center">
            <label className="text-xs font-mono text-[#888] uppercase tracking-widest">Test String</label>
          </div>
          <textarea
            className="flex-1 w-full bg-transparent border-none outline-none p-6 font-mono text-[13px] text-[#ddd] resize-none"
            placeholder="Enter text to match against..."
            value={testString}
            onChange={e => setTestString(e.target.value)}
            spellCheck={false}
            data-testid="input-regex-test"
          />
        </div>
        
        <div className="w-full lg:w-[400px] flex-shrink-0 bg-[#0a0a0a] flex flex-col">
          <div className="p-4 border-b border-[#1a1a1a] flex justify-between items-center">
            <label className="text-xs font-mono text-[#888] uppercase tracking-widest">Matches</label>
            {pattern && !error && (
              <span className="text-xs font-mono text-[#dbff00] bg-[#dbff00]/10 px-2 py-1 rounded" data-testid="text-regex-count">
                {matches.length} match{matches.length !== 1 ? 'es' : ''}
              </span>
            )}
          </div>
          <div className="flex-1 p-4 overflow-auto">
            {error ? (
              <div className="text-[#ff4f4f] bg-[#ff4f4f]/10 p-4 border border-[#ff4f4f]/20 rounded font-mono text-[13px]" data-testid="error-regex">
                <div className="flex items-center gap-2 mb-2 font-bold"><AlertCircle size={16} /> Invalid Regex</div>
                {error}
              </div>
            ) : matches.length > 0 ? (
              <div className="space-y-2">
                {matches.map((m, i) => (
                  <div key={i} className="bg-[#111] border border-[#333] rounded p-3 font-mono text-[13px]" data-testid={`output-regex-match-${i}`}>
                    <div className="text-[10px] text-[#888] mb-1 tracking-widest uppercase">Index: {m.index}</div>
                    <div className="text-[#ededed] break-all whitespace-pre-wrap">{m.match}</div>
                  </div>
                ))}
              </div>
            ) : pattern ? (
              <div className="text-[#888] font-mono text-[13px] text-center mt-10">No matches found</div>
            ) : (
              <div className="text-[#444] font-mono text-[13px] text-center mt-10">Enter a pattern to test</div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

function ApiTester() {
  const [method, setMethod] = useState('GET');
  const [url, setUrl] = useState('');
  const [headers, setHeaders] = useState('{\n  "Accept": "application/json"\n}');
  const [body, setBody] = useState('');
  const [loading, setLoading] = useState(false);
  const [response, setResponse] = useState<any>(null);
  const [error, setError] = useState<string | null>(null);
  const [pendingRequest, setPendingRequest] = useState<ApiRequestReview | null>(null);

  const METHODS = ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS', 'HEAD'];

  const reviewRequest = () => {
    try {
      setPendingRequest(createApiRequestReview(method, url, headers, body));
      setError(null);
    } catch (e: any) {
      const message = e instanceof Error ? e.message : 'The request setup could not be reviewed.';
      setError(message);
    }
  };

  const confirmRequest = async () => {
    if (!pendingRequest) return;

    const { preview, requestInit } = pendingRequest;
    setPendingRequest(null);
    setLoading(true);
    setError(null);
    setResponse(null);
    try {
      const res = await sendReviewedApiRequest({ preview, requestInit });
      const text = await res.text();
      let data = text;
      try { data = JSON.parse(text); } catch {}
      
      setResponse({
        status: res.status,
        statusText: res.statusText,
        headers: Object.fromEntries(res.headers.entries()),
        data
      });
    } catch (e: any) {
      const message = e instanceof Error ? e.message : 'The request could not be completed.';
      setError(`${message} Browser CORS policies may block cross-origin requests; the target server must return appropriate CORS headers.`);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="h-full flex flex-col min-h-0 bg-[#0a0a0a]">
      <div className="border-b border-[#445018] bg-[#dbff00]/[0.06] px-4 py-2.5 font-mono text-[10px] leading-relaxed text-[#c6d889]" data-testid="notice-api-safety">
        {API_SAFETY_NOTICE}
      </div>
      <div className="p-4 border-b border-[#1a1a1a] bg-[#050505] flex gap-3 flex-wrap">
        <select 
          className="bg-[#111] border border-[#333] text-white px-4 h-10 rounded font-mono text-[13px] outline-none focus:border-[#dbff00]"
          value={method}
          onChange={e => setMethod(e.target.value)}
          data-testid="select-api-method"
        >
          {METHODS.map(m => <option key={m} value={m}>{m}</option>)}
        </select>
        <input 
          className="flex-1 bg-[#111] border border-[#333] text-white px-4 h-10 rounded font-mono text-[13px] outline-none focus:border-[#dbff00] min-w-[200px]"
          placeholder="https://api.example.com/v1/resource"
          value={url}
          onChange={e => setUrl(e.target.value)}
          data-testid="input-api-url"
        />
        <button 
           onClick={reviewRequest}
          disabled={loading || !url}
          className="bg-[#dbff00] text-black px-6 h-10 rounded font-bold text-[13px] hover:bg-[#b8d900] disabled:opacity-50 transition-colors flex items-center gap-2 whitespace-nowrap"
           data-testid="button-api-review"
        >
           <Play size={14} /> Review request
        </button>
      </div>
      
      <div className="flex-1 flex flex-col lg:flex-row min-h-0">
        <div className="flex-1 border-b lg:border-b-0 lg:border-r border-[#1a1a1a] bg-[#050505] flex flex-col">
           <div className="p-4 border-b border-[#1a1a1a]">
             <label className="text-xs font-mono text-[#888] uppercase tracking-widest">Headers (JSON)</label>
           </div>
           <textarea
             className="h-32 bg-transparent border-b border-[#1a1a1a] outline-none p-4 font-mono text-[13px] text-[#ddd] resize-none"
             value={headers}
             onChange={e => setHeaders(e.target.value)}
             spellCheck={false}
             data-testid="input-api-headers"
           />
           <div className="p-4 border-b border-[#1a1a1a]">
             <label className="text-xs font-mono text-[#888] uppercase tracking-widest">Body</label>
           </div>
           <textarea
             className="flex-1 bg-transparent border-none outline-none p-4 font-mono text-[13px] text-[#ddd] resize-none"
             value={body}
             onChange={e => setBody(e.target.value)}
             spellCheck={false}
             placeholder={['GET', 'HEAD'].includes(method) ? 'Request body is not sent for GET or HEAD.' : 'Enter request body here...'}
             data-testid="input-api-body"
           />
        </div>
        
        <div className="flex-1 bg-[#0a0a0a] flex flex-col relative overflow-hidden">
          {loading && (
             <div className="absolute inset-0 bg-[#0a0a0a]/80 backdrop-blur-[2px] flex items-center justify-center z-10">
               <div className="text-[#dbff00] font-mono animate-pulse">Sending request...</div>
             </div>
          )}
          <div className="p-4 border-b border-[#1a1a1a] flex justify-between items-center">
            <label className="text-xs font-mono text-[#888] uppercase tracking-widest">Response</label>
            {response && (
              <span className={`font-mono text-xs px-2 py-1 rounded ${response.status >= 200 && response.status < 300 ? 'bg-[#dbff00]/20 text-[#dbff00]' : 'bg-[#ff4f4f]/20 text-[#ff4f4f]'}`} data-testid="text-api-status">
                {response.status} {response.statusText}
              </span>
            )}
          </div>
          <div className="flex-1 overflow-auto p-4">
             {error ? (
               <div className="text-[#ff4f4f] bg-[#ff4f4f]/10 p-4 border border-[#ff4f4f]/20 rounded font-mono text-[13px]" data-testid="error-api">
                 <div className="flex items-center gap-2 mb-2 font-bold"><AlertCircle size={16} /> Error</div>
                 {error}
               </div>
             ) : response ? (
               <div className="space-y-4">
                 <div>
                   <div className="text-[10px] text-[#666] font-mono mb-2 uppercase tracking-widest">Headers</div>
                   <pre className="font-mono text-[11px] text-[#aaa] bg-[#111] p-3 rounded overflow-x-auto border border-[#1a1a1a]">
                     {JSON.stringify(response.headers, null, 2)}
                   </pre>
                 </div>
                 <div>
                   <div className="text-[10px] text-[#666] font-mono mb-2 uppercase tracking-widest">Body</div>
                   <pre className="font-mono text-[13px] text-[#ededed] bg-[#111] p-4 rounded overflow-x-auto border border-[#1a1a1a]" data-testid="output-api">
                     {typeof response.data === 'string' ? response.data : JSON.stringify(response.data, null, 2)}
                   </pre>
                 </div>
               </div>
             ) : (
               <div className="h-full flex items-center justify-center text-[#444] font-mono text-[13px]">
                 Enter a URL and send the request
               </div>
             )}
          </div>
        </div>
      </div>

      {pendingRequest && (
        <div
          className="fixed inset-0 z-30 flex items-center justify-center bg-black/75 p-4"
          role="dialog"
          aria-modal="true"
          aria-labelledby="api-review-title"
          data-testid="dialog-api-review"
        >
          <div className="w-full max-w-2xl max-h-[90vh] overflow-auto rounded border border-[#3d4819] bg-[#0d0d0d] shadow-2xl">
            <div className="flex items-start justify-between gap-4 border-b border-[#1a1a1a] p-5">
              <div>
                <div id="api-review-title" className="font-mono text-sm font-bold uppercase tracking-widest text-[#dbff00]">
                  Review request
                </div>
                <p className="mt-2 font-mono text-xs leading-relaxed text-[#888]">
                  Nothing has been sent yet. Confirm these resolved values before they leave the browser.
                </p>
              </div>
              <button
                type="button"
                onClick={() => setPendingRequest(null)}
                className="font-mono text-xs text-[#888] hover:text-white"
                data-testid="button-api-review-cancel"
              >
                Cancel
              </button>
            </div>

            <div className="space-y-4 p-5">
              <div className="grid gap-3 sm:grid-cols-[auto_1fr]">
                <div className="rounded border border-[#252525] bg-[#111] p-3">
                  <div className="mb-1 text-[10px] uppercase tracking-widest text-[#666]">Method</div>
                  <div className="font-mono text-sm font-bold text-white" data-testid="text-api-preview-method">
                    {pendingRequest.preview.method}
                  </div>
                </div>
                <div className="rounded border border-[#252525] bg-[#111] p-3 min-w-0">
                  <div className="mb-1 text-[10px] uppercase tracking-widest text-[#666]">URL</div>
                  <div className="break-all font-mono text-sm text-[#ddd]" data-testid="text-api-preview-url">
                    {pendingRequest.preview.url}
                  </div>
                </div>
              </div>

              <div className="rounded border border-[#252525] bg-[#111]">
                <div className="border-b border-[#252525] px-3 py-2 text-[10px] uppercase tracking-widest text-[#666]">
                  Headers
                </div>
                <div className="divide-y divide-[#1d1d1d]" data-testid="list-api-preview-headers">
                  {pendingRequest.preview.headers.length > 0 ? (
                    pendingRequest.preview.headers.map((header) => (
                      <div key={header.name} className="grid gap-1 px-3 py-2 sm:grid-cols-[minmax(120px,0.4fr)_1fr] sm:gap-3">
                        <div className="break-all font-mono text-xs text-[#aaa]">{header.name}</div>
                        <div className="break-all font-mono text-xs text-[#ddd]">
                          {header.sensitive ? (
                            <span data-testid={`text-api-preview-header-${header.name}`}>
                              <span className="text-[#dbff00]">••••••••</span>
                              <span className="ml-2 text-[10px] uppercase tracking-widest text-[#888]">Sensitive · masked</span>
                            </span>
                          ) : (
                            header.value
                          )}
                        </div>
                      </div>
                    ))
                  ) : (
                    <div className="px-3 py-3 font-mono text-xs text-[#666]">No headers</div>
                  )}
                </div>
              </div>

              <div className="rounded border border-[#252525] bg-[#111] p-3" data-testid="text-api-preview-body">
                <div className="mb-1 text-[10px] uppercase tracking-widest text-[#666]">Body</div>
                <div className={`font-mono text-sm ${pendingRequest.preview.body.willSend ? 'text-[#ddd]' : 'text-[#dbff00]'}`}>
                  {pendingRequest.preview.body.willSend
                    ? `Will send body (${pendingRequest.preview.body.characterCount} characters)`
                    : 'No body will be sent'}
                </div>
                 {pendingRequest.preview.body.content !== null && (
                   <pre
                     className="mt-3 max-h-52 overflow-auto whitespace-pre-wrap break-words rounded border border-[#252525] bg-[#080808] p-3 font-mono text-xs leading-relaxed text-[#ddd]"
                     data-testid="text-api-preview-body-content"
                   >
                     {pendingRequest.preview.body.content}
                   </pre>
                 )}
              </div>
            </div>

            <div className="flex justify-end gap-3 border-t border-[#1a1a1a] p-5">
              <button
                type="button"
                onClick={() => setPendingRequest(null)}
                className="rounded border border-[#333] px-4 py-2 font-mono text-xs text-[#aaa] hover:border-[#666] hover:text-white"
                data-testid="button-api-review-cancel-footer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={confirmRequest}
                className="rounded bg-[#dbff00] px-4 py-2 font-mono text-xs font-bold text-black hover:bg-[#b8d900]"
                data-testid="button-api-confirm"
              >
                Send request
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function ToolWorkspace({ toolId, onBack, onChooseTool }: ToolWorkspaceProps) {
  const activeTool = TOOLS.find((tool) => tool.id === toolId) ?? TOOLS[0];
  let Tool: () => React.ReactElement;
  switch (activeTool.id) {
    case 'regex-vis':
      Tool = RegexVisualizer;
      break;
    case 'jwt-decode':
      Tool = JwtDecoder;
      break;
    case 'json-format':
      Tool = JsonFormatter;
      break;
    case 'sql-format':
      Tool = SqlFormatter;
      break;
    case 'svg-opt':
      Tool = SvgOptimizer;
      break;
    case 'api-tester':
    default:
      Tool = ApiTester;
  }

  return (
    <div className="tool-workspace" data-testid="page-free-tools">
      <header className="tool-topbar">
        <button className="tool-back-button" onClick={onBack} data-testid="button-back-to-tools-home">
          <ArrowLeft size={15} />
          <img className="tool-brand-logo" src={`${import.meta.env.BASE_URL}logo.svg`} alt="" aria-hidden="true" />
          <span>LANA DEV</span>
        </button>
        <div className="tool-topbar-center">
          <span className="tool-topbar-kicker">FREE TOOL /</span>
          <span>{activeTool.name}</span>
        </div>
        <div className="tool-local-badge">BROWSER TOOL</div>
      </header>
      <div className="tool-layout">
        <aside className="tool-sidebar">
          <div className="tool-sidebar-intro">
            <div className="tool-sidebar-kicker">Browser utilities</div>
            <h1>Small tools.<br />No upload.</h1>
            <p>Formatters and decoders run in this tab. API Tester only sends data after you press Send.</p>
          </div>
          <nav className="tool-nav" aria-label="Free tools">
            {TOOLS.map((tool) => {
              const Icon = tool.icon;
              return (
                <button
                  key={tool.id}
                  className={`tool-nav-item ${activeTool.id === tool.id ? 'active' : ''}`}
                  onClick={() => onChooseTool(tool.id)}
                  data-testid={`button-tool-nav-${tool.id}`}
                >
                  <span className="tool-nav-icon"><Icon size={16} strokeWidth={1.6} /></span>
                  <span className="tool-nav-copy">
                    <strong>{tool.name}</strong>
                    <small>{tool.description}</small>
                  </span>
                  <ChevronRight size={14} className="tool-nav-arrow" />
                </button>
              );
            })}
          </nav>
          <div className="tool-sidebar-foot">
            <span className="tool-foot-dot" />
            <span>RUNNING IN YOUR BROWSER</span>
          </div>
        </aside>
        <main className="tool-main">
          <div className="tool-main-heading">
            <div>
              <div className="tool-heading-kicker">LANA DEV / FREE TOOLS</div>
              <h2 data-testid="heading-tool">{activeTool.name}</h2>
              <p>{activeTool.description}</p>
            </div>
            <div className="tool-shortcut">NO ACCOUNT REQUIRED</div>
          </div>
          <div className="tool-canvas" data-testid={`workspace-tool-${activeTool.id}`}>
            <Tool />
          </div>
        </main>
      </div>
    </div>
  );
}

export { ToolWorkspace };

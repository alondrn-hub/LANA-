# Robotics IDE Frontend

This directory is reserved for the frontend of LANA DEV's Robotics IDE. It
parallels `src/lib/robotics/` and should remain simulation-first until the
runtime is fully validated.

## Planned component structure

```text
robotics/
├── RoboticsWorkspace.tsx       # Feature shell and simulation-only status
├── RoboticsScene.tsx           # 3D robot viewport
├── UrdfInputPanel.tsx          # Paste/upload URDF and show validation state
├── KinematicTreePanel.tsx      # Links, joints, and selected-node details
├── JointControls.tsx           # Safe local joint-state controls
├── SimulationToolbar.tsx       # Play, pause, reset, timestep, runtime status
├── TelemetryPanel.tsx          # Future TF, sensors, and point-cloud views
└── robotics.css                # Feature-scoped visual styles
```

## Required UI states

- Empty: explain how to paste or upload a URDF
- Loading: parse and resolve the kinematic tree
- Invalid: show actionable XML, link, and joint errors
- Ready: show the robot scene and inspectable tree
- Simulating: show fixed-step runtime status and reset controls
- Unsupported: explain WebGPU availability and WASM fallback
- Safety boundary: always show that this view is simulation-only and sends no
  commands to real hardware

## Integration point

The feature should be added as a new LANA DEV workspace entry without replacing
Build, Preview, Publish, or Free Tools. The workspace should preserve the
current dark LANA DEV visual language while giving the 3D scene enough space to
remain useful on desktop and mobile widths.
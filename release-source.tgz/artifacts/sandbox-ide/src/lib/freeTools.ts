export const API_SAFETY_NOTICE =
  'Requests leave this browser and are sent directly to the URL you enter. Browser credentials are omitted, but any headers you add—including authorization headers—will be sent. CORS or preflight rules can block a request or limit what you can read.';

const SQL_CLAUSE_PATTERN = /\b(?:INSERT\s+INTO|DELETE\s+FROM|CREATE\s+TABLE|ALTER\s+TABLE|DROP\s+TABLE|INNER\s+JOIN|LEFT\s+JOIN|RIGHT\s+JOIN|GROUP\s+BY|ORDER\s+BY|UNION\s+ALL|SELECT|FROM|WHERE|AND|OR|JOIN|ON|HAVING|LIMIT|OFFSET|UPDATE|SET|VALUES|UNION)\b/gi;
const SQL_WORD_PATTERN = /\b(?:AS|ASC|DESC)\b/gi;

function formatSqlSegment(segment: string) {
  return segment
    .replace(/\s+/g, ' ')
    .replace(SQL_CLAUSE_PATTERN, (clause) => `\n${clause.toUpperCase().replace(/\s+/g, ' ')} `)
    .replace(SQL_WORD_PATTERN, (word) => word.toUpperCase());
}

export function formatSql(input: string) {
  const output: string[] = [];
  let segmentStart = 0;

  for (let index = 0; index < input.length; index += 1) {
    const quote = input[index];
    if (!["'", '"', '`'].includes(quote)) continue;

    output.push(formatSqlSegment(input.slice(segmentStart, index)));
    let end = index + 1;
    while (end < input.length) {
      if (input[end] === quote) {
        if (quote === "'" && input[end + 1] === "'") {
          end += 2;
          continue;
        }
        end += 1;
        break;
      }
      if (input[end] === '\\' && end + 1 < input.length) {
        end += 2;
      } else {
        end += 1;
      }
    }
    output.push(input.slice(index, end));
    index = end - 1;
    segmentStart = end;
  }

  output.push(formatSqlSegment(input.slice(segmentStart)));
  return output.join('')
    .replace(/[ \t]+\n/g, '\n')
    .replace(/\n[ \t]+/g, '\n')
    .split('\n')
    .map((line) => line.trim())
    .filter(Boolean)
    .join('\n');
}

export function formatJson(input: string) {
  if (!input.trim()) {
    throw new Error('Paste JSON into the input area before formatting.');
  }

  return JSON.stringify(JSON.parse(input), null, 2);
}

export function optimizeSvg(input: string) {
  if (!input.trim()) {
    throw new Error('Paste SVG markup into the input area before optimizing.');
  }
  if (!/<svg(?:\s|>)/i.test(input) || !/<\/svg\s*>/i.test(input)) {
    throw new Error('This does not look like a complete SVG document. Include an opening and closing <svg> tag.');
  }

  return input
    .replace(/<!--[\s\S]*?-->/g, '')
    .replace(/<\?xml.*?\?>/gi, '')
    .replace(/<!DOCTYPE.*?>/gi, '')
    .replace(/\s+/g, ' ')
    .replace(/>\s+</g, '><')
    .trim();
}

export interface DecodedJwt {
  header: unknown;
  payload: unknown;
}

export function decodeJwt(token: string): DecodedJwt {
  if (!token.trim()) {
    throw new Error('Paste a JWT into the input area before decoding.');
  }

  const parts = token.split('.');
  if (parts.length !== 3) throw new Error('Must have exactly 3 parts separated by dots.');
  if (!parts[0] || !parts[1] || !parts[2]) {
    throw new Error('Header, payload, and signature segments are all required.');
  }

  const decodeBase64Url = (value: string) => {
    let base64 = value.replace(/-/g, '+').replace(/_/g, '/');
    while (base64.length % 4) base64 += '=';
    const binary = globalThis.atob(base64);
    const bytes = new Uint8Array(binary.length);
    for (let index = 0; index < binary.length; index += 1) {
      bytes[index] = binary.charCodeAt(index);
    }
    return new TextDecoder().decode(bytes);
  };

  return {
    header: JSON.parse(decodeBase64Url(parts[0])),
    payload: JSON.parse(decodeBase64Url(parts[1])),
  };
}

export interface RegexMatch {
  match: string;
  index: number;
}

export function findRegexMatches(pattern: string, flags: string, testString: string): RegexMatch[] {
  if (!pattern) {
    throw new Error('Enter a pattern before testing it.');
  }

  const regex = new RegExp(pattern, flags);
  if (flags.includes('g')) {
    return [...testString.matchAll(regex)].map((result) => ({
      match: result[0],
      index: result.index ?? -1,
    }));
  }

  const result = testString.match(regex);
  return result ? [{ match: result[0], index: result.index ?? -1 }] : [];
}

export function validateApiUrl(value: string) {
  if (!value.trim()) {
    throw new Error('Enter an HTTP or HTTPS URL before sending.');
  }

  const url = new URL(value.trim());
  if (!['http:', 'https:'].includes(url.protocol)) {
    throw new Error('Only HTTP and HTTPS URLs are supported.');
  }
  return url;
}

export function parseApiHeaders(input: string): Record<string, string> {
  if (!input.trim()) return {};

  let parsed: unknown;
  try {
    parsed = JSON.parse(input);
  } catch {
    throw new Error('Headers must be valid JSON.');
  }

  if (!parsed || Array.isArray(parsed) || typeof parsed !== 'object') {
    throw new Error('Headers must be a JSON object.');
  }

  return parsed as Record<string, string>;
}

const SENSITIVE_API_HEADER_PATTERN = /^(?:authorization|proxy-authorization|cookie|set-cookie|x-api-key|api-key|x-auth-token|access-token|refresh-token|id-token)$/i;
const SENSITIVE_API_HEADER_KEYWORD_PATTERN = /(?:token|secret|password|api[_-]?key)/i;

export function isSensitiveApiHeader(name: string) {
  return SENSITIVE_API_HEADER_PATTERN.test(name.trim()) || SENSITIVE_API_HEADER_KEYWORD_PATTERN.test(name.trim());
}

export interface ApiRequestPreviewHeader {
  name: string;
  value: string;
  sensitive: boolean;
}

export interface ApiRequestPreview {
  method: string;
  url: string;
  headers: ApiRequestPreviewHeader[];
  body: {
    willSend: boolean;
    characterCount: number;
    content: string | null;
  };
}

export function buildApiRequestPreview(
  method: string,
  url: string,
  headers: string,
  body: string,
): ApiRequestPreview {
  const resolvedMethod = method.toUpperCase();
  const resolvedHeaders = parseApiHeaders(headers);
  const willSendBody = !['GET', 'HEAD'].includes(resolvedMethod) && Boolean(body);

  return {
    method: resolvedMethod,
    url: validateApiUrl(url).toString(),
    headers: Object.entries(resolvedHeaders).map(([name, value]) => ({
      name,
      value: String(value),
      sensitive: isSensitiveApiHeader(name),
    })),
    body: {
      willSend: willSendBody,
      characterCount: willSendBody ? body.length : 0,
      content: willSendBody ? body : null,
    },
  };
}

export function buildApiRequestInit(method: string, headers: string, body: string): RequestInit {
  const resolvedMethod = method.toUpperCase();
  const requestInit: RequestInit = {
    method: resolvedMethod,
    headers: parseApiHeaders(headers),
    credentials: 'omit',
    mode: 'cors',
  };

  if (!['GET', 'HEAD'].includes(resolvedMethod) && body) {
    requestInit.body = body;
  }

  return requestInit;
}

export interface ApiRequestReview {
  preview: ApiRequestPreview;
  requestInit: RequestInit;
}

export function createApiRequestReview(
  method: string,
  url: string,
  headers: string,
  body: string,
): ApiRequestReview {
  const preview = buildApiRequestPreview(method, url, headers, body);

  return {
    preview,
    requestInit: buildApiRequestInit(preview.method, headers, preview.body.content ?? ''),
  };
}

export function sendReviewedApiRequest(
  review: ApiRequestReview,
  fetchImplementation: typeof fetch = fetch,
) {
  return fetchImplementation(review.preview.url, review.requestInit);
}

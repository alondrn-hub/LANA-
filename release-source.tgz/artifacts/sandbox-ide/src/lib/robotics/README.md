# Robotics IDE Runtime

This directory is the reserved home for LANA DEV's third feature: a browser-based
Robotics IDE. The full source architecture is documented in
`attached_assets/Pasted-ROBOTICS-IDE-RUNTIME-ARCHITECTURE-1-GPU-PHYSICS-RUNTIME_1787587258322.txt`.

## First vertical slice

The first implementation should stay simulation-only and include:

1. URDF paste/upload and validation
2. Link and joint kinematic-tree resolution
3. A browser 3D scene for the loaded robot
4. Basic joint-state controls
5. A deterministic fixed-step simulation loop
6. WebGPU with a WASM fallback
7. Clear runtime status showing that no hardware commands are being sent

## Planned module boundaries

```text
robotics/
├── urdf/          # XML parsing, validation, kinematic-tree resolution
├── state/         # aligned joint/link state and simulation snapshots
├── simulation/    # fixed-step loop, constraints, and physics adapters
├── rendering/     # 3D scene and WebGPU/WASM capability selection
├── transport/     # future ROS2/Zenoh/WebTransport/WebSocket adapters
├── safety/        # future watchdog, limits, heartbeat, and E-stop states
├── devices/       # future hardware abstraction and device discovery
├── twin/          # future simulation-vs-real state mirroring and replay
└── recording/     # future MCAP, sensor, and deterministic replay support
```

## Safety boundary

The browser Robotics IDE must not send commands to real hardware in the first
vertical slice. ROS2 transport, hardware control, safety enforcement, and
emergency-stop behavior require separate implementation and validation before
they can be exposed as anything other than clearly labelled future modules.
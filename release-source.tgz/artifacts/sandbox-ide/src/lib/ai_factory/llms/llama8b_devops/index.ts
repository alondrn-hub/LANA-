import type { FactoryWorker } from '../types.ts';

export const llama8bDevopsWorker: FactoryWorker = {
  id: 'llama8b_devops',
  directory: 'llms/llama8b_devops',
  label: 'Pipeline Worker',
  responsibility: 'Architecture, debugging, and delivery flow',
  instruction: 'Prioritize system boundaries, implementation order, failure isolation, operational behavior, and the cheapest useful diagnostic step.',
};
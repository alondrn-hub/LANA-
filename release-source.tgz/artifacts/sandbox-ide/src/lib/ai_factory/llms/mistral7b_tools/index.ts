import type { FactoryWorker } from '../types.ts';

export const mistral7bToolsWorker: FactoryWorker = {
  id: 'mistral7b_tools',
  directory: 'llms/mistral7b_tools',
  label: 'Tools Worker',
  responsibility: 'Validation and developer utility work',
  instruction: 'Prioritize acceptance criteria, edge cases, safe transformations, validation, and concise verification steps.',
};
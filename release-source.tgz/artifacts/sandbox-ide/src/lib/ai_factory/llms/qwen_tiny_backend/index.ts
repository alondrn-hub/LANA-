import type { FactoryWorker } from '../types.ts';

export const qwenTinyBackendWorker: FactoryWorker = {
  id: 'qwen_tiny_backend',
  directory: 'llms/qwen_tiny_backend',
  label: 'Backend Worker',
  responsibility: 'Backend and data work',
  instruction: 'Prioritize APIs, persistence, validation, authentication boundaries, data contracts, and error handling.',
};
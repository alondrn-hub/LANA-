export type FactoryWorkerId =
  | 'phi3_ui'
  | 'qwen_tiny_backend'
  | 'llama8b_devops'
  | 'mistral7b_tools';

export type FactoryWorker = {
  id: FactoryWorkerId;
  directory: string;
  label: string;
  responsibility: string;
  instruction: string;
};
import type { FactoryWorker } from '../types.ts';

export const phi3UiWorker: FactoryWorker = {
  id: 'phi3_ui',
  directory: 'llms/phi3_ui',
  label: 'UI Worker',
  responsibility: 'Frontend and interaction work',
  instruction: 'Prioritize component behavior, responsive layout, accessibility, interaction states, and visual hierarchy.',
};
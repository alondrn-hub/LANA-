import { llama8bDevopsWorker } from './llama8b_devops/index.ts';
import { mistral7bToolsWorker } from './mistral7b_tools/index.ts';
import { phi3UiWorker } from './phi3_ui/index.ts';
import { qwenTinyBackendWorker } from './qwen_tiny_backend/index.ts';
import type { FactoryWorker, FactoryWorkerId } from './types.ts';

export type { FactoryWorker, FactoryWorkerId } from './types.ts';

export const factoryWorkers: Record<FactoryWorkerId, FactoryWorker> = {
  phi3_ui: phi3UiWorker,
  qwen_tiny_backend: qwenTinyBackendWorker,
  llama8b_devops: llama8bDevopsWorker,
  mistral7b_tools: mistral7bToolsWorker,
};

export function getFactoryWorker(workerId: FactoryWorkerId) {
  return factoryWorkers[workerId];
}
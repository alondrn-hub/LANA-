import { core, nova, pixel, pulse, shield } from '../../ai/agents/index.ts';
import { localModelClient } from '../../ai/localModelClient.ts';
import { routeRequest } from '../../ai/router.ts';
import type {
  Agent,
  AgentRequest,
  LocalModelClient,
  OrchestrationResult,
} from '../../ai/types.ts';
import { getFactoryWorker } from '../llms/index.ts';
import { splitTask } from './task_splitter.ts';

const agents: Record<string, Agent> = {
  nova,
  pixel,
  core,
  pulse,
  shield,
};

export function createFactoryPlan(request: AgentRequest) {
  const route = routeRequest(request);
  return {
    route,
    tasks: splitTask(request, route),
  };
}

export async function runAgentPipeline(
  request: AgentRequest,
  client: LocalModelClient = localModelClient,
): Promise<OrchestrationResult> {
  const { route, tasks } = createFactoryPlan(request);
  const results: OrchestrationResult['results'] = [];
  const completed = new Set<string>();
  const pending = [...tasks];

  while (pending.length > 0) {
    const readyTasks = pending.filter((task) =>
      task.dependsOn.every((dependency) => completed.has(dependency)),
    );

    if (readyTasks.length === 0) {
      throw new Error('The AI Factory could not resolve its task dependencies.');
    }

    const readyIds = new Set(readyTasks.map(({ agentId }) => agentId));
    const priorResults = results.map(({ agent: completedAgent, label, content }) => ({
      agent: completedAgent,
      label,
      content,
    }));
    const batchResults = await Promise.all(readyTasks.map(async (task) => {
      const agent = agents[task.agentId];
      if (!agent) throw new Error(`Unknown local agent: ${task.agentId}`);

      const worker = getFactoryWorker(task.workerId);
      return agent.run({
        ...task.request,
        priorResults,
      }, client, worker);
    }));

    results.push(...batchResults);
    readyTasks.forEach(({ agentId }) => completed.add(agentId));
    pending.splice(
      0,
      pending.length,
      ...pending.filter(({ agentId }) => !readyIds.has(agentId)),
    );
  }

  const content = route.pipeline.length === 1
    ? results[0].content
    : results.map((result) => `### ${result.label}\n${result.content}`).join('\n\n');

  return {
    route,
    results,
    content,
    model: results[results.length - 1]?.model ?? client.model,
  };
}
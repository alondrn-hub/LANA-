import type { AgentId } from '../../ai/types.ts';
import type { FactoryWorkerId } from '../llms/types.ts';

export const fullReviewAgentOrder: AgentId[] = [
  'nova',
  'pixel',
  'core',
  'pulse',
  'shield',
];

export const workerForAgent: Record<AgentId, FactoryWorkerId> = {
  nova: 'llama8b_devops',
  pixel: 'phi3_ui',
  core: 'qwen_tiny_backend',
  pulse: 'llama8b_devops',
  shield: 'mistral7b_tools',
};

export function getWorkerForAgent(agentId: AgentId) {
  return workerForAgent[agentId];
}

export function getWorkerPipeline(agentPipeline: AgentId[]) {
  return agentPipeline.map(getWorkerForAgent);
}
import type {
  AgentRequest,
  AgentRoute,
  AgentId,
} from '../../ai/types.ts';
import { getWorkerForAgent } from './pipeline_rules.ts';
import type { FactoryWorkerId } from '../llms/types.ts';

export type FactoryTask = {
  agentId: AgentId;
  workerId: FactoryWorkerId;
  request: AgentRequest;
  dependsOn: AgentId[];
  phase: number;
  parallel: boolean;
};

export function splitTask(
  request: AgentRequest,
  route: AgentRoute,
): FactoryTask[] {
  const lastAgentIndex = route.pipeline.length - 1;

  return route.pipeline.map((agentId) => {
    const index = route.pipeline.indexOf(agentId);
    const isFirst = index === 0;
    const isFinal = index === lastAgentIndex && route.pipeline.length > 2;
    const isParallel = route.pipeline.length > 2 && !isFirst && !isFinal;
    const dependsOn = isFirst
      ? []
      : isFinal
        ? route.pipeline.slice(1, lastAgentIndex)
        : [route.pipeline[0]];
    const task: FactoryTask = {
      agentId,
      workerId: getWorkerForAgent(agentId),
      request: {
        ...request,
        priorResults: request.priorResults,
      },
      dependsOn,
      phase: isFirst ? 0 : isFinal ? 2 : 1,
      parallel: isParallel,
    };
    return task;
  });
}
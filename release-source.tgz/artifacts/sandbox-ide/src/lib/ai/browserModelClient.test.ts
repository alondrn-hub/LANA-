import assert from 'node:assert/strict';
import test from 'node:test';
import {
  BrowserLocalModelClient,
  BROWSER_MODEL_ESTIMATED_STORAGE_BYTES,
  BROWSER_MODEL_ID,
} from './browserModelClient.ts';

test('reports, clears, and rebuilds the approved browser model cache', async () => {
  let cached = false;
  let initializeCount = 0;
  let unloadCount = 0;
  let deleteCount = 0;
  const progressStates: string[] = [];
  const secondSubscriberStates: string[] = [];
  const client = new BrowserLocalModelClient({
    getCapabilities: () => ({ webgpu: true, wasm: true, memory: 8 }),
    estimateStorage: async () => ({ usage: 1_150_000_000, quota: 5_000_000_000 }),
    loadWebLlm: async () => ({
      CreateMLCEngine: async (_modelId, options) => {
        initializeCount += 1;
        options.initProgressCallback({ progress: 0.5, text: 'Downloading locally' });
        cached = true;
        return {
          chat: {
            completions: {
              create: async () => ({ choices: [{ message: { content: 'Local response' } }] }),
            },
          },
          unload: async () => {
            unloadCount += 1;
          },
        };
      },
      hasModelInCache: async (modelId) => modelId === BROWSER_MODEL_ID && cached,
      deleteModelAllInfoInCache: async () => {
        deleteCount += 1;
        cached = false;
      },
    }),
    loadTransformers: async () => ({
      pipeline: async () => {
        throw new Error('WASM should not initialize while WebGPU is available.');
      },
      ModelRegistry: {
        is_pipeline_cached: async () => false,
        clear_pipeline_cache: async () => ({ filesDeleted: 0 }),
      },
    }),
  });
  client.onProgress((progress) => progressStates.push(progress.state));
  client.onProgress((progress) => secondSubscriberStates.push(progress.state));

  await client.ensureReady();
  const cachedDiagnostics = await client.getDiagnostics();
  assert.equal(cachedDiagnostics.cacheState, 'cached');
  assert.equal(cachedDiagnostics.runtime, 'webgpu');
  assert.equal(cachedDiagnostics.estimatedModelStorageBytes, BROWSER_MODEL_ESTIMATED_STORAGE_BYTES);
  assert.equal(cachedDiagnostics.browserStorageUsageBytes, 1_150_000_000);

  await client.clearCache();
  const clearedDiagnostics = await client.getDiagnostics();
  assert.equal(clearedDiagnostics.cacheState, 'not-cached');
  assert.equal(clearedDiagnostics.estimatedModelStorageBytes, 0);
  assert.equal(unloadCount, 1);
  assert.equal(deleteCount, 1);

  await client.ensureReady();
  const rebuiltDiagnostics = await client.getDiagnostics();
  assert.equal(rebuiltDiagnostics.cacheState, 'cached');
  assert.equal(initializeCount, 2);
  assert.ok(progressStates.includes('clearing'));
  assert.equal(progressStates.at(-1), 'ready');
  assert.deepEqual(secondSubscriberStates, progressStates);
});
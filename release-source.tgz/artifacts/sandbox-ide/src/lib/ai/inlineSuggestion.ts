export type InlineAcceptance = 'word' | 'line' | 'all';

export type InlineSuggestion = {
  text: string;
  position: number;
  baseContent: string;
  filePath: string;
};

export type InlineSuggestionAction = InlineAcceptance | 'dismiss';

export type InlineSuggestionApplication =
  | {
      kind: 'applied';
      content: string;
      acceptedText: string;
      nextPosition: number;
      remaining: InlineSuggestion | null;
    }
  | {
      kind: 'stale';
      reason: 'content-changed' | 'file-switched';
    };

export function getAcceptedInlineText(text: string, acceptance: InlineAcceptance) {
  if (acceptance === 'all') return text;
  if (acceptance === 'line') {
    return text.split(/\n(?=[\s\S]*)/, 1)[0] + (text.includes('\n') ? '\n' : '');
  }
  return text.match(/^\s*\S+(?:\s+|$)/)?.[0] ?? text;
}

export function applyInlineSuggestion({
  content,
  filePath,
  suggestion,
  acceptance,
}: {
  content: string;
  filePath: string;
  suggestion: InlineSuggestion;
  acceptance: InlineAcceptance;
}): InlineSuggestionApplication {
  if (suggestion.filePath !== filePath) {
    return { kind: 'stale', reason: 'file-switched' };
  }
  if (suggestion.baseContent !== content) {
    return { kind: 'stale', reason: 'content-changed' };
  }

  const acceptedText = getAcceptedInlineText(suggestion.text, acceptance);
  const nextContent = `${content.slice(0, suggestion.position)}${acceptedText}${content.slice(suggestion.position)}`;
  const nextPosition = suggestion.position + acceptedText.length;

  return {
    kind: 'applied',
    content: nextContent,
    acceptedText,
    nextPosition,
    remaining: acceptedText.length >= suggestion.text.length
      ? null
      : {
          ...suggestion,
          text: suggestion.text.slice(acceptedText.length),
          position: nextPosition,
          baseContent: nextContent,
        },
  };
}

export function getInlineSuggestionKeyboardAction(event: {
  key: string;
  ctrlKey?: boolean;
  metaKey?: boolean;
  shiftKey?: boolean;
}): InlineSuggestionAction | null {
  if (event.key === 'Escape') return 'dismiss';
  if (event.key === 'Tab') return 'all';
  if ((event.ctrlKey || event.metaKey) && event.key === 'ArrowRight') return 'word';
  if (event.key === 'Enter' && !event.shiftKey) return 'line';
  return null;
}

export function canRequestInlineSuggestion({
  isSignedIn,
  userId,
  hydratedUserId,
  isSuggesting,
  localModelAvailable,
}: {
  isSignedIn: boolean;
  userId?: string | null;
  hydratedUserId?: string | null;
  isSuggesting: boolean;
  localModelAvailable: boolean;
}) {
  return Boolean(
    isSignedIn &&
    userId &&
    hydratedUserId === userId &&
    !isSuggesting &&
    localModelAvailable,
  );
}
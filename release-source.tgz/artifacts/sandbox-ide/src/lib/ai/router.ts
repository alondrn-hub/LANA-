import type { AgentId, AgentRequest, AgentRoute } from './types.ts';
import { fullReviewAgentOrder } from '../ai_factory/orchestrator/pipeline_rules.ts';

const allAgents: AgentId[] = fullReviewAgentOrder;

function hasAny(text: string, terms: string[]) {
  return terms.some((term) => text.includes(term));
}

export function routeRequest(request: AgentRequest): AgentRoute {
  const text = `${request.message} ${request.context.activeFile}`.toLowerCase();
  const wantsPipeline = hasAny(text, [
    'review everything',
    'review the whole',
    'full review',
    'audit',
    'check the whole',
    'all agents',
  ]);
  const wantsProjectTeam = hasAny(text, [
    'build a ',
    'build an ',
    'create a ',
    'create an ',
    'make a ',
    'make an ',
    'develop a ',
    'develop an ',
    'new app',
    'new website',
    'new platform',
    'new product',
    'project brief',
  ]);

  if (wantsPipeline || wantsProjectTeam) {
    return {
      primary: 'nova',
      pipeline: allAgents,
      reason: wantsProjectTeam
        ? 'The request is a project brief, so Nova scopes it before the specialist roles work in parallel.'
        : 'The request asks for a broad review, so each specialist contributes through the factory pipeline.',
    };
  }

  if (hasAny(text, [
    'tool',
    'formatter',
    'format json',
    'format sql',
    'jwt',
    'regex',
    'svg',
    'api tester',
    'decode token',
    'optimize svg',
  ])) {
    return { primary: 'shield', pipeline: ['shield'], reason: 'The request focuses on a developer tool, safe transformation, or validation task.' };
  }

  if (hasAny(text, ['error', 'bug', 'broken', 'crash', 'exception', 'fail', 'debug', 'stack trace'])) {
    return { primary: 'pulse', pipeline: ['pulse'], reason: 'The request contains debugging or failure signals.' };
  }
  if (hasAny(text, ['test', 'verify', 'regression', 'edge case', 'coverage', 'qa'])) {
    return { primary: 'shield', pipeline: ['shield'], reason: 'The request focuses on validation or test coverage.' };
  }
  if (hasAny(text, ['api', 'backend', 'server', 'database', 'auth', 'persist', 'endpoint', 'schema'])) {
    return { primary: 'core', pipeline: ['core'], reason: 'The request focuses on backend, data, or authentication concerns.' };
  }
  if (hasAny(text, ['ui', 'frontend', 'component', 'css', 'layout', 'responsive', 'button', 'design', 'style'])) {
    return { primary: 'pixel', pipeline: ['pixel'], reason: 'The request focuses on frontend behavior or presentation.' };
  }

  return {
    primary: 'nova',
    pipeline: ['nova'],
    reason: 'The request is broad, so Nova provides an architectural starting point.',
  };
}
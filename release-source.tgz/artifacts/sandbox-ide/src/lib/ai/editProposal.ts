export type DiffLine = { kind: 'same' | 'removed' | 'added'; text: string };

export type ProposedHunk = {
  id: string;
  originalStart: number;
  originalLines: string[];
  updatedLines: string[];
  lines: DiffLine[];
  selected: boolean;
};

export type ProposedFileChange<FilePath extends string = string> = {
  path: FilePath;
  original: string;
  updated: string;
  hunks: ProposedHunk[];
};

export type EditProposal<FilePath extends string = string> = {
  summary: string;
  changes: ProposedFileChange<FilePath>[];
};

export type EditProposalApplyResult<FilePath extends string = string> =
  | { kind: 'applied'; files: Record<FilePath, string>; hunkCount: number }
  | { kind: 'no-selection' }
  | { kind: 'stale'; paths: FilePath[] };

function splitLogicalLines(content: string): string[] {
  return content.split(/\r\n|\n/);
}

function findLineEnding(content: string): string | undefined {
  return content.match(/\r\n|\n/)?.[0];
}

function findLineStarts(content: string): { starts: number[]; endings: Array<{ start: number; text: string }> } {
  const starts = [0];
  const endings: Array<{ start: number; text: string }> = [];
  const pattern = /\r\n|\n/g;
  let match: RegExpExecArray | null;
  while ((match = pattern.exec(content)) !== null) {
    endings.push({ start: match.index, text: match[0] });
    starts.push(pattern.lastIndex);
  }
  return { starts, endings };
}

function applyHunks(original: string, updated: string, hunks: ProposedHunk[]): string {
  const { starts, endings } = findLineStarts(original);
  const lineEnding = findLineEnding(original) ?? findLineEnding(updated) ?? '\n';
  let result = original;

  [...hunks]
    .sort((left, right) => right.originalStart - left.originalStart)
    .forEach((hunk) => {
      const startIndex = hunk.originalStart;
      const endIndex = startIndex + hunk.originalLines.length;
      let rangeStart: number;
      let rangeEnd: number;
      let replacement: string;

      if (endIndex < starts.length) {
        rangeStart = starts[startIndex];
        rangeEnd = starts[endIndex];
        const boundaryEnding = hunk.originalLines.length > 0
          ? endings[endIndex - 1].text
          : lineEnding;
        replacement = hunk.updatedLines.length > 0
          ? `${hunk.updatedLines.join(lineEnding)}${boundaryEnding}`
          : '';
      } else if (startIndex < starts.length) {
        const precedingEnding = startIndex > 0 ? endings[startIndex - 1] : undefined;
        rangeStart = precedingEnding?.start ?? 0;
        rangeEnd = original.length;
        replacement = hunk.updatedLines.length > 0
          ? `${precedingEnding?.text ?? ''}${hunk.updatedLines.join(lineEnding)}`
          : '';
      } else {
        rangeStart = original.length;
        rangeEnd = original.length;
        replacement = hunk.updatedLines.length > 0
          ? `${original.length > 0 ? lineEnding : ''}${hunk.updatedLines.join(lineEnding)}`
          : '';
      }

      result = `${result.slice(0, rangeStart)}${replacement}${result.slice(rangeEnd)}`;
    });

  return result;
}

export function createHunks(original: string, updated: string, path: string): ProposedHunk[] {
  const originalLines = splitLogicalLines(original);
  const updatedLines = splitLogicalLines(updated);
  const table: number[][] = Array.from({ length: originalLines.length + 1 }, () =>
    Array<number>(updatedLines.length + 1).fill(0),
  );
  for (let originalIndex = originalLines.length - 1; originalIndex >= 0; originalIndex -= 1) {
    for (let updatedIndex = updatedLines.length - 1; updatedIndex >= 0; updatedIndex -= 1) {
      table[originalIndex][updatedIndex] = originalLines[originalIndex] === updatedLines[updatedIndex]
        ? table[originalIndex + 1][updatedIndex + 1] + 1
        : Math.max(table[originalIndex + 1][updatedIndex], table[originalIndex][updatedIndex + 1]);
    }
  }

  const operations: Array<{ kind: DiffLine['kind']; text: string; originalIndex: number }> = [];
  let originalIndex = 0;
  let updatedIndex = 0;
  while (originalIndex < originalLines.length || updatedIndex < updatedLines.length) {
    if (
      originalIndex < originalLines.length &&
      updatedIndex < updatedLines.length &&
      originalLines[originalIndex] === updatedLines[updatedIndex]
    ) {
      operations.push({ kind: 'same', text: originalLines[originalIndex], originalIndex });
      originalIndex += 1;
      updatedIndex += 1;
    } else if (
      updatedIndex < updatedLines.length &&
      (originalIndex === originalLines.length || table[originalIndex][updatedIndex + 1] >= table[originalIndex + 1][updatedIndex])
    ) {
      operations.push({ kind: 'added', text: updatedLines[updatedIndex], originalIndex });
      updatedIndex += 1;
    } else {
      operations.push({ kind: 'removed', text: originalLines[originalIndex], originalIndex });
      originalIndex += 1;
    }
  }

  const hunks: ProposedHunk[] = [];
  let current: Array<{ kind: DiffLine['kind']; text: string; originalIndex: number }> = [];
  const flush = () => {
    if (!current.length) return;
    const firstOriginalIndex = current[0].originalIndex;
    hunks.push({
      id: `${path}-${hunks.length}`,
      originalStart: firstOriginalIndex,
      originalLines: current.filter((line) => line.kind === 'removed').map((line) => line.text),
      updatedLines: current.filter((line) => line.kind === 'added').map((line) => line.text),
      lines: current.map(({ kind, text }) => ({ kind, text })),
      selected: true,
    });
    current = [];
  };
  operations.forEach((operation) => {
    if (operation.kind === 'same') flush();
    else current.push(operation);
  });
  flush();
  return hunks;
}

export function applyEditProposal<FilePath extends string>(
  workspaceFiles: Record<FilePath, string>,
  proposal: EditProposal<FilePath>,
): EditProposalApplyResult<FilePath> {
  const selected = proposal.changes
    .map((change) => ({
      change,
      hunks: change.hunks.filter((hunk) => hunk.selected),
    }))
    .filter(({ hunks }) => hunks.length > 0);

  if (!selected.length) return { kind: 'no-selection' };

  const stalePaths = selected
    .filter(({ change }) => workspaceFiles[change.path] !== change.original)
    .map(({ change }) => change.path);
  if (stalePaths.length) return { kind: 'stale', paths: stalePaths };

  const next = { ...workspaceFiles };
  selected.forEach(({ change, hunks }) => {
    next[change.path] = applyHunks(change.original, change.updated, hunks);
  });

  return {
    kind: 'applied',
    files: next,
    hunkCount: selected.reduce((total, item) => total + item.hunks.length, 0),
  };
}
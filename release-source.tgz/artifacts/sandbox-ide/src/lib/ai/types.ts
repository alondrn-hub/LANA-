export type AgentId = 'nova' | 'pixel' | 'core' | 'pulse' | 'shield';

export type WorkspaceFile = {
  path: string;
  content: string;
  kind: 'code' | 'json' | 'text';
};

export type ContextSource = {
  path: string;
  reason: 'active' | 'instructions' | 'referenced' | 'relevant' | 'open-tab' | 'selected';
};

export type WorkspaceContext = {
  activeFile: string;
  activeContent: string;
  files: WorkspaceFile[];
  openTabs?: string[];
  selectedPaths?: string[];
  instructions?: string;
  contextSources?: ContextSource[];
  omittedPaths?: string[];
  contextSummary?: {
    includedFiles: number;
    omittedFiles: number;
    characterCount: number;
    characterLimit: number;
  };
  previewState?: 'idle' | 'running' | 'ready' | 'error';
  terminalOutput?: string;
};

export type AgentRequest = {
  message: string;
  context: WorkspaceContext;
  priorResults?: Array<Pick<AgentResult, 'agent' | 'label' | 'content'>>;
};

export type LocalModelMessage = {
  role: 'system' | 'user';
  content: string;
};

export type LocalModelRequest = {
  messages: LocalModelMessage[];
  signal?: AbortSignal;
};

export type LocalModelResponse = {
  content: string;
  model: string;
  done: boolean;
};

export interface LocalModelClient {
  readonly model: string;
  chat(request: LocalModelRequest): Promise<LocalModelResponse>;
}

export type AgentResult = {
  agent: AgentId;
  label: string;
  content: string;
  model: string;
  workerId?: string;
};

export type AgentWorker = {
  id: string;
  label: string;
  responsibility: string;
  instruction: string;
};

export type Agent = {
  id: AgentId;
  label: string;
  role: string;
  run(
    request: AgentRequest,
    client: LocalModelClient,
    worker?: AgentWorker,
  ): Promise<AgentResult>;
};

export type AgentRoute = {
  primary: AgentId;
  pipeline: AgentId[];
  reason: string;
};

export type OrchestrationResult = {
  route: AgentRoute;
  results: AgentResult[];
  content: string;
  model: string;
};
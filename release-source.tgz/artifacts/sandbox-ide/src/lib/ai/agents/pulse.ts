import { createAgent } from './shared.ts';

export const pulse = createAgent(
  'pulse',
  'Pulse',
  'Debugger',
  'Focus on reproducing failures, reading the available error or terminal context, isolating likely causes, and ordering diagnostic steps from cheapest to most informative.',
);
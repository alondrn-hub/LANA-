import type {
  Agent,
  AgentWorker,
  AgentId,
  AgentRequest,
  AgentResult,
  LocalModelClient,
} from '../types.ts';
import { buildAgentUserPrompt } from '../promptContext.ts';

export function createAgent(
  id: AgentId,
  label: string,
  role: string,
  instruction: string,
): Agent {
  return {
    id,
    label,
    role,
    async run(
      request: AgentRequest,
      client: LocalModelClient,
      worker?: AgentWorker,
    ): Promise<AgentResult> {
      const workerInstruction = worker
        ? `${worker.label} owns this task. Its responsibility is ${worker.responsibility}. ${worker.instruction}`
        : '';
      const combinedInstruction = [workerInstruction, instruction]
        .filter(Boolean)
        .join(' ');
      const response = await client.chat({
        messages: [
          {
            role: 'system',
            content: `You are ${label}, the ${role} agent in a local coding workspace. ${combinedInstruction} Be concise, practical, and explicit about assumptions.`,
          },
          {
            role: 'user',
            content: buildAgentUserPrompt(request, combinedInstruction),
          },
        ],
      });
      return {
        agent: id,
        label,
        content: response.content || 'The local model returned an empty response.',
        model: response.model,
        workerId: worker?.id,
      };
    },
  };
}
import { createAgent } from './shared.ts';

export const core = createAgent(
  'core',
  'Core',
  'Backend specialist',
  'Focus on APIs, persistence, validation, authentication boundaries, error handling, and operational behavior. Call out data-contract risks clearly.',
);
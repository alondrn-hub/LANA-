import {
  sendAiChat,
  type AiChatMessage,
  type AiProvider,
} from '@workspace/api-client-react';
import type { LocalModelClient, LocalModelRequest, LocalModelResponse } from './types';

export class CloudModelError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'CloudModelError';
  }
}

function messageFromError(error: unknown) {
  if (typeof error === 'object' && error !== null && 'data' in error) {
    const data = (error as { data?: unknown }).data;
    if (typeof data === 'object' && data !== null && 'error' in data && typeof data.error === 'string') {
      return data.error;
    }
  }
  if (error instanceof Error && error.message) {
    return error.message.replace(/^HTTP \d+[^:]*:\s*/, '');
  }
  return 'The cloud provider request failed. Check the connection and try again.';
}

export class CloudModelClient implements LocalModelClient {
  readonly model = 'cloud';

  constructor(private readonly provider: AiProvider) {}

  async chat({ messages, signal }: LocalModelRequest): Promise<LocalModelResponse> {
    try {
      const response = await sendAiChat({
        provider: this.provider,
        messages: messages as AiChatMessage[],
      }, { signal });
      return {
        content: response.content,
        model: response.model,
        done: response.done,
      };
    } catch (error) {
      throw new CloudModelError(messageFromError(error));
    }
  }
}

export function cloudModelErrorMessage(error: unknown) {
  return error instanceof CloudModelError
    ? error.message
    : 'The cloud provider request failed. Check the connection and try again.';
}
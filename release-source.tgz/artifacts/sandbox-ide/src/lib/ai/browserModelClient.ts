import type { LocalModelClient, LocalModelRequest, LocalModelResponse } from './types.ts';

export const BROWSER_MODEL_ID = 'Llama-3.2-1B-Instruct-q4f16_1-MLC';
export const BROWSER_MODEL_SIZE = '740 MB download · about 1.1 GB storage';
export const BROWSER_MODEL_ESTIMATED_STORAGE_BYTES = 1_100_000_000;
export const WASM_MODEL_ID = 'onnx-community/Llama-3.2-1B-Instruct-ONNX';

export type BrowserRuntime = 'webgpu' | 'wasm';
export type BrowserModelCacheState = 'checking' | 'cached' | 'not-cached' | 'unknown';
export type BrowserModelProgress = {
  state: 'checking' | 'clearing' | 'downloading' | 'loading' | 'ready' | 'unsupported' | 'memory-pressure' | 'error';
  runtime?: BrowserRuntime;
  progress?: number;
  message: string;
};
export type BrowserModelDiagnostics = {
  cacheState: BrowserModelCacheState;
  runtime?: BrowserRuntime;
  modelId: string;
  estimatedModelStorageBytes: number;
  browserStorageUsageBytes?: number;
  browserStorageQuotaBytes?: number;
};

type ProgressListener = (progress: BrowserModelProgress) => void;
type BrowserCapabilities = { webgpu: boolean; wasm: boolean; memory?: number };
type BrowserEngine = {
  chat: {
    completions: {
      create: (request: {
        messages: LocalModelRequest['messages'];
        max_tokens: number;
        temperature: number;
      }) => Promise<{ choices?: Array<{ message?: { content?: string } }> }>;
    };
  };
  unload?: () => Promise<void>;
};
type WebLlmModule = {
  CreateMLCEngine: (
    modelId: string,
    options: {
      initProgressCallback: (progress: { progress: number; text?: string }) => void;
    },
  ) => Promise<unknown>;
  hasModelInCache: (modelId: string) => Promise<boolean>;
  deleteModelAllInfoInCache: (modelId: string) => Promise<void>;
};
type WasmGenerator = {
  (prompt: string, options: {
    max_new_tokens: number;
    temperature: number;
    return_full_text: boolean;
  }): Promise<unknown>;
  dispose?: () => Promise<void> | void;
};
type TransformersModule = {
  pipeline: (
    task: 'text-generation',
    modelId: string,
    options: {
      dtype: 'q4';
      device: 'wasm';
      progress_callback: (progress: { progress?: number; status?: string }) => void;
    },
  ) => Promise<WasmGenerator>;
  ModelRegistry: {
    is_pipeline_cached: (
      task: 'text-generation',
      modelId: string,
      options: { dtype: 'q4'; device: 'wasm' },
    ) => Promise<boolean>;
    clear_pipeline_cache: (
      task: 'text-generation',
      modelId: string,
      options: { dtype: 'q4'; device: 'wasm' },
    ) => Promise<unknown>;
  };
};
type BrowserModelClientOptions = {
  getCapabilities?: () => BrowserCapabilities;
  loadWebLlm?: () => Promise<WebLlmModule>;
  loadTransformers?: () => Promise<TransformersModule>;
  estimateStorage?: () => Promise<{ usage?: number; quota?: number }>;
};

function browserCapabilities(): BrowserCapabilities {
  if (typeof window === 'undefined') return { webgpu: false, wasm: false, memory: undefined };
  const webgpu = 'gpu' in navigator;
  const wasm = typeof WebAssembly !== 'undefined' && typeof Worker !== 'undefined';
  const memory = (navigator as Navigator & { deviceMemory?: number }).deviceMemory;
  return { webgpu, wasm, memory };
}

export class BrowserLocalModelClient implements LocalModelClient {
  readonly model = BROWSER_MODEL_ID;
  private engine: BrowserEngine | null = null;
  private wasmPipeline: ((messages: LocalModelRequest['messages']) => Promise<string>) | null = null;
  private disposeWasmPipeline: (() => Promise<void> | void) | null = null;
  private initPromise: Promise<void> | null = null;
  private queue: Promise<unknown> = Promise.resolve();
  private cacheOperationPromise: Promise<void> | null = null;
  private readonly listeners = new Set<ProgressListener>();
  private activeRuntime?: BrowserRuntime;
  private readonly getCapabilities: () => BrowserCapabilities;
  private readonly loadWebLlm: () => Promise<WebLlmModule>;
  private readonly loadTransformers: () => Promise<TransformersModule>;
  private readonly estimateStorage: () => Promise<{ usage?: number; quota?: number }>;

  constructor(options: BrowserModelClientOptions = {}) {
    this.getCapabilities = options.getCapabilities ?? browserCapabilities;
    this.loadWebLlm = options.loadWebLlm ?? (async () => import('@mlc-ai/web-llm') as Promise<WebLlmModule>);
    this.loadTransformers = options.loadTransformers ?? (async () => import('@huggingface/transformers') as unknown as Promise<TransformersModule>);
    this.estimateStorage = options.estimateStorage ?? (async () => {
      if (typeof navigator === 'undefined' || !navigator.storage?.estimate) return {};
      return navigator.storage.estimate();
    });
  }

  onProgress(listener: ProgressListener) {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  }

  private emitProgress(progress: BrowserModelProgress) {
    for (const listener of this.listeners) listener(progress);
  }

  get capabilities() {
    return this.getCapabilities();
  }

  get runtime() {
    return this.activeRuntime;
  }

  async ensureReady() {
    if (this.cacheOperationPromise) await this.cacheOperationPromise;
    if (this.engine || this.wasmPipeline) return;
    this.initPromise ??= this.initialize().catch((error) => {
      this.initPromise = null;
      throw error;
    });
    await this.initPromise;
  }

  async getDiagnostics(): Promise<BrowserModelDiagnostics> {
    const runtime = this.activeRuntime ?? (this.capabilities.webgpu ? 'webgpu' : this.capabilities.wasm ? 'wasm' : undefined);
    const storage: { usage?: number; quota?: number } = await this.estimateStorage().catch(() => ({}));
    let cacheState: BrowserModelCacheState = 'unknown';

    try {
      if (runtime === 'webgpu') {
        const webllm = await this.loadWebLlm();
        cacheState = await webllm.hasModelInCache(BROWSER_MODEL_ID) ? 'cached' : 'not-cached';
      } else if (runtime === 'wasm') {
        const transformers = await this.loadTransformers();
        cacheState = await transformers.ModelRegistry.is_pipeline_cached(
          'text-generation',
          WASM_MODEL_ID,
          { dtype: 'q4', device: 'wasm' },
        ) ? 'cached' : 'not-cached';
      }
    } catch {
      cacheState = this.engine || this.wasmPipeline ? 'cached' : 'unknown';
    }

    return {
      cacheState,
      runtime,
      modelId: runtime === 'wasm' ? WASM_MODEL_ID : BROWSER_MODEL_ID,
      estimatedModelStorageBytes: cacheState === 'cached' ? BROWSER_MODEL_ESTIMATED_STORAGE_BYTES : 0,
      browserStorageUsageBytes: storage.usage,
      browserStorageQuotaBytes: storage.quota,
    };
  }

  async clearCache() {
    if (this.cacheOperationPromise) return this.cacheOperationPromise;
    const clear = this.queue.then(async () => {
      const runtimeToClear = this.activeRuntime ?? (this.capabilities.webgpu ? 'webgpu' : 'wasm');
      this.emitProgress({
        state: 'clearing',
        runtime: this.activeRuntime,
        message: 'Removing the browser model cache…',
      });
      await this.initPromise?.catch(() => undefined);
      await this.engine?.unload?.();
      await this.disposeWasmPipeline?.();
      this.engine = null;
      this.wasmPipeline = null;
      this.disposeWasmPipeline = null;
      this.activeRuntime = undefined;
      this.initPromise = null;

      const results = await Promise.allSettled([
        this.loadWebLlm().then((webllm) => webllm.deleteModelAllInfoInCache(BROWSER_MODEL_ID)),
        this.loadTransformers().then((transformers) => transformers.ModelRegistry.clear_pipeline_cache(
          'text-generation',
          WASM_MODEL_ID,
          { dtype: 'q4', device: 'wasm' },
        )),
      ]);
      const activeRuntimeResult = results[runtimeToClear === 'webgpu' ? 0 : 1];
      if (activeRuntimeResult.status === 'rejected') {
        throw new BrowserModelError('The browser model cache could not be cleared. Close other LANA DEV tabs and try again.', 'error');
      }
      this.emitProgress({
        state: 'checking',
        progress: 0,
        message: 'Browser model cache cleared. Preparing a fresh local copy…',
      });
    });
    this.queue = clear.then(() => undefined, () => undefined);
    const trackedClear = clear.finally(() => {
      if (this.cacheOperationPromise === trackedClear) this.cacheOperationPromise = null;
    });
    this.cacheOperationPromise = trackedClear;
    return trackedClear;
  }

  private async initialize() {
    const { webgpu, wasm, memory } = this.getCapabilities();
    this.emitProgress({ state: 'checking', message: `Checking this browser · ${BROWSER_MODEL_SIZE}` });
    if (!webgpu && !wasm) {
      throw new BrowserModelError('This browser does not support WebGPU or WASM. Use the latest Chrome, Edge, Firefox, or Safari.', 'unsupported');
    }
    if (memory !== undefined && memory < 4) {
      throw new BrowserModelError('This device reports less than 4 GB memory. Close other tabs or use a device with more memory, then retry.', 'memory-pressure');
    }
    if (webgpu) {
      this.emitProgress({ state: 'downloading', runtime: 'webgpu', progress: 0, message: `Downloading the approved Llama model · ${BROWSER_MODEL_SIZE}` });
      try {
        const webllm = await this.loadWebLlm();
        const engine = await webllm.CreateMLCEngine(BROWSER_MODEL_ID, {
          initProgressCallback: (progress) => this.emitProgress({
            state: progress.progress < 1 ? 'downloading' : 'loading',
            runtime: 'webgpu',
            progress: progress.progress,
            message: progress.text || 'Preparing the cached browser model…',
          }),
        });
        this.engine = engine as BrowserEngine;
        this.activeRuntime = 'webgpu';
        this.emitProgress({ state: 'ready', runtime: 'webgpu', progress: 1, message: 'Llama is ready in this browser · prompts stay on this device.' });
        return;
      } catch (error) {
        if (!wasm) throw new BrowserModelError(
          error instanceof Error ? `WebGPU could not start: ${error.message}` : 'WebGPU could not start. Retry after closing other GPU-heavy tabs.',
          'error',
        );
        this.emitProgress({ state: 'loading', runtime: 'wasm', message: 'WebGPU is unavailable here. Trying the WASM fallback…' });
      }
    }
    this.emitProgress({ state: 'downloading', runtime: 'wasm', progress: 0, message: 'Downloading the WASM fallback model. It is slower but stays on this device.' });
    try {
      const { pipeline } = await this.loadTransformers();
      const generator = await pipeline('text-generation', WASM_MODEL_ID, {
        dtype: 'q4',
        device: 'wasm',
        progress_callback: (progress: { progress?: number; status?: string }) => this.emitProgress({
          state: 'downloading',
          runtime: 'wasm',
          progress: typeof progress.progress === 'number' ? progress.progress / 100 : undefined,
          message: progress.status || 'Caching the WASM model…',
        }),
      });
      this.wasmPipeline = async (messages) => {
        const prompt = messages.map((message) => `${message.role}: ${message.content}`).join('\n');
        const result = await generator(prompt, { max_new_tokens: 384, temperature: 0.2, return_full_text: false });
        const first = Array.isArray(result) ? result[0] as { generated_text?: string } : undefined;
        return first?.generated_text?.trim() ?? '';
      };
      this.disposeWasmPipeline = generator.dispose ? () => generator.dispose!() : null;
      this.activeRuntime = 'wasm';
      this.emitProgress({ state: 'ready', runtime: 'wasm', progress: 1, message: 'Llama is ready through WASM · prompts stay on this device.' });
    } catch (error) {
      throw new BrowserModelError(error instanceof Error ? `The browser model could not be loaded: ${error.message}` : 'The browser model could not be loaded. Retry after closing other tabs.', 'error');
    }
  }

  async chat({ messages, signal }: LocalModelRequest): Promise<LocalModelResponse> {
    const run = async () => {
      if (signal?.aborted) throw new BrowserModelError('The local model request was cancelled.', 'error');
      await this.ensureReady();
      if (signal?.aborted) throw new BrowserModelError('The local model request was cancelled.', 'error');
      if (this.engine) {
        const response = await this.engine.chat.completions.create({ messages, max_tokens: 900, temperature: 0.2 });
        const content = response.choices?.[0]?.message?.content;
        if (typeof content !== 'string') throw new BrowserModelError('The browser runtime returned an invalid response.', 'error');
        return { content: content.trim(), model: this.model, done: true };
      }
      const content = await this.wasmPipeline!(messages);
      return { content, model: WASM_MODEL_ID, done: true };
    };
    const result = this.queue.then(run, run);
    this.queue = result.then(() => undefined, () => undefined);
    return result;
  }
}

export class BrowserModelError extends Error {
  readonly code: 'unsupported' | 'memory-pressure' | 'error';

  constructor(message: string, code: 'unsupported' | 'memory-pressure' | 'error') {
    super(message);
    this.name = 'BrowserModelError';
    this.code = code;
  }
}

export const browserLocalModelClient = new BrowserLocalModelClient();
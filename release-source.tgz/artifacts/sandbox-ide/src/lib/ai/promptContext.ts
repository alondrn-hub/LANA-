import type { AgentRequest, WorkspaceContext } from './types.ts';

const MAX_FILE_CONTENT = 12_000;
const MAX_ADDITIONAL_FILE_CONTENT = 18_000;
const MAX_SINGLE_ADDITIONAL_FILE = 6_000;
const MAX_TERMINAL_OUTPUT = 4_000;
const MAX_PRIOR_REVIEW_CONTENT = 8_000;
const MAX_SINGLE_PRIOR_RESULT = 2_000;
const MAX_PROMPT_CONTEXT = MAX_FILE_CONTENT + MAX_ADDITIONAL_FILE_CONTENT + 4_000;

export function buildPromptContext(context: WorkspaceContext) {
  const files = context.files
    .map((file) => `${file.path} (${file.kind})`)
    .join(', ');
  const activeContent = context.activeContent.length > MAX_FILE_CONTENT
    ? `${context.activeContent.slice(0, MAX_FILE_CONTENT)}\n… [file truncated]`
    : context.activeContent;
  const terminalOutput = context.terminalOutput
    ? context.terminalOutput.slice(-MAX_TERMINAL_OUTPUT)
    : 'No terminal output yet.';
  const instructions = context.instructions
    ? context.instructions.slice(0, 4_000)
    : 'No project instructions were supplied.';
  const contextSources = context.contextSources?.length
    ? context.contextSources.map((source) => `${source.path} (${source.reason})`).join(', ')
    : 'Active file only.';
  const openTabs = context.openTabs?.length ? context.openTabs.join(', ') : 'None.';
  const omittedPaths = context.omittedPaths?.length ? context.omittedPaths.join(', ') : 'None.';
  let remainingFileBudget = MAX_ADDITIONAL_FILE_CONTENT;
  const relatedFiles = context.files
    .filter((file) => file.path !== context.activeFile)
    .flatMap((file) => {
      if (remainingFileBudget <= 0) return [];
      const limit = Math.min(MAX_SINGLE_ADDITIONAL_FILE, remainingFileBudget);
      const content = file.content.slice(0, limit);
      remainingFileBudget -= content.length;
      const suffix = file.content.length > content.length ? '\n… [file truncated]' : '';
      return [`--- ${file.path} (${file.kind}) ---\n${content}${suffix}\n--- end ${file.path} ---`];
    });

  return [
    `Active file: ${context.activeFile}`,
    `Preview state: ${context.previewState ?? 'idle'}`,
    `Workspace files: ${files || 'No files listed.'}`,
    `Open tabs: ${openTabs}`,
    `Selected context: ${contextSources}`,
    `Context budget: ${context.contextSummary?.characterCount ?? 'bounded'} / ${context.contextSummary?.characterLimit ?? MAX_PROMPT_CONTEXT} characters`,
    `Omitted from request: ${omittedPaths}`,
    '',
    '--- project instructions ---',
    instructions,
    '--- end project instructions ---',
    '',
    `--- ${context.activeFile} ---`,
    activeContent,
    '--- end active file ---',
    '',
    '--- related workspace files ---',
    relatedFiles.join('\n\n') || 'No additional workspace files were supplied.',
    '--- end related workspace files ---',
    '',
    '--- terminal output ---',
    terminalOutput,
    '--- end terminal output ---',
  ].join('\n');
}

export function buildAgentUserPrompt(request: AgentRequest, instruction: string) {
  let remainingPriorBudget = MAX_PRIOR_REVIEW_CONTENT;
  const priorResults = request.priorResults?.length
    ? request.priorResults.flatMap((result) => {
      if (remainingPriorBudget <= 0) return [];
      const limit = Math.min(MAX_SINGLE_PRIOR_RESULT, remainingPriorBudget);
      const content = result.content.slice(0, limit);
      remainingPriorBudget -= content.length;
      const suffix = result.content.length > content.length ? '\n… [review truncated]' : '';
      return [`### ${result.label}\n${content}${suffix}`];
    }).join('\n\n')
    : 'No earlier agent review is available.';

  return [
    instruction,
    '',
    `Developer request: ${request.message}`,
    '',
    '--- earlier agent review ---',
    priorResults,
    '--- end earlier agent review ---',
    '',
    buildPromptContext(request.context),
    '',
    'Do not modify files or claim to have run commands. Give concrete reasoning and next steps based only on the supplied workspace context.',
  ].join('\n');
}
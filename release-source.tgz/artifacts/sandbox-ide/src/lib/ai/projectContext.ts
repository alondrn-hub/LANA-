import type { ContextSource, WorkspaceFile } from './types.ts';

const MAX_CONTEXT_FILES = 8;
const MIN_QUERY_TOKEN_LENGTH = 3;
const STOP_WORDS = new Set([
  'about', 'after', 'before', 'build', 'change', 'could', 'files', 'from',
  'have', 'into', 'make', 'need', 'please', 'project', 'that', 'this',
  'with', 'would', 'your',
]);

type ProjectContextInput = {
  message: string;
  activeFile: string;
  files: WorkspaceFile[];
  openTabs?: string[];
  selectedPaths?: string[];
};

export type ProjectContextBundle = {
  files: WorkspaceFile[];
  instructions?: string;
  sources: ContextSource[];
  omittedPaths: string[];
};

function getQueryTokens(message: string) {
  return [...new Set(
    message
      .toLowerCase()
      .split(/[^a-z0-9_./-]+/)
      .filter((token) => token.length >= MIN_QUERY_TOKEN_LENGTH && !STOP_WORDS.has(token)),
  )];
}

function scoreFile(file: WorkspaceFile, message: string, tokens: string[]) {
  const haystack = `${file.path}\n${file.content.slice(0, 8000)}`.toLowerCase();
  const explicitlyReferenced = message.includes(file.path.toLowerCase())
    || message.includes(`@${file.path.toLowerCase()}`)
    || message.includes(file.path.split('/').at(-1)?.toLowerCase() ?? '');

  if (explicitlyReferenced) return { score: 10_000, reason: 'referenced' as const };

  const score = tokens.reduce((total, token) => (
    total
      + (file.path.toLowerCase().includes(token) ? 9 : 0)
      + (haystack.includes(token) ? 2 : 0)
  ), 0);
  return { score, reason: 'relevant' as const };
}

export function buildProjectContext({
  message,
  activeFile,
  files,
  openTabs = [],
  selectedPaths = [],
}: ProjectContextInput): ProjectContextBundle {
  const active = files.find((file) => file.path === activeFile);
  const instructionsFile = files.find((file) => /^(?:\.lana|lana)\.md$/i.test(file.path));
  const selected: WorkspaceFile[] = [];
  const sources: ContextSource[] = [];
  const explicitlyReferenced = new Set<string>();
  const messageTokens = message.toLowerCase().split(/[^a-z0-9_./@-]+/).filter(Boolean);
  files.forEach((file) => {
    const lowerPath = file.path.toLowerCase();
    if (messageTokens.some((token) => {
      const reference = token.replace(/^@/, '');
      return reference === lowerPath || lowerPath.startsWith(`${reference}/`);
    })) explicitlyReferenced.add(file.path);
  });
  const add = (file: WorkspaceFile | undefined, reason: ContextSource['reason']) => {
    if (!file || selected.some((item) => item.path === file.path)) return;
    if (selected.length >= MAX_CONTEXT_FILES) return;
    selected.push(file);
    sources.push({ path: file.path, reason });
  };

  add(active, 'active');
  add(instructionsFile, 'instructions');
  openTabs.forEach((path) => add(files.find((file) => file.path === path), 'open-tab'));
  selectedPaths.forEach((path) => {
    files
      .filter((file) => file.path === path || file.path.startsWith(`${path.replace(/\/$/, '')}/`))
      .forEach((file) => add(file, 'selected'));
  });
  [...explicitlyReferenced]
    .map((path) => files.find((file) => file.path === path))
    .forEach((file) => add(file, 'referenced'));

  const normalizedMessage = message.toLowerCase();
  const tokens = getQueryTokens(message);
  files
    .filter((file) => file.path !== activeFile && file.path !== instructionsFile?.path)
    .map((file) => ({ file, ...scoreFile(file, normalizedMessage, tokens) }))
    .filter(({ score }) => score > 0)
    .sort((left, right) => right.score - left.score || left.file.path.localeCompare(right.file.path))
    .forEach(({ file, reason }) => add(file, reason));

  return {
    files: selected,
    instructions: instructionsFile?.content.slice(0, 4000),
    sources,
    omittedPaths: files.filter((file) => !selected.some((item) => item.path === file.path)).map((file) => file.path),
  };
}
import type {
  LocalModelClient,
  LocalModelRequest,
  LocalModelResponse,
} from './types';
import { isDesktopRuntime } from './desktopRuntime.ts';
import { getAndroidBridge, isAndroidRuntime } from './androidRuntime.ts';
import { browserLocalModelClient } from './browserModelClient.ts';

const DEFAULT_BASE_URL = 'http://localhost:11434';
const DEFAULT_MODEL = 'qwen2.5-coder';
const DEFAULT_TIMEOUT_MS = 45_000;
const viteEnv = (import.meta as ImportMeta & {
  env?: Record<string, string | boolean | undefined>;
}).env ?? {};

type LocalModelClientOptions = {
  baseUrl?: string;
  model?: string;
  fetchImpl?: typeof fetch;
  timeoutMs?: number;
};

export class LocalModelError extends Error {
  readonly code: 'unavailable' | 'request' | 'invalid-response';

  constructor(
    message: string,
    code: 'unavailable' | 'request' | 'invalid-response',
  ) {
    super(message);
    this.name = 'LocalModelError';
    this.code = code;
  }
}

export function resolveLocalModelBaseUrl(env: {
  VITE_OLLAMA_BASE_URL?: string | boolean;
  DEV?: string | boolean;
} = {}) {
  const configuredBaseUrl = typeof env.VITE_OLLAMA_BASE_URL === 'string'
    ? env.VITE_OLLAMA_BASE_URL
    : undefined;
  const isDevelopment = env.DEV === true || env.DEV === 'true';
  const baseUrl = configuredBaseUrl ?? (isDevelopment ? '/__ollama' : DEFAULT_BASE_URL);
  return baseUrl.replace(/\/$/, '');
}

function getBaseUrl() {
  if (isDesktopRuntime()) return 'http://127.0.0.1:39271';
  // Android uses the native bridge; this value is only retained for diagnostics.
  if (isAndroidRuntime()) return 'android://llama.cpp';
  return resolveLocalModelBaseUrl(viteEnv);
}

export function isBrowserLocalRuntime() {
  return typeof window !== 'undefined' && !isDesktopRuntime() && !isAndroidRuntime();
}

export function getConfiguredModelName() {
  return typeof viteEnv.VITE_LOCAL_MODEL === 'string'
    ? viteEnv.VITE_LOCAL_MODEL
    : DEFAULT_MODEL;
}

function withTimeout(timeoutMs: number, signal?: AbortSignal) {
  const controller = new AbortController();
  const timeout = globalThis.setTimeout(() => controller.abort(), timeoutMs);

  if (signal) {
    if (signal.aborted) controller.abort();
    signal.addEventListener('abort', () => controller.abort(), { once: true });
  }

  return { signal: controller.signal, clear: () => globalThis.clearTimeout(timeout) };
}

export class OllamaLocalModelClient implements LocalModelClient {
  readonly model: string;
  private readonly baseUrl: string;
  private readonly fetchImpl?: typeof fetch;
  private readonly timeoutMs: number;

  constructor(options: LocalModelClientOptions = {}) {
    this.model = options.model ?? getConfiguredModelName();
    this.baseUrl = (options.baseUrl ?? getBaseUrl()).replace(/\/$/, '');
    this.fetchImpl = options.fetchImpl;
    this.timeoutMs = options.timeoutMs ?? DEFAULT_TIMEOUT_MS;
  }

  async chat({ messages, signal }: LocalModelRequest): Promise<LocalModelResponse> {
    const android = getAndroidBridge();
    if (android) {
      if (signal?.aborted) throw new LocalModelError('The local model request was cancelled.', 'unavailable');
      try {
        return await android.chat({ messages, signal });
      } catch (error) {
        if (error instanceof LocalModelError) throw error;
        throw new LocalModelError(
          error instanceof Error ? error.message : 'The Android local model is unavailable.',
          'unavailable',
        );
      }
    }
    const request = withTimeout(this.timeoutMs, signal);
    const desktop = isDesktopRuntime() || this.baseUrl.includes(':39271');
    let response: Response;

    try {
      response = await (this.fetchImpl ?? globalThis.fetch).call(globalThis, `${this.baseUrl}${desktop ? '/v1/chat/completions' : '/api/chat'}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          model: this.model,
          messages,
          stream: false,
          ...(desktop ? { max_tokens: 900, temperature: 0.2 } : { options: { num_predict: 900 } }),
        }),
        signal: request.signal,
      });
    } catch (error) {
      request.clear();
      const detail = error instanceof Error && error.name === 'AbortError'
        ? 'The local model request timed out.'
        : 'Ollama could not be reached. Start Ollama and try again.';
      throw new LocalModelError(detail, 'unavailable');
    }

    request.clear();

    if (!response.ok) {
      const detail = await response.text().catch(() => '');
      if (response.status === 404) {
        throw new LocalModelError(
          desktop
            ? `The bundled model "${this.model}" is not ready yet. Complete first-run setup and try again.`
            : `The configured model "${this.model}" is not available. Run: ollama pull ${this.model}`,
          'unavailable',
        );
      }
      throw new LocalModelError(
        detail || `Ollama returned HTTP ${response.status}.`,
        'request',
      );
    }

    let payload: unknown;
    try {
      payload = await response.json();
    } catch {
      throw new LocalModelError('Ollama returned an unreadable response.', 'invalid-response');
    }

    if (isDesktopRuntime()) {
      const openAiPayload = payload as { choices?: Array<{ message?: { content?: unknown } }>; model?: unknown };
      const content = openAiPayload.choices?.[0]?.message?.content;
      if (typeof content !== 'string') {
        throw new LocalModelError('The bundled llama.cpp runtime returned an invalid chat response.', 'invalid-response');
      }
      return {
        content: content.trim(),
        model: typeof openAiPayload.model === 'string' ? openAiPayload.model : this.model,
        done: true,
      };
    }
    if (
      !payload ||
      typeof payload !== 'object' ||
      !('message' in payload) ||
      !payload.message ||
      typeof payload.message !== 'object' ||
      !('content' in payload.message) ||
      typeof payload.message.content !== 'string'
    ) {
      throw new LocalModelError('Ollama returned an invalid chat response.', 'invalid-response');
    }

    return {
      content: payload.message.content.trim(),
      model: 'model' in payload && typeof payload.model === 'string' ? payload.model : this.model,
      done: 'done' in payload ? payload.done === true : true,
    };
  }
}

// Browser users get the in-page runtime; desktop and Android keep their native
// llama.cpp/Ollama-compatible clients.
export const localModelClient: LocalModelClient = isBrowserLocalRuntime()
  ? browserLocalModelClient
  : new OllamaLocalModelClient();

export function localModelErrorMessage(error: unknown) {
  if (error instanceof LocalModelError) {
    if (error.code === 'unavailable') {
      return `${error.message} This chat stays local; no cloud fallback was used. If this IDE is deployed, allow its origin in Ollama's OLLAMA_ORIGINS setting.`;
    }
    return error.message;
  }
  return isDesktopRuntime()
    ? 'The bundled local model did not return a response. Open Settings to retry first-run setup.'
    : isAndroidRuntime()
      ? 'The Android local model did not return a response. Open local model setup to retry.'
    : 'The local model did not return a response. Check Ollama and try again.';
}

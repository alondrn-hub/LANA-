import { createServer } from 'node:http';
import { once } from 'node:events';
import assert from 'node:assert/strict';
import test from 'node:test';
import { detectLocalModel } from './detectLocalModel';
import { formatAndroidRuntimeMessage } from './androidRuntime';
import {
  localModelErrorMessage,
  LocalModelError,
  OllamaLocalModelClient,
  resolveLocalModelBaseUrl,
} from './localModelClient';
import { runAgentPipeline } from './orchestrator';
import { buildProjectContext } from './projectContext';
import { routeRequest } from './router';
import type { AgentId, AgentRequest, LocalModelClient, LocalModelRequest, LocalModelResponse } from './types';

const context: AgentRequest['context'] = {
  activeFile: 'src/App.tsx',
  activeContent: 'export function App() { return null; }',
  files: [
    { path: 'src/App.tsx', content: 'export function App() { return null; }', kind: 'code' },
    { path: 'package.json', content: '{"scripts":{"test":"tsx --test"}}', kind: 'json' },
  ],
  previewState: 'ready',
  terminalOutput: 'Build output is clean.',
};

function request(message: string): AgentRequest {
  return { message, context };
}

class RecordingClient implements LocalModelClient {
  readonly model = 'fixture-model';
  readonly requests: LocalModelRequest[] = [];

  async chat(modelRequest: LocalModelRequest): Promise<LocalModelResponse> {
    this.requests.push(modelRequest);
    const systemPrompt = modelRequest.messages.find((message) => message.role === 'system')?.content ?? '';
    const label = systemPrompt.match(/^You are ([^,]+)/)?.[1] ?? 'Unknown';
    return {
      content: `${label} fixture response`,
      model: this.model,
      done: true,
    };
  }
}

test('routes each specialist request to the intended agent', () => {
  const cases: Array<[string, AgentId]> = [
    ['How should I structure this feature?', 'nova'],
    ['Fix the responsive button layout and CSS.', 'pixel'],
    ['Review the API endpoint and database schema.', 'core'],
    ['Debug the crash and stack trace.', 'pulse'],
    ['Verify the regression with an edge-case test.', 'shield'],
  ];

  for (const [message, expectedAgent] of cases) {
    const route = routeRequest(request(message));
    assert.deepEqual(route.pipeline, [expectedAgent]);
    assert.equal(route.primary, expectedAgent);
  }
});

test('builds bounded context from open tabs, explicit files, and folders', () => {
  const files = [
    { path: 'src/App.tsx', content: 'app', kind: 'code' as const },
    { path: 'src/components/Button.tsx', content: 'button', kind: 'code' as const },
    { path: 'README.md', content: 'readme', kind: 'text' as const },
    { path: 'LANA.md', content: 'rules', kind: 'text' as const },
  ];
  const bundle = buildProjectContext({
    message: 'Review @README.md and the src folder',
    activeFile: 'src/App.tsx',
    openTabs: ['README.md'],
    selectedPaths: ['src'],
    files,
  });

  assert.deepEqual(bundle.files.map((file) => file.path), [
    'src/App.tsx',
    'LANA.md',
    'README.md',
    'src/components/Button.tsx',
  ]);
  assert.deepEqual(bundle.sources.map((source) => source.reason), [
    'active', 'instructions', 'open-tab', 'selected',
  ]);
  assert.deepEqual(bundle.omittedPaths, []);
});

test('uses the direct Ollama transport in production and the proxy only in development', () => {
  assert.equal(resolveLocalModelBaseUrl({ DEV: false }), 'http://localhost:11434');
  assert.equal(resolveLocalModelBaseUrl({ DEV: true }), '/__ollama');
  assert.equal(
    resolveLocalModelBaseUrl({
      DEV: false,
      VITE_OLLAMA_BASE_URL: 'https://model.example/',
    }),
    'https://model.example',
  );
});

test('runs the full review in the staged specialist order and passes earlier reviews forward', async () => {
  const client = new RecordingClient();
  const result = await runAgentPipeline(request('Please do a full review of this workspace.'), client);

  assert.deepEqual(result.route.pipeline, ['nova', 'pixel', 'core', 'pulse', 'shield']);
  assert.deepEqual(result.results.map(({ agent }) => agent), ['nova', 'pixel', 'core', 'pulse', 'shield']);
  assert.match(client.requests[1].messages[1].content, /### Nova/);
  assert.match(client.requests[4].messages[1].content, /### Core/);
  assert.match(result.content, /### Nova/);
  assert.match(result.content, /### Shield/);
});

test('parses a controlled Ollama-compatible response through the real local client', async (t) => {
  const server = createServer(async (incoming, response) => {
    if (incoming.url !== '/api/chat' || incoming.method !== 'POST') {
      response.writeHead(404).end();
      return;
    }
    for await (const _chunk of incoming) {
      // Consume the request body to model Ollama's normal HTTP behavior.
    }
    response.writeHead(200, { 'Content-Type': 'application/json' });
    response.end(JSON.stringify({
      model: 'fixture-model',
      message: { role: 'assistant', content: 'The fixture model can see the active file.' },
      done: true,
    }));
  });
  t.after(() => server.close());
  server.listen(0, '127.0.0.1');
  await once(server, 'listening');
  const address = server.address();
  assert.ok(address && typeof address === 'object');

  const client = new OllamaLocalModelClient({
    baseUrl: `http://127.0.0.1:${address.port}`,
    model: 'fixture-model',
    timeoutMs: 1_000,
  });
  const result = await client.chat({
    messages: [{ role: 'user', content: 'Review the active file.' }],
  });

  assert.equal(result.content, 'The fixture model can see the active file.');
  assert.equal(result.model, 'fixture-model');
  assert.equal(result.done, true);
});

test('calls the configured fetch transport with the browser-global receiver', async () => {
  let receiver: unknown;
  const client = new OllamaLocalModelClient({
    baseUrl: 'http://fixture-ollama',
    model: 'fixture-model',
    fetchImpl: function () {
      receiver = this;
      return Promise.resolve(new Response(JSON.stringify({
        model: 'fixture-model',
        message: { role: 'assistant', content: 'Bound transport response.' },
        done: true,
      }), { status: 200, headers: { 'Content-Type': 'application/json' } }));
    },
  });

  await client.chat({ messages: [{ role: 'user', content: 'Check the transport binding.' }] });

  assert.equal(receiver, globalThis);
});

test('reports a running Ollama daemon with a missing model as actionable', async () => {
  const status = await detectLocalModel(undefined, {
    baseUrl: 'http://fixture-ollama',
    configuredModel: 'qwen2.5-coder',
    fetchImpl: async () => new Response(JSON.stringify({
      models: [{ name: 'llama3.2:latest' }],
    }), { status: 200, headers: { 'Content-Type': 'application/json' } }),
  });

  assert.equal(status.available, false);
  assert.match(status.error ?? '', /ollama pull qwen2\.5-coder/);
});

test('keeps offline errors local and does not imply a cloud fallback', async () => {
  const error = new LocalModelError('Ollama could not be reached. Start Ollama and try again.', 'unavailable');
  assert.match(localModelErrorMessage(error), /This chat stays local; no cloud fallback was used/);
  assert.match(localModelErrorMessage(error), /OLLAMA_ORIGINS/);

  const status = await detectLocalModel(undefined, {
    baseUrl: 'http://offline-ollama',
    configuredModel: 'fixture-model',
    fetchImpl: async () => {
      throw new Error('Failed to fetch');
    },
  });
  assert.equal(status.available, false);
  assert.equal(status.error, 'Failed to fetch');
});

test('formats Android model provisioning and memory states for the workspace', () => {
  assert.equal(formatAndroidRuntimeMessage({
    state: 'downloading',
    message: 'Copying model',
    model: 'lana-qwen2.5-coder-q4',
    modelSizeBytes: 100,
    modelDownloadedBytes: 42,
    acceleration: 'cpu',
  }), 'Downloading local model · 42%');
  assert.equal(formatAndroidRuntimeMessage({
    state: 'memory-pressure',
    message: 'Free memory is below the model requirement.',
    model: 'lana-qwen2.5-coder-q4',
    acceleration: 'cpu',
  }), 'Free memory is below the model requirement.');
});
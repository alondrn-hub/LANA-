import {
  getConfiguredModelName,
  LocalModelError,
  resolveLocalModelBaseUrl,
} from './localModelClient.ts';
import { getDesktopBridge } from './desktopRuntime.ts';
import { formatAndroidRuntimeMessage, getAndroidBridge } from './androidRuntime.ts';
import {
  browserLocalModelClient,
  BROWSER_MODEL_ID,
  BROWSER_MODEL_SIZE,
  BrowserModelError,
  type BrowserModelCacheState,
} from './browserModelClient.ts';
import { isBrowserLocalRuntime } from './localModelClient.ts';

const viteEnv = (import.meta as ImportMeta & {
  env?: Record<string, string | boolean | undefined>;
}).env ?? {};

export type LocalModelStatus = {
  available: boolean;
  models: string[];
  baseUrl: string;
  configuredModel: string;
  runtimeState?: string;
  runtimeMessage?: string;
  error?: string;
  runtime?: 'webgpu' | 'wasm';
  progress?: number;
  cacheState?: BrowserModelCacheState;
  estimatedModelStorageBytes?: number;
  browserStorageUsageBytes?: number;
  browserStorageQuotaBytes?: number;
};

function getBaseUrl() {
  return resolveLocalModelBaseUrl(viteEnv);
}

type DetectLocalModelOptions = {
  baseUrl?: string;
  configuredModel?: string;
  fetchImpl?: typeof fetch;
};
export async function detectLocalModel(
  signal?: AbortSignal,
  options: DetectLocalModelOptions = {},
): Promise<LocalModelStatus> {
  const desktop = getDesktopBridge();
  if (desktop) {
    const runtime = await desktop.getRuntimeState();
    return {
      available: runtime.state === 'ready',
      models: runtime.state === 'ready' ? [runtime.model] : [],
      baseUrl: 'http://127.0.0.1:39271',
      configuredModel: runtime.model,
      runtimeState: runtime.state,
      runtimeMessage: runtime.message,
      error: runtime.state === 'ready' ? undefined : runtime.message,
    };
  }
  const android = getAndroidBridge();
  if (android) {
    const runtime = await android.getRuntimeStatus();
    return {
      available: runtime.state === 'ready',
      models: runtime.state === 'ready' ? [runtime.model] : [],
      baseUrl: 'android://llama.cpp',
      configuredModel: runtime.model,
      runtimeState: runtime.state,
      runtimeMessage: runtime.message,
      error: runtime.state === 'ready' ? undefined : formatAndroidRuntimeMessage(runtime),
    };
  }
  if (isBrowserLocalRuntime()) {
    try {
      await browserLocalModelClient.ensureReady();
      const runtime = browserLocalModelClient.runtime ?? (browserLocalModelClient.capabilities.webgpu ? 'webgpu' : 'wasm');
      const diagnostics = await browserLocalModelClient.getDiagnostics();
      return {
        available: true,
        models: [BROWSER_MODEL_ID],
        baseUrl: 'browser://local',
        configuredModel: BROWSER_MODEL_ID,
        runtime,
        runtimeMessage: `Cached locally · ${BROWSER_MODEL_SIZE}`,
        cacheState: diagnostics.cacheState,
        estimatedModelStorageBytes: diagnostics.estimatedModelStorageBytes,
        browserStorageUsageBytes: diagnostics.browserStorageUsageBytes,
        browserStorageQuotaBytes: diagnostics.browserStorageQuotaBytes,
      };
    } catch (error) {
      const browserError = error as BrowserModelError;
      return {
        available: false,
        models: [],
        baseUrl: 'browser://local',
        configuredModel: BROWSER_MODEL_ID,
        runtimeState: browserError.code,
        error: browserError.message || 'The browser local model is unavailable.',
        runtimeMessage: BROWSER_MODEL_SIZE,
      };
    }
  }
  const baseUrl = (options.baseUrl ?? getBaseUrl()).replace(/\/$/, '');
  const configuredModel = options.configuredModel ?? getConfiguredModelName();
  const fetchImpl = options.fetchImpl ?? fetch;
  try {
    const response = await fetchImpl(`${baseUrl}/api/tags`, { signal });
    if (!response.ok) {
      throw new LocalModelError(`Ollama returned HTTP ${response.status}.`, 'request');
    }
    const payload = await response.json() as {
      models?: Array<{ name?: string }>;
      unavailable?: boolean;
    };
    if (payload.unavailable) {
      return {
        available: false,
        models: [],
        baseUrl,
        configuredModel,
        error: 'Ollama is offline.',
      };
    }
    const models = Array.isArray(payload.models)
      ? payload.models.flatMap((model) => typeof model.name === 'string' ? [model.name] : [])
      : [];
    const modelAvailable = models.some((model) =>
      model === configuredModel ||
      model.startsWith(`${configuredModel}:`) ||
      configuredModel.startsWith(`${model}:`),
    );

    return modelAvailable
      ? { available: true, models, baseUrl, configuredModel }
      : {
        available: false,
        models,
        baseUrl,
        configuredModel,
        error: `Model "${configuredModel}" is not installed. Run: ollama pull ${configuredModel}`,
      };
  } catch (error) {
    return {
      available: false,
      models: [],
      baseUrl,
      configuredModel,
      error: error instanceof Error ? error.message : 'Ollama is unavailable.',
    };
  }
}

export type DesktopRuntimeState = {
  state: 'starting' | 'downloading' | 'ready' | 'offline' | 'error';
  message: string;
  model: string;
  gpu: 'cuda' | 'vulkan' | 'cpu';
  diskFreeBytes?: number;
  requiredBytes?: number;
};

export type LanaDesktopBridge = {
  isDesktop: true;
  getRuntimeState: () => Promise<DesktopRuntimeState>;
  retrySetup: () => Promise<DesktopRuntimeState>;
  openModelsFolder: () => Promise<void>;
};

declare global {
  interface Window {
    lanaDesktop?: LanaDesktopBridge;
  }
}

export function getDesktopBridge() {
  return typeof window !== 'undefined' ? window.lanaDesktop : undefined;
}

export function isDesktopRuntime() {
  return Boolean(getDesktopBridge()?.isDesktop);
}
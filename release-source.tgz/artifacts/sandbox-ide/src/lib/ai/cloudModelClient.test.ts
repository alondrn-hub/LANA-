import assert from 'node:assert/strict';
import test, { mock } from 'node:test';

let receivedSignal: AbortSignal | undefined;
mock.module('@workspace/api-client-react', {
  namedExports: {
    sendAiChat: async (_input: unknown, options?: { signal?: AbortSignal }) => {
      receivedSignal = options?.signal;
      throw new DOMException('The operation was aborted.', 'AbortError');
    },
  },
});

const { CloudModelClient, CloudModelError } = await import('./cloudModelClient.ts');

test('passes an aborted request signal through to the cloud API request', async () => {
  const controller = new AbortController();
  controller.abort();
  receivedSignal = undefined;

  const client = new CloudModelClient('openai');
  await assert.rejects(
    client.chat({
      messages: [{ role: 'user', content: 'This request must be cancelled.' }],
      signal: controller.signal,
    }),
    (error: unknown) => error instanceof CloudModelError,
  );
  assert.equal(receivedSignal, controller.signal);
});
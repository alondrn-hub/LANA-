import type { LocalModelRequest, LocalModelResponse } from './types.ts';

export type AndroidRuntimeState =
  | 'starting'
  | 'downloading'
  | 'ready'
  | 'memory-pressure'
  | 'offline'
  | 'unsupported'
  | 'error';

export type AndroidRuntimeStatus = {
  state: AndroidRuntimeState;
  message: string;
  model: string;
  modelSizeBytes?: number;
  modelDownloadedBytes?: number;
  availableMemoryBytes?: number;
  requiredMemoryBytes?: number;
  threads?: number;
  acceleration: 'nnapi' | 'cpu' | 'vulkan';
};

export type LanaAndroidBridge = {
  isAndroid: true;
  getRuntimeStatus: () => Promise<AndroidRuntimeStatus>;
  retrySetup: () => Promise<AndroidRuntimeStatus>;
  chat: (request: LocalModelRequest) => Promise<LocalModelResponse>;
};

declare global {
  interface Window {
    lanaAndroid?: LanaAndroidBridge;
  }
}

export function getAndroidBridge() {
  return typeof window !== 'undefined' ? window.lanaAndroid : undefined;
}

export function isAndroidRuntime() {
  return Boolean(getAndroidBridge()?.isAndroid);
}

export function formatAndroidRuntimeMessage(status: AndroidRuntimeStatus) {
  if (status.state === 'downloading' && status.modelSizeBytes) {
    const downloaded = status.modelDownloadedBytes ?? 0;
    const percent = Math.min(100, Math.round((downloaded / status.modelSizeBytes) * 100));
    return `Downloading local model · ${percent}%`;
  }
  return status.message;
}
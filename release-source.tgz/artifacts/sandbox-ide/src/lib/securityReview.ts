export type SecurityCheckStatus = 'ready' | 'attention' | 'checking';

export type SecurityConnection = {
  provider: string;
  state: 'connected' | 'error' | 'not_configured' | string;
};

export type SecurityCheck = {
  id: 'requests' | 'credentials' | 'preview' | 'publish';
  label: string;
  status: SecurityCheckStatus;
  summary: string;
  detail: string;
  evidence: string[];
};

export type SecurityIssue = {
  id: 'requests' | 'credentials' | 'preview' | 'save';
  title: string;
  detail: string;
  action: 'request-review' | 'integrations' | 'preview' | 'sign-in' | 'build';
};

export type SecurityReview = {
  checks: SecurityCheck[];
  issues: SecurityIssue[];
  securityReady: boolean;
  publishReady: boolean;
};

export type SecurityReleaseState = 'idle' | 'building' | 'ready';

type ReviewFile = {
  path: string;
  content: string;
};

type ReviewInput = {
  files: ReviewFile[];
  saveState: 'saved' | 'saving' | 'error' | 'sign-in';
  previewState: 'idle' | 'running' | 'ready' | 'error';
  releaseState: 'idle' | 'building' | 'ready';
  connections: SecurityConnection[];
  connectionsLoading?: boolean;
  connectionsUnavailable?: boolean;
  requestReviewApproved?: boolean;
};

const requestSignals = [
  { label: 'fetch', pattern: /\bfetch\s*\(/i },
  { label: 'axios', pattern: /\baxios(?:\.[a-z]+|\s*\()/i },
  { label: 'XMLHttpRequest', pattern: /\bXMLHttpRequest\b/i },
  { label: 'WebSocket', pattern: /\bWebSocket\s*\(/i },
  { label: 'EventSource', pattern: /\bEventSource\s*\(/i },
  { label: 'sendBeacon', pattern: /\bsendBeacon\s*\(/i },
] as const;

const credentialSignals = [
  /\bapi[_-]?key\b/i,
  /\bclient[_-]?secret\b/i,
  /\bprivate[_-]?key\b/i,
  /\b(?:access|refresh|id)[_-]?token\b/i,
  /\bauthorization\b/i,
  /\b(?:password|secret)\b/i,
] as const;

function inspectFiles(files: ReviewFile[]) {
  const sourceFiles = files.filter((file) => /\.(?:[cm]?[jt]sx?|html|vue|svelte)$/i.test(file.path));
  const requestEvidence = sourceFiles.flatMap((file) => {
    const signals = requestSignals
      .filter(({ pattern }) => pattern.test(file.content))
      .map(({ label }) => label);
    return signals.length ? [{ path: file.path, signals }] : [];
  });
  const credentialEvidence = sourceFiles
    .filter((file) => credentialSignals.some((pattern) => pattern.test(file.content)))
    .map((file) => file.path);

  return { requestEvidence, credentialEvidence };
}

function providerLabel(provider: string) {
  if (provider === 'xai') return 'xAI';
  return provider.charAt(0).toUpperCase() + provider.slice(1);
}

export function shouldInvalidateReleasePreflight(
  releaseState: SecurityReleaseState,
  securityReady: boolean,
) {
  return releaseState !== 'idle' && !securityReady;
}

export function buildSecurityReview(input: ReviewInput): SecurityReview {
  const { requestEvidence, credentialEvidence } = inspectFiles(input.files);
  const connectedProviders = input.connections
    .filter((connection) => connection.state === 'connected')
    .map((connection) => providerLabel(connection.provider));
  const erroredProviders = input.connections
    .filter((connection) => connection.state === 'error')
    .map((connection) => providerLabel(connection.provider));

  const requestCheck: SecurityCheck = requestEvidence.length
    ? {
        id: 'requests',
        label: 'Outbound requests',
        status: input.requestReviewApproved ? 'ready' : 'attention',
        summary: input.requestReviewApproved
          ? `${requestEvidence.length} request surface${requestEvidence.length === 1 ? '' : 's'} reviewed`
          : `${requestEvidence.length} request surface${requestEvidence.length === 1 ? '' : 's'} need code review`,
        detail: input.requestReviewApproved
          ? 'You approved the listed request code for the current workspace revision. Any source edit requires a fresh review.'
          : 'Inspect the listed source files, then approve this review for the current workspace revision. API Tester reviews separate, manual browser requests.',
        evidence: requestEvidence.map(({ path, signals }) => `${path} · ${signals.join(', ')}`),
      }
    : {
        id: 'requests',
        label: 'Outbound requests',
        status: 'ready',
        summary: 'No request calls detected',
        detail: 'No direct browser request calls were found in the current editable files. API Tester still requires a review before it sends.',
        evidence: [],
      };

  const credentialCheck: SecurityCheck = input.connectionsLoading
    ? {
        id: 'credentials',
        label: 'Credentials',
        status: 'checking',
        summary: 'Checking connected accounts',
        detail: 'Connection status is loading. Secret values are never displayed in this review.',
        evidence: [],
      }
    : input.connectionsUnavailable
      ? {
          id: 'credentials',
          label: 'Credentials',
          status: 'attention',
          summary: 'Could not load connection status',
          detail: 'Retry the connection check before publishing. Secret values are never displayed in this review.',
          evidence: [],
        }
    : credentialEvidence.length || erroredProviders.length
      ? {
          id: 'credentials',
          label: 'Credentials',
          status: 'attention',
          summary: credentialEvidence.length
            ? `Credential-like references in ${credentialEvidence.length} file${credentialEvidence.length === 1 ? '' : 's'}`
            : `${erroredProviders.join(', ')} connection${erroredProviders.length === 1 ? '' : 's'} need attention`,
          detail: credentialEvidence.length
            ? 'Move credential values to runtime secrets and keep them out of browser code. Only file names are shown here.'
            : 'Re-test or remove the affected provider connection before sending cloud requests.',
          evidence: [
            ...credentialEvidence,
            ...erroredProviders.map((provider) => `${provider} · connection error`),
          ],
        }
      : {
          id: 'credentials',
          label: 'Credentials',
          status: 'ready',
          summary: connectedProviders.length
            ? `${connectedProviders.length} provider account${connectedProviders.length === 1 ? '' : 's'} protected`
            : 'No cloud credentials connected',
          detail: connectedProviders.length
            ? 'Connected provider keys stay encrypted. This review shows provider status only, never a key or secret value.'
            : 'Local-first mode does not need an API key. Add a provider only when you intentionally want cloud inference.',
          evidence: connectedProviders,
        };

  const previewCheck: SecurityCheck = input.previewState === 'ready'
    ? {
        id: 'preview',
        label: 'Local preview',
        status: 'ready',
        summary: 'Preview is live',
        detail: 'The current saved workspace has a live local preview to check before release.',
        evidence: [],
      }
    : {
        id: 'preview',
        label: 'Local preview',
        status: 'attention',
        summary: input.previewState === 'running' ? 'Preview is starting' : 'Preview has not been checked',
        detail: input.previewState === 'running'
          ? 'Wait for the local server to finish starting, then review the live surface.'
          : 'Run the workspace from Preview and check the current build before publishing.',
        evidence: [],
      };

  const saveIssue: SecurityIssue | null = input.saveState === 'saved'
    ? null
    : {
        id: input.saveState === 'sign-in' ? 'save' : 'save',
        title: input.saveState === 'sign-in' ? 'Sign in to save the workspace' : 'Save the latest workspace changes',
        detail: input.saveState === 'error'
          ? 'The last save failed. Retry the save before publishing.'
          : input.saveState === 'saving'
            ? 'Wait for the current save to finish before publishing.'
            : 'Sign in so the exact files you reviewed can be recovered and published.',
        action: input.saveState === 'sign-in' ? 'sign-in' : 'build',
      };

  const issues: SecurityIssue[] = [
    ...(requestCheck.status === 'attention'
      ? [{
          id: 'requests' as const,
          title: 'Review browser request surfaces',
          detail: 'Inspect the flagged source files and move sensitive work behind a server boundary before publishing.',
          action: 'request-review' as const,
        }]
      : []),
    ...(credentialCheck.status !== 'ready'
      ? [{
          id: 'credentials' as const,
          title: credentialCheck.status === 'checking' ? 'Wait for credential status to finish loading' : 'Resolve credential handling',
          detail: credentialCheck.status === 'checking'
            ? 'Provider connection status is still loading, so release preparation stays paused.'
            : input.connectionsUnavailable
              ? 'Connection status could not be confirmed. Retry the check before preparing a release.'
            : credentialEvidence.length
              ? 'Move credential values out of browser code, then review the affected files again.'
              : 'Re-test or remove the provider connection before using cloud requests.',
          action: 'integrations' as const,
        }]
      : []),
    ...(previewCheck.status === 'attention'
      ? [{
          id: 'preview' as const,
          title: 'Check the local preview',
          detail: previewCheck.detail,
          action: 'preview' as const,
        }]
      : []),
    ...(saveIssue ? [saveIssue] : []),
  ];

  const securityReady = issues.length === 0;
  const publishReady = securityReady && input.releaseState === 'ready';
  const publishCheck: SecurityCheck = {
    id: 'publish',
    label: 'Publish readiness',
    status: publishReady ? 'ready' : 'attention',
    summary: publishReady
      ? 'Ready to share'
      : securityReady
        ? input.releaseState === 'building' ? 'Release checks are running' : 'Ready to prepare'
        : `${issues.length} review${issues.length === 1 ? '' : 's'} blocking release`,
    detail: publishReady
      ? 'Security checks, save state, preview, and release checklist are current.'
      : securityReady
        ? 'Prepare the release checklist after the security checks pass.'
        : 'Resolve the highlighted checks before preparing a release.',
    evidence: [],
  };

  return {
    checks: [requestCheck, credentialCheck, previewCheck, publishCheck],
    issues,
    securityReady,
    publishReady,
  };
}
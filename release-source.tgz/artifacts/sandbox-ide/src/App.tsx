import { type ReactNode, useEffect, useMemo, useRef, useState } from 'react';
import { ClerkProvider, SignIn, SignUp, useAuth } from '@clerk/react';
import { publishableKeyFromHost } from '@clerk/react/internal';
import { shadcn } from '@clerk/themes';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import {
  getGetProjectQueryKey,
  getGetProjectResourcesQueryKey,
  getListAiConnectionsQueryKey,
  getProjectResources,
  useListAiConnections,
  useGetProject,
  useGetProjectResources,
  useSaveProject,
  useSaveProjectResources,
  type LibraryItem,
  type AiProvider,
  type ProjectResources,
  type ProjectTemplate,
} from '@workspace/api-client-react';
import { detectLocalModel } from '@/lib/ai/detectLocalModel';
import { getConfiguredModelName, isBrowserLocalRuntime, localModelClient, localModelErrorMessage } from '@/lib/ai/localModelClient';
import {
  browserLocalModelClient,
  BROWSER_MODEL_ID,
  BROWSER_MODEL_SIZE,
  BrowserModelError,
  type BrowserModelCacheState,
} from '@/lib/ai/browserModelClient';
import { getDesktopBridge, isDesktopRuntime } from '@/lib/ai/desktopRuntime';
import { formatAndroidRuntimeMessage, getAndroidBridge, isAndroidRuntime } from '@/lib/ai/androidRuntime';
import { CloudModelClient, cloudModelErrorMessage } from '@/lib/ai/cloudModelClient';
import { runAgentPipeline } from '@/lib/ai/orchestrator';
import { buildProjectContext } from '@/lib/ai/projectContext';
import { buildPromptContext } from '@/lib/ai/promptContext';
import type { WorkspaceContext } from '@/lib/ai/types';
import {
  applyInlineSuggestion,
  canRequestInlineSuggestion,
  getInlineSuggestionKeyboardAction,
  type InlineSuggestion,
} from '@/lib/ai/inlineSuggestion';
import {
  applyEditProposal as applyEditProposalChanges,
  createHunks,
  type ProposedFileChange,
} from '@/lib/ai/editProposal';
import {
  Check,
  Code2,
  ChevronDown,
  ChevronRight,
  CircleAlert,
  CircleDot,
  FileCode2,
  FileJson,
  FileText,
  Folder,
  GitBranch,
  HelpCircle,
  HardDrive,
  LockKeyhole,
  Menu,
  MonitorPlay,
  MoreHorizontal,
  Play,
  Plus,
  RotateCcw,
  Rocket,
  Send,
  Settings2,
  Sparkles,
  Terminal,
  X,
  Search,
  PackageSearch,
  ShieldCheck,
  AlertTriangle,
  ExternalLink,
} from 'lucide-react';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import { LanaHome, type HomeArea } from '@/components/LanaHome';
import { ToolWorkspace } from '@/components/ToolWorkspace';
import { VibeCodeWorkspace } from '@/components/VibeCodeWorkspace';
import { ResourceWorkspace } from '@/components/ResourceWorkspace';
import { AiConnectorPanel } from '@/components/AiConnectorPanel';
import { WorkspaceSidebar, type WorkspaceArea, type WorkspacePage } from '@/components/WorkspaceSidebar';
import {
  buildSecurityReview,
  shouldInvalidateReleasePreflight,
  type SecurityReview,
} from '@/lib/securityReview';
import NotFound from '@/pages/not-found';
import { Route, Switch, useLocation, Router as WouterRouter } from 'wouter';

const queryClient = new QueryClient();
const basePath = import.meta.env.BASE_URL.replace(/\/$/, '');

function formatStorageSize(bytes?: number) {
  if (bytes === undefined) return 'Unavailable';
  if (bytes === 0) return '0 MB';
  const units = ['B', 'KB', 'MB', 'GB'];
  const unitIndex = Math.min(Math.floor(Math.log(bytes) / Math.log(1000)), units.length - 1);
  return `${(bytes / (1000 ** unitIndex)).toFixed(unitIndex >= 3 ? 1 : 0)} ${units[unitIndex]}`;
}

const clerkPubKey = publishableKeyFromHost(
  window.location.hostname,
  import.meta.env.VITE_CLERK_PUBLISHABLE_KEY,
);
const clerkProxyUrl = import.meta.env.VITE_CLERK_PROXY_URL;
const clerkAppearance = {
  theme: shadcn,
  cssLayerName: 'clerk',
  options: {
    logoPlacement: 'inside' as const,
    logoLinkUrl: basePath || '/',
    logoImageUrl: `${window.location.origin}${basePath}/logo.svg`,
  },
  variables: {
    colorPrimary: '#e9a52b',
    colorForeground: '#24283c',
    colorMutedForeground: '#747080',
    colorDanger: '#b34c42',
    colorBackground: '#faf8f2',
    colorInput: '#f4f1e9',
    colorInputForeground: '#24283c',
    colorNeutral: '#d8d2c5',
    fontFamily: 'Manrope, sans-serif',
    borderRadius: '0.4rem',
  },
};

type FilePath = 'src/App.tsx' | 'src/main.tsx' | 'src/index.css' | 'package.json' | 'README.md' | 'LANA.md';
type PreviewState = 'idle' | 'running' | 'ready' | 'error';
type ChatMessage = { id: number; role: 'you' | 'model'; text: string; agentLabel?: string };
type PreviewPage = 'home' | 'dashboard' | 'settings';
const emptyProjectResources: ProjectResources = { revision: 0, templates: [], routines: [], library: [] };
const initialChatMessages: ChatMessage[] = [
  { id: 1, role: 'model', text: 'Local workspace assistant. Ask me about the files in this workspace.' },
];
type AssistantMode = 'chat' | 'edit';

const fileRows: Array<{ path: FilePath; kind: 'code' | 'json' | 'text' }> = [
  { path: 'src/App.tsx', kind: 'code' },
  { path: 'src/main.tsx', kind: 'code' },
  { path: 'src/index.css', kind: 'code' },
  { path: 'package.json', kind: 'json' },
  { path: 'README.md', kind: 'text' },
  { path: 'LANA.md', kind: 'text' },
];

const fileContents: Record<FilePath, Array<{ text: string; tone?: string }>> = {
  'src/App.tsx': [
    { text: "import { useState } from 'react';", tone: 'tok-key' },
    { text: "import { Preview } from './components/Preview';", tone: 'tok-key' },
    { text: '', tone: 'tok-muted' },
    { text: 'export default function App() {' },
    { text: '  const [ready, setReady] = useState(false);' },
    { text: '', tone: 'tok-muted' },
    { text: '  return (' },
    { text: '    <main className="app-shell">' },
    { text: '      <header className="topbar">', tone: 'tok-type' },
    { text: '        <span className="wordmark">LANA DEV</span>' },
    { text: '        <button onClick={() => setReady(true)}>' },
    { text: '          Run workspace' },
    { text: '        </button>' },
    { text: '      </header>' },
    { text: '      <Preview active={ready} />' },
    { text: '    </main>' },
    { text: '  );' },
    { text: '}', tone: 'tok-punc' },
  ],
  'src/main.tsx': [
    { text: "import { StrictMode } from 'react';", tone: 'tok-key' },
    { text: "import { createRoot } from 'react-dom/client';", tone: 'tok-key' },
    { text: "import App from './App';", tone: 'tok-key' },
    { text: "import './index.css';", tone: 'tok-key' },
    { text: '', tone: 'tok-muted' },
    { text: "const root = document.getElementById('root');", tone: 'tok-fn' },
    { text: '', tone: 'tok-muted' },
    { text: 'createRoot(root!).render(' },
    { text: '  <StrictMode>' },
    { text: '    <App />', tone: 'tok-type' },
    { text: '  </StrictMode>,' },
    { text: ');' },
  ],
  'src/index.css': [
    { text: ':root {' },
    { text: '  --ink: #202338;', tone: 'tok-key' },
    { text: '  --paper: #f3f0e9;', tone: 'tok-key' },
    { text: '  --signal: #e9a52b;', tone: 'tok-key' },
    { text: '  --quiet: #8d8b9b;', tone: 'tok-key' },
    { text: '}', tone: 'tok-punc' },
    { text: '', tone: 'tok-muted' },
    { text: 'body {' },
    { text: "  margin: 0;", tone: 'tok-str' },
    { text: "  background: var(--paper);", tone: 'tok-str' },
    { text: "  color: var(--ink);", tone: 'tok-str' },
    { text: "  font-family: 'Manrope', sans-serif;", tone: 'tok-str' },
    { text: '}' },
    { text: '', tone: 'tok-muted' },
    { text: '.app-shell {' },
    { text: '  min-height: 100dvh;', tone: 'tok-str' },
    { text: '  display: grid;', tone: 'tok-str' },
    { text: '  grid-template-rows: 54px 1fr;', tone: 'tok-str' },
    { text: '}' },
  ],
  'package.json': [
    { text: '{' },
    { text: '  "name": "lana-dev",' },
    { text: '  "private": true,' },
    { text: '  "version": "0.4.2",' },
    { text: '  "type": "module",' },
    { text: '  "scripts": {' },
    { text: '    "dev": "vite",' },
    { text: '    "build": "vite build",' },
    { text: '    "preview": "vite preview"' },
    { text: '  },' },
    { text: '  "dependencies": {' },
    { text: '    "react": "^19.0.0",' },
    { text: '    "lucide-react": "^0.468.0"' },
    { text: '  }' },
    { text: '}', tone: 'tok-punc' },
  ],
  'README.md': [
    { text: '# LANA DEV' },
    { text: '', tone: 'tok-muted' },
    { text: 'A browser workspace for turning ideas into software.' },
    { text: 'you notice while building.' },
    { text: '', tone: 'tok-muted' },
    { text: '## Local development' },
    { text: '' },
    { text: 'npm install' },
    { text: 'npm run dev' },
    { text: '', tone: 'tok-muted' },
    { text: 'Open the local preview and start shaping.' },
  ],
  'LANA.md': [
    { text: '# LANA DEV project instructions' },
    { text: '' },
    { text: '- Keep this starter project lightweight and readable.' },
    { text: '- Prefer accessible UI and clear empty or error states.' },
    { text: '- Do not add cloud AI fallbacks; local AI remains opt-in.' },
    { text: '- Explain proposed code changes before they are applied.' },
  ],
};

const defaultFileContents = Object.fromEntries(
  Object.entries(fileContents).map(([path, lines]) => [
    path,
    lines.map((line) => line.text).join('\n'),
  ]),
) as Record<FilePath, string>;

function IconForFile({ kind }: { kind: 'code' | 'json' | 'text' }) {
  if (kind === 'json') return <FileJson size={14} strokeWidth={1.8} />;
  if (kind === 'text') return <FileText size={14} strokeWidth={1.8} />;
  return <FileCode2 size={14} strokeWidth={1.8} />;
}

function Home() {
  const [appMode, setAppMode] = useState<'home' | 'vibe' | 'ide' | 'tool' | 'section'>('home');
  const [entryMode, setEntryMode] = useState<'vibe' | 'ide'>('ide');
  const [selectedTool, setSelectedTool] = useState('');
  const [homeArea, setHomeArea] = useState<HomeArea>('home');
  const { isLoaded, isSignedIn, userId } = useAuth();
  const activeUserIdRef = useRef<string | null>(null);
  activeUserIdRef.current = userId ?? null;
  const projectQueryKey = useMemo(
    () => [...getGetProjectQueryKey(), userId ?? 'signed-out'],
    [userId],
  );
  const resourcesQueryKey = useMemo(
    () => [...getGetProjectResourcesQueryKey(), userId ?? 'signed-out'],
    [userId],
  );
  const aiConnectionsQueryKey = useMemo(
    () => [...getListAiConnectionsQueryKey(), userId ?? 'signed-out'],
    [userId],
  );
  const { data: savedProject, isLoading: isProjectLoading } = useGetProject({
    query: {
      queryKey: projectQueryKey,
      enabled: Boolean(isLoaded && isSignedIn),
      retry: false,
    },
  });
  const { data: savedResources, isLoading: isResourcesLoading } = useGetProjectResources({
    query: {
      queryKey: resourcesQueryKey,
      enabled: Boolean(isLoaded && isSignedIn),
      retry: false,
    },
  });
  const {
    data: aiConnections = [],
    isLoading: isAiConnectionsLoading,
    isError: isAiConnectionsUnavailable,
  } = useListAiConnections({
    query: {
      queryKey: aiConnectionsQueryKey,
      enabled: Boolean(isLoaded && isSignedIn),
      retry: false,
    },
  });
  const saveProject = useSaveProject();
  const saveResources = useSaveProjectResources();
  const [activeFile, setActiveFile] = useState<FilePath>('src/App.tsx');
  const [tabs, setTabs] = useState<FilePath[]>(['src/App.tsx', 'package.json', 'README.md']);
  const [selectedContextPaths, setSelectedContextPaths] = useState<string[]>([]);
  const [workspaceSearch, setWorkspaceSearch] = useState('');
  const [editableFiles, setEditableFiles] = useState<Record<FilePath, string>>(defaultFileContents);
  const [saveState, setSaveState] = useState<'saved' | 'saving' | 'error' | 'sign-in'>('sign-in');
  const hydratedProjectUserId = useRef<string | null>(null);
  const resourcesHydratedFor = useRef<string | null>(null);
  const skipNextSave = useRef(false);
  const workspaceRevision = useRef(0);
  const previewTimer = useRef<number | undefined>(undefined);
  const releaseTimer = useRef<number | undefined>(undefined);
  const [terminalLines, setTerminalLines] = useState<Array<{ text: string; tone?: string }>>([
    { text: 'lana dev · terminal attached', tone: 'dim' },
    { text: 'Ready when you are. Run the workspace to start a preview.', tone: 'dim' },
  ]);
  const [previewState, setPreviewState] = useState<PreviewState>('idle');
  const [workspacePage, setWorkspacePage] = useState<WorkspacePage>('build');
  const [activeSidebarArea, setActiveSidebarArea] = useState<WorkspaceArea | null>(null);
  const [previewPage, setPreviewPage] = useState<PreviewPage>('home');
  const [releaseState, setReleaseState] = useState<'idle' | 'building' | 'ready'>('idle');
  const [approvedRequestReviewRevision, setApprovedRequestReviewRevision] = useState<number | null>(null);
  const [terminalTab, setTerminalTab] = useState<'terminal' | 'output'>('terminal');
  const [mobileFilesOpen, setMobileFilesOpen] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>(initialChatMessages);
  const chatUserId = useRef<string | null>(null);
  const [chatDraft, setChatDraft] = useState('');
  const [isModelThinking, setIsModelThinking] = useState(false);
  const [assistantMode, setAssistantMode] = useState<AssistantMode>('chat');
  const [workerRun, setWorkerRun] = useState<{
    state: 'idle' | 'running' | 'complete' | 'error';
    prompt?: string;
    results?: Array<{ label: string; content: string }>;
  }>({ state: 'idle' });
  const [editProposal, setEditProposal] = useState<{
    summary: string;
    changes: ProposedFileChange<FilePath>[];
  } | null>(null);
  const [isSuggesting, setIsSuggesting] = useState(false);
  const [typingRevision, setTypingRevision] = useState(0);
  const [inlineSuggestion, setInlineSuggestion] = useState<InlineSuggestion | null>(null);
  const [localModelStatus, setLocalModelStatus] = useState<{
    state: 'checking' | 'available' | 'unavailable';
    error?: string;
    runtimeState?: string;
    runtimeMessage?: string;
    runtime?: 'webgpu' | 'wasm';
    progress?: number;
    cacheState?: BrowserModelCacheState;
    estimatedModelStorageBytes?: number;
    browserStorageUsageBytes?: number;
    browserStorageQuotaBytes?: number;
  }>({ state: 'checking' });
  const [isClearingBrowserCache, setIsClearingBrowserCache] = useState(false);
  const [selectedAiProvider, setSelectedAiProvider] = useState<AiProvider | 'local'>('local');
  const [isUnlocked, setIsUnlocked] = useState(false);
  const [isExplorerLoading, setIsExplorerLoading] = useState(false);
  const [explorerError, setExplorerError] = useState(false);
  const [notice, setNotice] = useState('');
  const [resources, setResources] = useState<ProjectResources>(emptyProjectResources);
  const [resourceSaveState, setResourceSaveState] = useState<'saved' | 'saving' | 'error' | 'sign-in'>('sign-in');
  const editorRef = useRef<HTMLTextAreaElement>(null);
  const suggestionController = useRef<AbortController | null>(null);
  const localModelOperation = useRef(0);
  const activeFileRef = useRef(activeFile);
  activeFileRef.current = activeFile;

  const resourcesForCurrentUser = isSignedIn && userId && resourcesHydratedFor.current === userId
    ? resources
    : emptyProjectResources;
  const workspaceFiles = isSignedIn && userId && hydratedProjectUserId.current === userId
    ? editableFiles
    : defaultFileContents;
  const hasCurrentUserState = Boolean(isSignedIn && userId && chatUserId.current === userId);
  const visibleMessages = hasCurrentUserState ? messages : [];
  const visibleChatDraft = hasCurrentUserState ? chatDraft : '';
  const visibleInlineSuggestion = hasCurrentUserState ? inlineSuggestion : null;
  const visibleWorkerRun = hasCurrentUserState ? workerRun : { state: 'idle' as const };
  const visibleEditProposal = hasCurrentUserState ? editProposal : null;
  const visibleIsModelThinking = hasCurrentUserState ? isModelThinking : false;
  const visibleNotice = !isSignedIn || hasCurrentUserState ? notice : '';
  const selectedCloudConnection = selectedAiProvider === 'local'
    ? null
    : aiConnections.find((connection) => connection.provider === selectedAiProvider && connection.state === 'connected') ?? null;
  const activeModelClient = selectedAiProvider === 'local'
    ? localModelClient
    : selectedCloudConnection
      ? new CloudModelClient(selectedAiProvider)
      : null;
  const isActiveModelAvailable = selectedAiProvider === 'local'
    ? localModelStatus.state === 'available'
    : Boolean(selectedCloudConnection);
  const isInlineSuggestionAvailable = localModelStatus.state === 'available';
  const currentContent = workspaceFiles[activeFile];
  const currentLines = useMemo(
    () => currentContent.split('\n').map((text) => ({ text })),
    [currentContent],
  );
  const contextPreview = useMemo(
    () => buildProjectContext({
      message: visibleChatDraft,
      activeFile,
      openTabs: tabs,
      selectedPaths: selectedContextPaths,
      files: fileRows.map((file) => ({
        path: file.path,
        content: workspaceFiles[file.path],
        kind: file.kind,
      })),
    }),
    [activeFile, selectedContextPaths, tabs, visibleChatDraft, workspaceFiles],
  );
  const securityReview = useMemo(
    () => buildSecurityReview({
      files: fileRows.map((file) => ({
        path: file.path,
        content: workspaceFiles[file.path],
      })),
      saveState,
      previewState,
      releaseState,
      connections: aiConnections,
      connectionsLoading: isAiConnectionsLoading,
      connectionsUnavailable: isAiConnectionsUnavailable,
      requestReviewApproved: approvedRequestReviewRevision === workspaceRevision.current,
    }),
    [aiConnections, approvedRequestReviewRevision, isAiConnectionsLoading, isAiConnectionsUnavailable, previewState, releaseState, saveState, workspaceFiles],
  );
  const securityNeedsAttention = securityReview.issues.length > 0;
  const securityReadyRef = useRef(securityReview.securityReady);
  securityReadyRef.current = securityReview.securityReady;

  useEffect(() => {
    if (!shouldInvalidateReleasePreflight(releaseState, securityReview.securityReady)) return;
    if (releaseTimer.current) window.clearTimeout(releaseTimer.current);
    releaseTimer.current = undefined;
    setReleaseState('idle');
  }, [releaseState, securityReview.securityReady]);

  const runLabel = previewState === 'running' ? 'Starting' : previewState === 'ready' ? 'Running' : 'Run';

  const persistProject = async () => {
    const initiatingUserId = userId;
    if (!isSignedIn || !initiatingUserId) {
      setSaveState('sign-in');
      return;
    }
    if (hydratedProjectUserId.current !== initiatingUserId) return;
    setSaveState('saving');
    try {
      await saveProject.mutateAsync({
        data: {
          name: 'lana-dev',
          files: fileRows.map((file) => ({
            path: file.path,
            content: workspaceFiles[file.path],
            kind: file.kind,
          })),
        },
      });
      if (activeUserIdRef.current !== initiatingUserId) return;
      setSaveState('saved');
    } catch {
      if (activeUserIdRef.current !== initiatingUserId) return;
      setSaveState('error');
    }
  };

  const persistResources = async (
    changes: Partial<Pick<ProjectResources, 'templates' | 'routines' | 'library'>>,
  ): Promise<boolean> => {
    const initiatingUserId = userId;
    if (!isSignedIn || !initiatingUserId) {
      setResourceSaveState('sign-in');
      flashNotice('Sign in to save reusable project resources.');
      return false;
    }
    if (resourcesHydratedFor.current !== initiatingUserId) {
      flashNotice('Your saved resources are still loading. Try again in a moment.');
      return false;
    }
    const category = (['templates', 'routines', 'library'] as const).find((key) => key in changes);
    if (!category) return false;
    const next = { ...resourcesForCurrentUser, ...changes };
    setResourceSaveState('saving');
    try {
      const saved = await saveResources.mutateAsync({
        data: {
          category,
          expectedRevision: resourcesForCurrentUser.revision,
          resources: next,
        },
      });
      if (activeUserIdRef.current !== initiatingUserId) return false;
      setResources(saved);
      queryClient.setQueryData(resourcesQueryKey, saved);
      setResourceSaveState('saved');
      return true;
    } catch (error) {
      if (activeUserIdRef.current !== initiatingUserId) return false;
      setResourceSaveState('error');
      if (typeof error === 'object' && error !== null && 'status' in error && error.status === 409) {
        try {
          const currentResources = await getProjectResources();
          if (activeUserIdRef.current !== initiatingUserId) return false;
          setResources(currentResources);
          queryClient.setQueryData(resourcesQueryKey, currentResources);
        } catch {
          // The next visit will still refetch the server state.
        }
        flashNotice('These resources changed elsewhere. Your latest server copy is now loaded.');
        return false;
      }
      flashNotice('Could not save these resources. Try again.');
      return false;
    }
  };

  useEffect(() => {
    if (!isLoaded) return;
    if (!isSignedIn || !userId) {
      hydratedProjectUserId.current = null;
      queryClient.removeQueries({ queryKey: getGetProjectQueryKey() });
      queryClient.removeQueries({ queryKey: getGetProjectResourcesQueryKey() });
      setEditableFiles(defaultFileContents);
      setApprovedRequestReviewRevision(null);
      setSaveState('sign-in');
      setSelectedAiProvider('local');
      return;
    }
    if (isProjectLoading) return;
    if (hydratedProjectUserId.current !== userId) {
      hydratedProjectUserId.current = userId;
      const loadedFiles = { ...defaultFileContents };
      if (savedProject?.files?.length) {
        for (const file of savedProject.files) {
          if (file.path in loadedFiles) loadedFiles[file.path as FilePath] = file.content;
        }
      }
      skipNextSave.current = true;
      setEditableFiles(loadedFiles);
      setApprovedRequestReviewRevision(null);
      setSaveState('saved');
      return;
    }
    if (skipNextSave.current) {
      skipNextSave.current = false;
      return;
    }
    setSaveState('saving');
    const timer = window.setTimeout(() => {
      void persistProject();
    }, 850);
    return () => window.clearTimeout(timer);
  }, [editableFiles, isLoaded, isProjectLoading, isSignedIn, savedProject, userId]);

  useEffect(() => {
    if (!isLoaded) return;
    if (!isSignedIn || !userId) {
      resourcesHydratedFor.current = null;
      queryClient.removeQueries({ queryKey: getGetProjectResourcesQueryKey() });
      setResources(emptyProjectResources);
      setResourceSaveState('sign-in');
      return;
    }
    if (isResourcesLoading || resourcesHydratedFor.current === userId) return;
    resourcesHydratedFor.current = userId;
    setResources(savedResources ?? emptyProjectResources);
    setResourceSaveState('saved');
  }, [isLoaded, isResourcesLoading, isSignedIn, savedResources, userId]);

  useEffect(() => {
    if (!isLoaded) return;
    suggestionController.current?.abort();
    if (previewTimer.current) window.clearTimeout(previewTimer.current);
    if (releaseTimer.current) window.clearTimeout(releaseTimer.current);
    previewTimer.current = undefined;
    releaseTimer.current = undefined;
    setInlineSuggestion(null);
    setIsSuggesting(false);
    setWorkerRun({ state: 'idle' });
    setEditProposal(null);
    setPreviewState('idle');
    setReleaseState('idle');
    setTerminalLines([
      { text: 'lana dev · terminal attached', tone: 'dim' },
      { text: 'Ready when you are. Run the workspace to start a preview.', tone: 'dim' },
    ]);
    if (!isSignedIn || !userId) {
      chatUserId.current = null;
      setMessages(initialChatMessages);
      setChatDraft('');
      setIsModelThinking(false);
      setNotice('');
      return;
    }
    if (chatUserId.current !== userId) {
      chatUserId.current = userId;
      setMessages(initialChatMessages);
      setChatDraft('');
      setIsModelThinking(false);
      setNotice('');
    }
  }, [isLoaded, isSignedIn, userId]);

  useEffect(() => {
    const controller = new AbortController();
    const detectionOperation = ++localModelOperation.current;
    const unsubscribe = browserLocalModelClient.onProgress((progress) => {
      if (!controller.signal.aborted) {
        setLocalModelStatus((current) => ({
          ...current,
          state: progress.state === 'ready' ? 'available' : progress.state === 'unsupported' || progress.state === 'memory-pressure' || progress.state === 'error' ? 'unavailable' : 'checking',
          error: progress.state === 'ready' ? undefined : progress.message,
          runtimeState: progress.state,
          runtimeMessage: progress.message,
          runtime: progress.runtime,
          progress: progress.progress,
          cacheState: progress.state === 'clearing' ? 'checking' : current.cacheState,
        }));
      }
    });
    void detectLocalModel(controller.signal).then((status) => {
      if (!controller.signal.aborted && localModelOperation.current === detectionOperation) {
        setLocalModelStatus({
          state: status.available ? 'available' : 'unavailable',
          error: status.error,
          runtimeState: status.runtimeState,
          runtimeMessage: status.runtimeMessage,
          runtime: status.runtime,
          progress: status.progress,
          cacheState: status.cacheState,
          estimatedModelStorageBytes: status.estimatedModelStorageBytes,
          browserStorageUsageBytes: status.browserStorageUsageBytes,
          browserStorageQuotaBytes: status.browserStorageQuotaBytes,
        });
      }
    });
    return () => {
      controller.abort();
      unsubscribe();
    };
  }, []);

  const desktopSetup = async () => {
    const bridge = getDesktopBridge();
    const android = getAndroidBridge();
    if (!bridge && !android && !isBrowserLocalRuntime()) return;
    localModelOperation.current += 1;
    setLocalModelStatus({ state: 'checking', error: 'Preparing the bundled local runtime…' });
    if (!bridge && !android) {
      try {
        await browserLocalModelClient.ensureReady();
        const diagnostics = await browserLocalModelClient.getDiagnostics();
        setLocalModelStatus({
          state: 'available',
          runtime: browserLocalModelClient.runtime,
          runtimeMessage: 'Cached locally · prompts stay on this device.',
          progress: 1,
          cacheState: diagnostics.cacheState,
          estimatedModelStorageBytes: diagnostics.estimatedModelStorageBytes,
          browserStorageUsageBytes: diagnostics.browserStorageUsageBytes,
          browserStorageQuotaBytes: diagnostics.browserStorageQuotaBytes,
        });
      } catch (error) {
        setLocalModelStatus({
          state: 'unavailable',
          runtimeState: error instanceof BrowserModelError ? error.code : 'error',
          error: error instanceof Error ? error.message : 'The browser model could not be loaded.',
        });
      }
      return;
    }
    const runtime = bridge ? await bridge.retrySetup() : await android!.retrySetup();
    setLocalModelStatus({
      state: runtime.state === 'ready' ? 'available' : 'unavailable',
      error: runtime.state === 'ready'
        ? undefined
        : 'acceleration' in runtime
          ? formatAndroidRuntimeMessage(runtime)
          : runtime.message,
      runtimeState: runtime.state,
      runtimeMessage: runtime.message,
    });
  };

  const clearBrowserModelCache = async () => {
    if (!isBrowserLocalRuntime() || isClearingBrowserCache || localModelStatus.state === 'checking') return;
    const confirmed = window.confirm(
      'Clear the browser-local Llama model cache? LANA DEV will remove its model files from this browser, then download and rebuild a fresh local copy. Prompts will remain on this device.',
    );
    if (!confirmed) return;

    localModelOperation.current += 1;
    setIsClearingBrowserCache(true);
    setLocalModelStatus((current) => ({
      ...current,
      state: 'checking',
      runtimeState: 'clearing',
      runtimeMessage: 'Removing the browser model cache…',
      error: undefined,
      progress: 0,
      cacheState: 'checking',
    }));
    try {
      await browserLocalModelClient.clearCache();
      setLocalModelStatus((current) => ({
        ...current,
        state: 'checking',
        runtimeState: 'downloading',
        runtimeMessage: 'Cache cleared. Downloading a fresh local model…',
        cacheState: 'not-cached',
        estimatedModelStorageBytes: 0,
      }));
      await browserLocalModelClient.ensureReady();
      const diagnostics = await browserLocalModelClient.getDiagnostics();
      setLocalModelStatus({
        state: 'available',
        runtimeState: 'ready',
        runtimeMessage: 'Fresh browser model ready · prompts stay on this device.',
        runtime: browserLocalModelClient.runtime,
        progress: 1,
        cacheState: diagnostics.cacheState,
        estimatedModelStorageBytes: diagnostics.estimatedModelStorageBytes,
        browserStorageUsageBytes: diagnostics.browserStorageUsageBytes,
        browserStorageQuotaBytes: diagnostics.browserStorageQuotaBytes,
      });
      flashNotice('Browser model cache rebuilt locally.');
    } catch (error) {
      setLocalModelStatus((current) => ({
        ...current,
        state: 'unavailable',
        runtimeState: error instanceof BrowserModelError ? error.code : 'error',
        runtimeMessage: 'The browser model cache needs attention.',
        error: error instanceof Error ? error.message : 'The browser model could not be rebuilt.',
        cacheState: current.cacheState === 'checking' ? 'unknown' : current.cacheState,
      }));
    } finally {
      setIsClearingBrowserCache(false);
    }
  };

  useEffect(() => {
    if (
      selectedAiProvider !== 'local' &&
      !isAiConnectionsLoading &&
      !aiConnections.some((connection) => connection.provider === selectedAiProvider && connection.state === 'connected')
    ) {
      setSelectedAiProvider('local');
    }
  }, [aiConnections, isAiConnectionsLoading, selectedAiProvider]);

  const openFile = (path: FilePath) => {
    setActiveFile(path);
    setTabs((current) => (current.includes(path) ? current : [...current, path]));
    setMobileFilesOpen(false);
  };

  const toggleContextPath = (path: string) => {
    setSelectedContextPaths((current) => current.includes(path)
      ? current.filter((item) => item !== path)
      : [...current, path]);
  };

  const updateCurrentFile = (content: string) => {
    if (hydratedProjectUserId.current !== userId) {
      flashNotice('Your workspace is still loading. Try again in a moment.');
      return;
    }
    setEditableFiles((current) => ({ ...current, [activeFile]: content }));
    suggestionController.current?.abort();
    setInlineSuggestion(null);
    workspaceRevision.current += 1;
    if (previewTimer.current) window.clearTimeout(previewTimer.current);
    if (releaseTimer.current) window.clearTimeout(releaseTimer.current);
    previewTimer.current = undefined;
    releaseTimer.current = undefined;
    setPreviewState('idle');
    setReleaseState('idle');
  };

  const requestInlineSuggestion = async () => {
    const initiatingUserId = userId;
    if (!isSignedIn || !initiatingUserId || hydratedProjectUserId.current !== initiatingUserId) {
      flashNotice('Your workspace is still loading. Try suggestions again in a moment.');
      return;
    }
    // Inline completions are deliberately local-only. They must never fall
    // through to a cloud connection when Ollama is offline.
    if (!canRequestInlineSuggestion({
      isSignedIn: Boolean(isSignedIn),
      userId: initiatingUserId,
      hydratedUserId: hydratedProjectUserId.current,
      isSuggesting,
      localModelAvailable: isInlineSuggestionAvailable,
    })) {
      if (!isInlineSuggestionAvailable) {
        flashNotice('Inline suggestions need an available local model.');
      }
      return;
    }

    const requestedFile = activeFile;
    const revisionAtRequest = workspaceRevision.current;
    const position = editorRef.current?.selectionStart ?? currentContent.length;
    const beforeCursor = currentContent.slice(Math.max(0, position - 2200), position);
    const afterCursor = currentContent.slice(position, position + 500);
    suggestionController.current?.abort();
    const controller = new AbortController();
    suggestionController.current = controller;
    setIsSuggesting(true);
    setInlineSuggestion(null);

    try {
      const response = await localModelClient.chat({
        signal: controller.signal,
        messages: [
          {
            role: 'system',
            content: 'You are LANA DEV Inline Suggestions. Return only the code continuation that should be inserted at the cursor. Do not use markdown fences, explanations, or comments about your answer. Keep it concise and preserve the existing coding style.',
          },
          {
            role: 'user',
            content: `Complete the active file at the cursor.\n\nFile: ${activeFile}\n\nCode before cursor:\n${beforeCursor}\n\nCode after cursor:\n${afterCursor}`,
          },
        ],
      });
      if (
        controller.signal.aborted ||
        activeUserIdRef.current !== initiatingUserId ||
        activeFileRef.current !== requestedFile ||
        workspaceRevision.current !== revisionAtRequest
      ) return;
      const text = response.content
        .trim()
        .replace(/^```[a-zA-Z0-9_-]*\n?/, '')
        .replace(/\n?```$/, '')
        .trim();
      if (!text) {
        flashNotice('The local model returned no suggestion.');
        return;
      }
      setInlineSuggestion({
        text: text.slice(0, 1200),
        position,
        baseContent: currentContent,
        filePath: requestedFile,
      });
    } catch (error) {
      if (!controller.signal.aborted && activeUserIdRef.current === initiatingUserId) {
        flashNotice(localModelErrorMessage(error));
      }
    } finally {
      if (activeUserIdRef.current === initiatingUserId && suggestionController.current === controller) {
        suggestionController.current = null;
        setIsSuggesting(false);
      }
    }
  };

  const acceptInlineSuggestion = (acceptance: 'word' | 'line' | 'all' = 'all') => {
    if (!visibleInlineSuggestion) return;
    const application = applyInlineSuggestion({
      content: currentContent,
      filePath: activeFile,
      suggestion: visibleInlineSuggestion,
      acceptance,
    });
    if (application.kind === 'stale') {
      setInlineSuggestion(null);
      flashNotice('This suggestion is out of date. Request a new one.');
      return;
    }
    updateCurrentFile(application.content);
    setInlineSuggestion(application.remaining);
    flashNotice(acceptance === 'all' ? 'Suggestion accepted.' : `${acceptance[0].toUpperCase()}${acceptance.slice(1)} accepted.`);
    window.requestAnimationFrame(() => {
      editorRef.current?.focus();
      editorRef.current?.setSelectionRange(application.nextPosition, application.nextPosition);
    });
  };

  useEffect(() => {
    if (!typingRevision || !isInlineSuggestionAvailable) return;
    const timer = window.setTimeout(() => {
      void requestInlineSuggestion();
    }, 900);
    return () => window.clearTimeout(timer);
  }, [activeFile, isInlineSuggestionAvailable, typingRevision]);

  useEffect(() => {
    suggestionController.current?.abort();
    setInlineSuggestion(null);
  }, [activeFile]);

  useEffect(() => {
    if (isInlineSuggestionAvailable) return;
    suggestionController.current?.abort();
    setInlineSuggestion(null);
    setIsSuggesting(false);
  }, [isInlineSuggestionAvailable]);

  const closeTab = (path: FilePath) => {
    setTabs((current) => {
      if (current.length === 1) return current;
      const next = current.filter((tab) => tab !== path);
      if (path === activeFile) {
        setActiveFile(next[Math.max(0, current.indexOf(path) - 1)]);
      }
      return next;
    });
  };

  const runWorkspace = () => {
    if (previewState === 'running') return;
    const revisionAtStart = workspaceRevision.current;
    if (previewTimer.current) window.clearTimeout(previewTimer.current);
    setReleaseState('idle');
    setPreviewState('running');
    setTerminalLines((current) => [
      ...current,
      { text: '' },
      { text: '$ npm run dev', tone: 'command' },
      { text: '  vite v6.0.5  readying local workspace…', tone: 'dim' },
    ]);
    previewTimer.current = window.setTimeout(() => {
      if (workspaceRevision.current !== revisionAtStart) return;
      setPreviewState('ready');
      setTerminalLines((current) => [
        ...current,
        { text: '  -> Local:   http://localhost:5173/', tone: 'success' },
        { text: '  -> Preview is live · 184ms', tone: 'success' },
      ]);
      previewTimer.current = undefined;
    }, 1100);
  };

  const prepareRelease = () => {
    if (releaseState === 'building' || saveState !== 'saved' || previewState !== 'ready' || !securityReview.securityReady) {
      flashNotice(securityReview.securityReady
        ? 'Save changes and run the preview before preparing a release.'
        : 'Resolve the security review before preparing a release.');
      return;
    }
    const revisionAtStart = workspaceRevision.current;
    if (releaseTimer.current) window.clearTimeout(releaseTimer.current);
    setReleaseState('building');
    releaseTimer.current = window.setTimeout(() => {
      if (workspaceRevision.current === revisionAtStart && securityReadyRef.current) {
        setReleaseState('ready');
      } else {
        setReleaseState('idle');
      }
      releaseTimer.current = undefined;
    }, 900);
  };

  const submitChat = () => {
    const message = visibleChatDraft.trim();
    if (!message || visibleIsModelThinking) return;
    const initiatingUserId = userId;
    if (!isSignedIn || !initiatingUserId || hydratedProjectUserId.current !== initiatingUserId) {
      flashNotice('Your workspace is still loading. Try chat again in a moment.');
      return;
    }
    if (assistantMode === 'edit') {
      void requestEditProposal(message);
      return;
    }
    if (!activeModelClient || !isActiveModelAvailable) {
      flashNotice(selectedAiProvider === 'local'
        ? 'Start Ollama to use local chat.'
        : 'Connect and select a working cloud provider before sending a request.');
      return;
    }
    setMessages((current) => [...current, { id: Date.now(), role: 'you', text: message }]);
    setChatDraft('');
    setIsModelThinking(true);
    const context = createWorkspaceContext(message);
    void activeModelClient.chat({
      messages: [
        {
          role: 'system',
          content: 'You are LANA DEV Copilot. Answer the developer directly using only the supplied local workspace context. Be concise, practical, and do not claim to have changed files or run commands.',
        },
        {
          role: 'user',
          content: `${message}\n\n${buildPromptContext(context)}`,
        },
      ],
    })
      .then((result) => {
        if (activeUserIdRef.current !== initiatingUserId || chatUserId.current !== initiatingUserId) return;
        setMessages((current) => [
          ...current,
          { id: Date.now(), role: 'model', agentLabel: 'Copilot', text: result.content || 'The selected model returned an empty response.' },
        ]);
      })
      .catch((error: unknown) => {
        if (activeUserIdRef.current !== initiatingUserId || chatUserId.current !== initiatingUserId) return;
        setMessages((current) => [
          ...current,
          { id: Date.now(), role: 'model', text: selectedAiProvider === 'local' ? localModelErrorMessage(error) : cloudModelErrorMessage(error) },
        ]);
      })
      .finally(() => {
        if (activeUserIdRef.current === initiatingUserId && chatUserId.current === initiatingUserId) {
          setIsModelThinking(false);
        }
      });
  };

  const createWorkspaceContext = (message: string): WorkspaceContext => {
    const contextBundle = buildProjectContext({
      message,
      activeFile,
      openTabs: tabs,
      selectedPaths: selectedContextPaths,
      files: fileRows.map((file) => ({
        path: file.path,
        content: workspaceFiles[file.path],
        kind: file.kind,
      })),
    });
    return {
      activeFile,
      activeContent: workspaceFiles[activeFile],
      files: contextBundle.files,
      openTabs: tabs,
      selectedPaths: selectedContextPaths,
      instructions: contextBundle.instructions,
      contextSources: contextBundle.sources,
      omittedPaths: contextBundle.omittedPaths,
      contextSummary: {
        includedFiles: contextBundle.files.length,
        omittedFiles: contextBundle.omittedPaths.length,
        characterCount: contextBundle.files.reduce((total, file) => total + file.content.length, 0),
        characterLimit: 34_000,
      },
      previewState,
      terminalOutput: terminalLines.map((line) => line.text).join('\n'),
    };
  };

  const runWorkerReview = () => {
    const initiatingUserId = userId;
    if (!isSignedIn || !initiatingUserId || hydratedProjectUserId.current !== initiatingUserId) {
      flashNotice('Your workspace is still loading. Try the worker review again in a moment.');
      return;
    }
    if (workerRun.state === 'running' || !activeModelClient || !isActiveModelAvailable) {
      if (!activeModelClient || !isActiveModelAvailable) {
        flashNotice(selectedAiProvider === 'local'
          ? 'AI Factory workers need an available local model.'
          : 'Connect and select a working cloud provider before running workers.');
      }
      return;
    }
    const prompt = visibleChatDraft.trim() || `Review the active workspace and suggest the highest-value next steps for ${activeFile}.`;
    setWorkerRun({ state: 'running', prompt });
    void runAgentPipeline({
      message: prompt,
      context: createWorkspaceContext(prompt),
    }, activeModelClient)
      .then((result) => {
        if (activeUserIdRef.current !== initiatingUserId) return;
        setWorkerRun({
          state: 'complete',
          prompt,
          results: result.results.map(({ label, content }) => ({ label, content })),
        });
      })
      .catch((error: unknown) => {
        if (activeUserIdRef.current !== initiatingUserId) return;
        setWorkerRun({ state: 'error', prompt });
        flashNotice(selectedAiProvider === 'local' ? localModelErrorMessage(error) : cloudModelErrorMessage(error));
      });
  };

  const requestEditProposal = async (message: string) => {
    const initiatingUserId = userId;
    if (!isSignedIn || !initiatingUserId || hydratedProjectUserId.current !== initiatingUserId) {
      flashNotice('Your workspace is still loading. Try edit mode again in a moment.');
      return;
    }
    if (!activeModelClient || !isActiveModelAvailable) {
      flashNotice(selectedAiProvider === 'local'
        ? 'Edit proposals need an available local model.'
        : 'Connect and select a working cloud provider before requesting edit proposals.');
      return;
    }
    setMessages((current) => [...current, { id: Date.now(), role: 'you', text: message }]);
    setChatDraft('');
    setIsModelThinking(true);
    setEditProposal(null);
    const contextBundle = buildProjectContext({
      message,
      activeFile,
      files: fileRows.map((file) => ({
        path: file.path,
        content: workspaceFiles[file.path],
        kind: file.kind,
      })),
    });
    const filesForPrompt = contextBundle.files.map((file) => ({
      path: file.path,
      content: file.content,
    }));

    try {
      const response = await activeModelClient.chat({
        messages: [
          {
            role: 'system',
            content: 'You are LANA DEV Edit Mode. Return only valid JSON with this exact shape: {"summary":"short explanation","files":[{"path":"one existing file path","content":"the complete replacement file content"}]}. Only include files that need changes. Never use markdown fences. Do not make changes outside the supplied files.',
          },
          {
            role: 'user',
            content: `Requested edit: ${message}\n\nProject instructions:\n${contextBundle.instructions ?? 'None supplied.'}\n\nSelected project files:\n${JSON.stringify(filesForPrompt)}`,
          },
        ],
      });
      if (activeUserIdRef.current !== initiatingUserId) return;
      const raw = response.content.trim().replace(/^```json\s*/i, '').replace(/\s*```$/, '');
      const parsed = JSON.parse(raw) as {
        summary?: unknown;
        files?: Array<{ path?: unknown; content?: unknown }>;
      };
      const changes = Array.isArray(parsed.files)
        ? parsed.files.flatMap((file): ProposedFileChange<FilePath>[] => {
          if (
            typeof file.path !== 'string' ||
            typeof file.content !== 'string' ||
            !fileRows.some((workspaceFile) => workspaceFile.path === file.path)
          ) {
            return [];
          }
          const path = file.path as FilePath;
          const original = workspaceFiles[path];
          return original === file.content
            ? []
            : [{ path, original, updated: file.content, hunks: createHunks(original, file.content, path) }];
        })
        : [];

      if (!changes.length) {
        flashNotice('The local model did not propose any file changes.');
        return;
      }
      setEditProposal({
        summary: typeof parsed.summary === 'string' && parsed.summary.trim()
          ? parsed.summary.trim()
          : `Review ${changes.length} proposed file change${changes.length === 1 ? '' : 's'}.`,
        changes,
      });
    } catch (error) {
      if (activeUserIdRef.current !== initiatingUserId) return;
      if (error instanceof SyntaxError) {
        flashNotice('The local model returned an unreadable edit proposal. Try a more specific request.');
      } else {
        flashNotice(selectedAiProvider === 'local' ? localModelErrorMessage(error) : cloudModelErrorMessage(error));
      }
    } finally {
      if (activeUserIdRef.current === initiatingUserId) {
        setIsModelThinking(false);
      }
    }
  };

  const applyEditProposal = (proposal = visibleEditProposal) => {
    if (!proposal || hydratedProjectUserId.current !== userId) return;
    const result = applyEditProposalChanges(workspaceFiles, proposal);
    if (result.kind === 'no-selection') {
      flashNotice('Select at least one hunk to apply.');
      return;
    }
    if (result.kind === 'stale') {
      flashNotice('One or more files changed while this proposal was open. Request a new proposal.');
      return;
    }
    setEditableFiles(result.files);
    workspaceRevision.current += 1;
    setPreviewState('idle');
    setReleaseState('idle');
    setEditProposal(null);
    flashNotice(`${result.hunkCount} approved hunk${result.hunkCount === 1 ? '' : 's'} applied.`);
  };

  const acceptAllEditProposal = () => {
    if (!visibleEditProposal) return;
    const acceptedProposal = {
      ...visibleEditProposal,
      changes: visibleEditProposal.changes.map((change) => ({
        ...change,
        hunks: change.hunks.map((hunk) => ({ ...hunk, selected: true })),
      })),
    };
    setEditProposal(acceptedProposal);
    applyEditProposal(acceptedProposal);
  };

  const refreshExplorer = () => {
    setExplorerError(false);
    setIsExplorerLoading(true);
    window.setTimeout(() => setIsExplorerLoading(false), 550);
  };

  const flashNotice = (text: string) => {
    setNotice(text);
    window.setTimeout(() => setNotice(''), 2200);
  };

  const statusText = previewState === 'ready' ? 'Preview live' : previewState === 'running' ? 'Starting preview' : 'Preview idle';
  const modelStatusText = visibleIsModelThinking
    ? 'thinking…'
    : selectedAiProvider !== 'local'
      ? selectedCloudConnection
        ? `${selectedCloudConnection.label} · cloud`
        : `${selectedAiProvider} not connected`
      : localModelStatus.state === 'checking'
        ? 'checking local model…'
        : localModelStatus.state === 'available'
          ? `${isBrowserLocalRuntime() ? BROWSER_MODEL_ID : getConfiguredModelName()} · local`
          : localModelStatus.error?.startsWith('Model ')
            ? 'Model unavailable'
            : isAndroidRuntime()
              ? localModelStatus.runtimeState === 'memory-pressure'
                ? 'Memory pressure'
                : localModelStatus.runtimeState === 'unsupported'
                  ? 'Device unsupported'
                  : 'Android model offline'
            : isDesktopRuntime()
              ? 'Desktop runtime offline'
            : 'Browser model offline';
  const browserRuntimeLabel = localModelStatus.runtime === 'webgpu'
    ? 'WebGPU'
    : localModelStatus.runtime === 'wasm'
      ? 'WASM'
      : 'Preparing';
  const browserCacheLabel = localModelStatus.cacheState === 'cached'
    ? 'Cached'
    : localModelStatus.cacheState === 'not-cached'
      ? 'Not cached'
      : localModelStatus.cacheState === 'checking'
        ? 'Checking'
        : 'Unknown';
  const browserProgressLabel = localModelStatus.progress === undefined
    ? localModelStatus.runtimeMessage
    : `${Math.round(localModelStatus.progress * 100)}% · ${localModelStatus.runtimeMessage ?? 'Preparing the local model…'}`;

  if (appMode === 'home') {
    return (
      <LanaHome 
        onOpenVibeCode={() => {
          setEntryMode('vibe');
          setHomeArea('home');
          setActiveSidebarArea(null);
          setWorkspacePage('build');
          setChatDraft('I want to build ');
          setMessages((current) => current.some((message) => message.agentLabel === 'Vibe Code')
            ? current
            : [...current, {
              id: Date.now(),
              role: 'model',
              agentLabel: 'Vibe Code',
              text: 'Describe what you want to make. I will help you shape the first version, then you can refine it directly in the IDE.',
            }]);
          flashNotice('Vibe Code is ready — describe what you want to make.');
          setAppMode('vibe');
        }}
        onOpenIDE={() => {
          setEntryMode('ide');
          setHomeArea('home');
          setActiveSidebarArea(null);
          setWorkspacePage('build');
          setAppMode('ide');
        }}
        selectedTool={selectedTool}
        activeArea={homeArea}
        onNavigateArea={setHomeArea}
        selectedAiProvider={selectedAiProvider}
        onSelectAiProvider={setSelectedAiProvider}
        onSelectTool={(toolId) => {
          setSelectedTool(toolId);
            setHomeArea('home');
          setAppMode('tool');
        }}
      />
    );
  }

  if (appMode === 'tool' && selectedTool) {
    return (
      <ToolWorkspace
        toolId={selectedTool}
        onBack={() => setAppMode('home')}
        onChooseTool={setSelectedTool}
      />
    );
  }

  const navigateWorkspace = (page: WorkspacePage) => {
    setActiveSidebarArea(null);
    setWorkspacePage(page);
    if (appMode === 'vibe' && page !== 'build') {
      setAppMode('ide');
    }
  };

  const navigateSidebarArea = (area: WorkspaceArea) => {
    setActiveSidebarArea(area);
    setAppMode('section');
  };

  const currentProjectFiles = fileRows.map((file) => ({
    path: file.path,
    content: workspaceFiles[file.path],
    kind: file.kind,
  }));

  const applyTemplate = async (template: ProjectTemplate) => {
    const hasWorkspaceChanges = currentProjectFiles.some(
      (file) => file.content !== defaultFileContents[file.path as FilePath],
    );
    const recoveryMessage = isSignedIn && hasWorkspaceChanges
      ? ' A recovery template of your current files will be saved first.'
      : '';
    if (!window.confirm(`Use "${template.name}"? This replaces the files in your current workspace.${recoveryMessage}`)) {
      return;
    }
    if (isSignedIn && hasWorkspaceChanges) {
      const recoveryTemplate: ProjectTemplate = {
        id: `recovery-${Date.now()}`,
        name: `Recovery · before ${template.name}`,
        description: `Automatic snapshot created before applying ${template.name}.`,
        category: 'Recovery',
        files: currentProjectFiles,
      };
      const didSaveRecovery = await persistResources({ templates: [...resourcesForCurrentUser.templates, recoveryTemplate] });
      if (!didSaveRecovery) {
        flashNotice('Template was not applied because the recovery copy could not be saved.');
        return;
      }
    }
    const loadedFiles = { ...defaultFileContents };
    for (const file of template.files) {
      if (file.path in loadedFiles) loadedFiles[file.path as FilePath] = file.content;
    }
    setEditableFiles(loadedFiles);
    setActiveFile('src/App.tsx');
    setTabs(['src/App.tsx', 'src/index.css', 'README.md']);
    workspaceRevision.current += 1;
    if (previewTimer.current) window.clearTimeout(previewTimer.current);
    if (releaseTimer.current) window.clearTimeout(releaseTimer.current);
    previewTimer.current = undefined;
    releaseTimer.current = undefined;
    setPreviewState('idle');
    setReleaseState('idle');
    setInlineSuggestion(null);
    setEditProposal(null);
    setWorkerRun({ state: 'idle' });
    setTerminalTab('terminal');
    setTerminalLines((current) => [
      ...current,
      { text: '' },
      { text: `Loaded ${template.name} starter files.`, tone: 'success' },
      { text: 'Edit src/App.tsx, then run the workspace when you are ready.', tone: 'dim' },
    ]);
    flashNotice(`${template.name} is ready to customize.`);
    setActiveSidebarArea(null);
    setWorkspacePage('build');
    setAppMode('ide');
  };

  const reuseLibraryItem = (item: LibraryItem) => {
    const activeContent = workspaceFiles[activeFile].replace(/\r\n/g, '\n').trim();
    const libraryContent = item.content.replace(/\r\n/g, '\n').trim();
    if (libraryContent && activeContent.includes(libraryContent)) {
      setActiveSidebarArea(null);
      setWorkspacePage('build');
      setAppMode('ide');
      flashNotice(`${item.name} is already in ${activeFile}.`);
      return;
    }
    updateCurrentFile(`${workspaceFiles[activeFile].replace(/\s*$/, '')}\n\n${item.content}`);
    setActiveSidebarArea(null);
    setWorkspacePage('build');
    setAppMode('ide');
    flashNotice(`${item.name} added to ${activeFile}.`);
  };

  if (appMode === 'vibe') {
    return (
      <div className="vibe-shell">
        <WorkspaceSidebar
          activePage={workspacePage}
          activeArea={activeSidebarArea}
          mode="vibe"
          securityNeedsAttention={securityNeedsAttention}
          onNavigate={navigateWorkspace}
          onNavigateArea={navigateSidebarArea}
          onHome={() => {
            setHomeArea('home');
            setAppMode('home');
          }}
        />
        <VibeCodeWorkspace
          messages={visibleMessages}
          chatDraft={visibleChatDraft}
          isModelThinking={visibleIsModelThinking}
          assistantStatusText={modelStatusText}
          isModelAvailable={isActiveModelAvailable}
          previewState={previewState}
          onChatDraftChange={setChatDraft}
          onSubmitChat={submitChat}
          onBack={() => setAppMode('home')}
          onRunPreview={runWorkspace}
        />
      </div>
    );
  }

  if (appMode === 'section' && activeSidebarArea) {
    return (
      <div className="ide-app">
        <div className="section-shell">
          <WorkspaceSidebar
            activePage={workspacePage}
            activeArea={activeSidebarArea}
            mode={entryMode}
            securityNeedsAttention={securityNeedsAttention}
            onNavigate={navigateWorkspace}
            onNavigateArea={navigateSidebarArea}
            onHome={() => {
              setHomeArea('home');
              setAppMode('home');
            }}
          />
          {activeSidebarArea === 'templates' || activeSidebarArea === 'routines' || activeSidebarArea === 'library' ? (
            <ResourceWorkspace
              key={userId ?? 'signed-out'}
              area={activeSidebarArea}
              resources={resourcesForCurrentUser}
              isLoading={Boolean(isResourcesLoading && isSignedIn)}
              isSaving={resourceSaveState === 'saving'}
              isSignedIn={Boolean(isSignedIn)}
              userId={userId ?? null}
              isCurrentUser={(candidateUserId) => activeUserIdRef.current === candidateUserId}
              currentFiles={currentProjectFiles}
              activeFile={activeFile}
              activeContent={workspaceFiles[activeFile]}
              onSaveResources={persistResources}
              onApplyTemplate={applyTemplate}
              onInsertLibraryItem={reuseLibraryItem}
              onBackToBuild={() => navigateWorkspace('build')}
              onNotice={flashNotice}
            />
          ) : (
            <WorkspaceAreaPage
              area={activeSidebarArea}
              onBackToBuild={() => navigateWorkspace('build')}
              onApplyTemplate={() => undefined}
              isSignedIn={Boolean(isSignedIn)}
              selectedAiProvider={selectedAiProvider}
              onSelectAiProvider={setSelectedAiProvider}
              securityReview={securityReview}
              onNavigateWorkspace={navigateWorkspace}
              onOpenIntegrations={() => navigateSidebarArea('integrations')}
              onOpenRequestReview={() => {
                setSelectedTool('api-tester');
                setAppMode('tool');
              }}
              onApproveRequestReview={() => {
                setApprovedRequestReviewRevision(workspaceRevision.current);
                flashNotice('Request code review recorded for this workspace revision.');
              }}
              onRetrySave={() => void persistProject()}
            />
          )}
        </div>
      </div>
    );
  }

  return (
    <div className="ide-app">
      <div className="ide-shell">
        <header className="topbar" data-testid="header-topbar">
          <div className="topbar-inner">
            <div className="flex items-center gap-3">
              <button className="ide-brand" onClick={() => setAppMode('home')} title="Back to LANA DEV home" aria-label="Back to LANA DEV home" data-testid="button-back-to-lana-home">
                <img className="brand-mark" src={`${basePath}/logo.svg`} alt="" aria-hidden="true" />
                <div className="brand-copy text-left">
                  <div className="text-[13px] font-extrabold tracking-[-0.03em]">LANA DEV <span className="font-mono text-[10px] font-medium text-[#9296a7]">/ IDE</span></div>
                  <div className="font-mono text-[9px] uppercase tracking-[0.12em] text-[#85899b]">browser workspace · local</div>
                </div>
              </button>
            </div>
            <div className="flex min-w-0 items-center gap-2">
               <div className={`save-status ${saveState}`} data-testid="status-save">
                 {saveState === 'saving' ? 'Saving…' : saveState === 'error' ? 'Save failed' : saveState === 'sign-in' ? 'Sign in to save' : 'Saved'}
               </div>
               {isSignedIn && <span className="hidden font-mono text-[10px] text-[#9296a7] md:inline">{userId ? 'Signed in' : ''}</span>}
               {!isSignedIn && <a className="topbar-button hidden sm:inline-flex" href={`${basePath}/sign-in`}>Sign in</a>}
               {isSignedIn && <button className="topbar-button hide-mobile" onClick={() => void persistProject()} title="Save project now" data-testid="button-save-project"><Check size={14} /><span>Save</span></button>}
              <div className={`preview-pill ${previewState === 'ready' ? 'running' : ''}`} data-testid="status-preview">
                <span className={`status-dot ${previewState === 'running' ? 'busy' : ''}`} />
                <span className="hidden sm:inline">{statusText}</span>
              </div>
              {visibleNotice && <span className="topbar-notice hidden md:inline" data-testid="status-topbar-notice">{visibleNotice}</span>}
              <button className="topbar-button mobile-toggle" onClick={() => setMobileFilesOpen((open) => !open)} title="Toggle file explorer" data-testid="button-toggle-explorer">
                <Menu size={15} />
              </button>
              <button className="topbar-button hide-mobile" onClick={() => flashNotice('Working tree is clean')} title="Source control" data-testid="button-source-control"><GitBranch size={14} /><span className="font-mono text-[10px]">main</span></button>
              <button className="topbar-button hide-mobile" onClick={() => flashNotice('Workspace settings are local')} title="Workspace settings" data-testid="button-settings"><Settings2 size={15} /></button>
              <button className="topbar-button hide-mobile" onClick={() => flashNotice('Tip: press Enter to ask the model')} title="Help" data-testid="button-help"><HelpCircle size={15} /></button>
              <button className="run-button inline-flex h-[31px] items-center gap-2 transition-transform" onClick={runWorkspace} disabled={previewState === 'running'} data-testid="button-run-workspace">
                <Play size={13} fill="currentColor" /><span>{runLabel}</span>
              </button>
            </div>
          </div>
        </header>

        <div className="ide-body">
          <WorkspaceSidebar
            activePage={workspacePage}
            activeArea={activeSidebarArea}
            mode="ide"
            securityNeedsAttention={securityNeedsAttention}
            onNavigate={navigateWorkspace}
            onNavigateArea={navigateSidebarArea}
            onHome={() => {
              setHomeArea('home');
              setAppMode('home');
            }}
          />
          <div className="ide-content">
        {workspacePage === 'build' ? <main className="workspace">
          <aside className={`file-panel ${mobileFilesOpen ? 'mobile-open' : ''}`} data-testid="panel-file-explorer">
            <div className="file-wrap">
              <div className="panel-heading">
                <div>
                  <div className="eyebrow">Workspace</div>
                  <div className="panel-title mt-1">Explorer</div>
                </div>
                <div className="flex items-center gap-1">
                  <button className="muted-icon-button" onClick={refreshExplorer} title="Refresh explorer" data-testid="button-refresh-explorer"><RotateCcw size={14} className={isExplorerLoading ? 'animate-spin' : ''} /></button>
                  <button className="muted-icon-button" onClick={() => setExplorerError(true)} title="Show explorer status" data-testid="button-explorer-status"><MoreHorizontal size={15} /></button>
                </div>
              </div>
              <label className="workspace-search">
                <Search size={13} />
                <input
                  value={workspaceSearch}
                  onChange={(event) => setWorkspaceSearch(event.target.value)}
                  placeholder="Search files and contents"
                  aria-label="Search workspace files and contents"
                  data-testid="input-workspace-search"
                />
              </label>
              {workspaceSearch.trim() && (
                <div className="workspace-search-results" data-testid="region-workspace-search-results">
                  {fileRows
                    .filter((file) => `${file.path}\n${workspaceFiles[file.path]}`.toLowerCase().includes(workspaceSearch.trim().toLowerCase()))
                    .map((file) => (
                      <button
                        className={`tree-file ${selectedContextPaths.includes(file.path) ? 'context-pinned' : ''}`}
                        key={`search-${file.path}`}
                        onClick={(event) => event.shiftKey ? toggleContextPath(file.path) : openFile(file.path)}
                        title="Click to open · Shift-click to pin context"
                        data-testid={`button-search-result-${file.path.replace(/[/.]/g, '-')}`}
                      ><Search size={12} /><span>{file.path}</span>{selectedContextPaths.includes(file.path) && <small>pinned</small>}</button>
                    ))}
                  {!fileRows.some((file) => `${file.path}\n${workspaceFiles[file.path]}`.toLowerCase().includes(workspaceSearch.trim().toLowerCase())) && (
                    <div className="workspace-search-empty">No matching files.</div>
                  )}
                </div>
              )}
              {explorerError ? (
                <div className="mx-2 mt-2 rounded border border-[#e7c7bc] bg-[#fff0eb] p-3 text-[11px] leading-relaxed text-[#a24e3e]" data-testid="state-explorer-error">
                  <div className="mb-1 flex items-center gap-1 font-bold"><CircleAlert size={13} /> Explorer unavailable</div>
                  <div className="mb-2">The local file index did not respond.</div>
                  <button onClick={refreshExplorer} className="font-mono text-[10px] font-bold underline" data-testid="button-retry-explorer">Retry scan</button>
                </div>
              ) : isExplorerLoading ? (
                <div className="space-y-3 px-3 pt-2" data-testid="state-explorer-loading">
                  <div className="skeleton-line w-24" /><div className="skeleton-line w-36" /><div className="skeleton-line w-28" />
                </div>
              ) : (
                  <div className="animate-[appear_.2s_ease-out]">
                  <div className="tree-root"><ChevronDown size={13} /><Folder size={14} className="text-[#9b6511]" /><span>lana-dev</span></div>
                  <div className="ml-1 border-l border-[#e5e0d6]">
                    <button
                      className={`tree-root pl-3 ${selectedContextPaths.includes('src') ? 'context-pinned' : ''}`}
                      onClick={(event) => event.shiftKey ? toggleContextPath('src') : undefined}
                      title="Shift-click to include the src folder in assistant context"
                      data-testid="button-context-folder-src"
                    ><ChevronDown size={13} /><Folder size={14} className="text-[#8a8c9e]" /><span>src</span><small>{selectedContextPaths.includes('src') ? 'pinned' : 'shift-click to pin'}</small></button>
                    <div className="space-y-0.5">
                      {fileRows.slice(0, 3).map((file) => (
                        <button className={`tree-file ${activeFile === file.path ? 'active' : ''} ${selectedContextPaths.includes(file.path) ? 'context-pinned' : ''}`} key={file.path} onClick={(event) => event.shiftKey ? toggleContextPath(file.path) : openFile(file.path)} title="Click to open · Shift-click to pin context" data-testid={`button-file-${file.path.replace(/[/.]/g, '-')}`}>
                          <span className="file-dot" /><IconForFile kind={file.kind} /><span>{file.path.replace('src/', '')}</span>{selectedContextPaths.includes(file.path) && <small>pinned</small>}
                        </button>
                      ))}
                    </div>
                    <button className={`tree-root pl-3 ${selectedContextPaths.includes('src/components') ? 'context-pinned' : ''}`} onClick={(event) => event.shiftKey ? toggleContextPath('src/components') : undefined} title="Shift-click to include the src/components folder in assistant context" data-testid="button-context-folder-components"><ChevronRight size={13} /><Folder size={14} className="text-[#8a8c9e]" /><span>components</span><small>{selectedContextPaths.includes('src/components') ? 'pinned' : 'shift-click to pin'}</small></button>
                  </div>
                  <div className="mt-1 space-y-0.5">
                    {fileRows.slice(3).map((file) => (
                      <button className={`tree-file ${activeFile === file.path ? 'active' : ''} ${selectedContextPaths.includes(file.path) ? 'context-pinned' : ''}`} key={file.path} onClick={(event) => event.shiftKey ? toggleContextPath(file.path) : openFile(file.path)} title="Click to open · Shift-click to pin context" data-testid={`button-file-${file.path.replace(/[/.]/g, '-')}`}>
                        <span className="file-dot" /><IconForFile kind={file.kind} /><span>{file.path}</span>{selectedContextPaths.includes(file.path) && <small>pinned</small>}
                      </button>
                    ))}
                  </div>
                </div>
              )}
              <div className="project-foot">
                <div className="flex items-center justify-between">
                  <span className="eyebrow">Branch</span>
                  <span className="font-mono text-[10px] text-[#55586a]">main</span>
                </div>
                <div className="mt-2 flex items-center gap-1.5 text-[10px] text-[#858174]"><CircleDot size={11} className={saveState === 'saving' ? 'text-[#e9a52b]' : 'text-[#4a9d81]'} /> {saveState === 'saving' ? 'Saving changes…' : saveState === 'error' ? 'Could not save changes' : saveState === 'sign-in' ? 'Sign in to save changes' : 'All changes saved'}</div>
              </div>
            </div>
          </aside>

          <section className="editor-zone" data-testid="panel-editor">
            <div className="tabs" role="tablist" aria-label="Open files">
              {tabs.map((tab) => (
                <div className={`tab ${tab === activeFile ? 'active' : ''}`} key={tab} role="tab" aria-selected={tab === activeFile}>
                  <button className="min-w-0 flex-1 truncate text-left" onClick={() => setActiveFile(tab)} data-testid={`button-tab-${tab.replace(/[/.]/g, '-')}`}>{tab}</button>
                  <button className="tab-close" onClick={() => closeTab(tab)} title={`Close ${tab}`} data-testid={`button-close-tab-${tab.replace(/[/.]/g, '-')}`}><X size={13} /></button>
                </div>
              ))}
              <button className="ml-auto grid min-w-[40px] place-items-center text-[#73798d] transition-colors hover:text-[#f4b943]" onClick={() => openFile('src/main.tsx')} title="Open main.tsx" data-testid="button-new-tab"><Plus size={14} /></button>
            </div>
            <div className="editor" data-testid="editor-code">
              <div className="mb-5 flex items-center gap-2 px-5 font-mono text-[10px] text-[#72788b]"><span className="text-[#e9a52b]">src</span><span>/</span><span>{activeFile.replace('src/', '')}</span><span className="ml-auto">UTF-8 · LF · TSX</span></div>
              <div className="editor-input-wrap">
                <div className="line-gutter" aria-hidden="true">
                  {currentLines.map((_, index) => <span key={`${activeFile}-line-${index}`}>{String(index + 1).padStart(2, '0')}</span>)}
                </div>
                <textarea
                   ref={editorRef}
                  className="code-editor-input"
                  value={currentContent}
                   onChange={(event) => {
                     updateCurrentFile(event.target.value);
                     setTypingRevision((current) => current + 1);
                   }}
                   onKeyDown={(event) => {
                     if (visibleInlineSuggestion && !isSuggesting) {
                        const action = getInlineSuggestionKeyboardAction(event);
                        if (action === 'dismiss') {
                         event.preventDefault();
                         setInlineSuggestion(null);
                         return;
                       }
                        if (action) {
                         event.preventDefault();
                          acceptInlineSuggestion(action);
                         return;
                       }
                     }
                     if ((event.ctrlKey || event.metaKey) && event.code === 'Space') {
                       event.preventDefault();
                       void requestInlineSuggestion();
                     }
                   }}
                  spellCheck={false}
                  aria-label={`Edit ${activeFile}`}
                  data-testid="input-editor-content"
                />
              </div>
               <div className="editor-suggestion-bar" data-testid="panel-inline-suggestion">
                 <div className="editor-suggestion-meta">
                   <span className="editor-suggestion-label"><Sparkles size={12} /> Inline suggestion</span>
                   <span className="editor-suggestion-hint">Ctrl/Cmd + Space</span>
                   <button
                     className="editor-suggest-button"
                     onClick={() => void requestInlineSuggestion()}
                     disabled={isSuggesting || !isInlineSuggestionAvailable}
                     data-testid="button-request-inline-suggestion"
                   >
                     {isSuggesting ? 'Thinking…' : 'Suggest'}
                   </button>
                 </div>
                 {visibleInlineSuggestion ? (
                    <div className="editor-suggestion-preview">
                      <code aria-label="Suggested code">{visibleInlineSuggestion.text}</code>
                      <div className="editor-suggestion-actions" aria-label="Suggestion actions">
                        <button onClick={() => acceptInlineSuggestion('word')} title="Accept the next word (Ctrl/Cmd + Right Arrow)" data-testid="button-accept-inline-suggestion-word">Word</button>
                        <button onClick={() => acceptInlineSuggestion('line')} title="Accept the next line (Enter)" data-testid="button-accept-inline-suggestion-line">Line</button>
                        <button onClick={() => acceptInlineSuggestion('all')} title="Accept the full suggestion (Tab)" data-testid="button-accept-inline-suggestion">All</button>
                        <button onClick={() => setInlineSuggestion(null)} title="Dismiss the suggestion (Escape)" data-testid="button-dismiss-inline-suggestion">Dismiss</button>
                     </div>
                   </div>
                 ) : (
                   <span className="editor-suggestion-empty">
                    {isInlineSuggestionAvailable ? 'Ask the local model for the next logical edit without changing your file.' : isBrowserLocalRuntime() ? `Download ${BROWSER_MODEL_ID} (${BROWSER_MODEL_SIZE}) to enable local suggestions. Prompts never leave this device.` : 'Start Ollama to enable local inline suggestions. Cloud models are not used for completions.'}
                   </span>
                 )}
               </div>
            </div>
            <div className="terminal" data-testid="panel-terminal">
              <div className="terminal-head">
                <div className="terminal-tabs">
                  <button className={`terminal-tab ${terminalTab === 'terminal' ? 'active' : ''}`} onClick={() => setTerminalTab('terminal')} data-testid="button-terminal-tab">TERMINAL</button>
                  <button className={`terminal-tab ${terminalTab === 'output' ? 'active' : ''}`} onClick={() => setTerminalTab('output')} data-testid="button-output-tab">OUTPUT</button>
                </div>
                <div className="flex items-center gap-3">
                  <span className="font-mono text-[10px] text-[#696f83]" data-testid="text-terminal-shell">zsh · 1</span>
                  <button className="text-[#696f83] transition-colors hover:text-[#f4b943]" title="Clear terminal" onClick={() => setTerminalLines([])} data-testid="button-clear-terminal"><RotateCcw size={13} /></button>
                </div>
              </div>
              <div className="terminal-body">
                {terminalTab === 'output' ? (
                  <div className="flex items-center gap-2 py-2 text-[#83cfb9]" data-testid="state-output"><Check size={13} /> Build output is clean. No diagnostics.</div>
                ) : terminalLines.length ? terminalLines.map((line, index) => <div className={`terminal-line ${line.tone ?? ''}`} key={`${line.text}-${index}`} data-testid={`text-terminal-line-${index}`}>{line.text || ' '}</div>) : (
                  <div className="py-2 text-[#666d82]" data-testid="state-terminal-empty">Terminal is empty. Run a command to see output.</div>
                )}
                {previewState === 'running' && <div className="terminal-line command animate-pulse" data-testid="status-terminal-running">  waiting for local server…</div>}
              </div>
            </div>
          </section>

          <aside className="chat-panel" data-testid="panel-assistant">
            <div className="chat-head">
              <div>
                <div className="eyebrow">{entryMode === 'vibe' ? 'Vibe Code' : 'LANA DEV Copilot'}</div>
                <div className="panel-title mt-1">{entryMode === 'vibe' ? 'Describe your idea' : assistantMode === 'edit' ? 'Propose edits' : 'Ask your selected model'}</div>
                <div className="model-chip" title={selectedAiProvider === 'local' ? localModelStatus.error : 'User-owned cloud API account'} data-testid="status-model"><Sparkles size={11} /> {modelStatusText}</div>
                {isBrowserLocalRuntime() && selectedAiProvider === 'local' && (
                  <details className="browser-model-diagnostics">
                    <summary data-testid="button-toggle-browser-model-diagnostics">
                      <HardDrive size={11} /> Model storage
                    </summary>
                    <div className="browser-model-diagnostics-body" data-testid="panel-browser-model-diagnostics">
                      <div>
                        <span>Cache</span>
                        <strong data-testid="status-browser-model-cache">{browserCacheLabel}</strong>
                      </div>
                      <div>
                        <span>Model storage</span>
                        <strong data-testid="text-browser-model-storage">
                          {localModelStatus.cacheState === 'cached'
                            ? `≈${formatStorageSize(localModelStatus.estimatedModelStorageBytes)}`
                            : '0 MB'}
                        </strong>
                      </div>
                      <div>
                        <span>Active runtime</span>
                        <strong data-testid="text-browser-model-runtime">{browserRuntimeLabel}</strong>
                      </div>
                      {localModelStatus.browserStorageUsageBytes !== undefined && (
                        <div>
                          <span>Browser site data</span>
                          <strong data-testid="text-browser-site-storage">
                            {formatStorageSize(localModelStatus.browserStorageUsageBytes)}
                            {localModelStatus.browserStorageQuotaBytes ? ` / ${formatStorageSize(localModelStatus.browserStorageQuotaBytes)}` : ''}
                          </strong>
                        </div>
                      )}
                      {localModelStatus.state === 'checking' && (
                        <div className="browser-model-progress" role="status" data-testid="status-browser-model-progress">
                          <span>{browserProgressLabel}</span>
                          {localModelStatus.progress !== undefined && (
                            <progress value={localModelStatus.progress} max={1} aria-label="Browser model preparation progress" />
                          )}
                        </div>
                      )}
                      <p>Model files and prompts stay on this device. Clearing removes only LANA DEV’s browser model files.</p>
                      <button
                        className="browser-model-clear"
                        onClick={() => void clearBrowserModelCache()}
                        disabled={isClearingBrowserCache || localModelStatus.state === 'checking'}
                        data-testid="button-clear-browser-model-cache"
                      >
                        <RotateCcw size={10} />
                        {isClearingBrowserCache
                          ? 'Clearing and rebuilding…'
                          : localModelStatus.state === 'checking'
                            ? 'Model setup in progress…'
                            : 'Clear and rebuild cache'}
                      </button>
                    </div>
                  </details>
                )}
                {(isDesktopRuntime() || isAndroidRuntime() || isBrowserLocalRuntime()) && localModelStatus.state !== 'available' && (
                  <button className="desktop-runtime-action" onClick={() => void desktopSetup()} data-testid="button-retry-local-setup">
                    <RotateCcw size={10} /> {isBrowserLocalRuntime() ? 'Retry browser model' : isAndroidRuntime() ? 'Retry model setup' : 'Retry local setup'}
                  </button>
                )}
                {isAndroidRuntime() && localModelStatus.state !== 'available' && localModelStatus.error && (
                  <div className="local-runtime-status" role="status" data-testid="status-android-runtime">
                    <CircleAlert size={12} />
                    <span>{localModelStatus.error}</span>
                  </div>
                )}
              </div>
              <button className="muted-icon-button" onClick={() => navigateSidebarArea('integrations')} title="Choose AI provider" data-testid="button-assistant-options"><MoreHorizontal size={15} /></button>
            </div>
            <div className="assistant-mode-switch" role="tablist" aria-label="Assistant mode">
              <button
                className={assistantMode === 'chat' ? 'active' : ''}
                onClick={() => setAssistantMode('chat')}
                role="tab"
                aria-selected={assistantMode === 'chat'}
                data-testid="button-assistant-mode-chat"
              >
                Chat
              </button>
              <button
                className={assistantMode === 'edit' ? 'active' : ''}
                onClick={() => setAssistantMode('edit')}
                role="tab"
                aria-selected={assistantMode === 'edit'}
                data-testid="button-assistant-mode-edit"
              >
                Edit
              </button>
            </div>
            <div className="context-sources" data-testid="panel-context-sources">
              <div className="context-sources-head">
                <span>Selected context</span>
                <button onClick={() => openFile('LANA.md')} data-testid="button-open-project-instructions">
                  Project rules
                </button>
              </div>
              <div className="context-source-list">
                {contextPreview.sources.map((source) => (
                  <span className="context-source-chip" key={source.path} title={`${source.reason} context`}>
                    {source.path.replace('src/', '')}
                    <small>{source.reason === 'instructions' ? 'rules' : source.reason}</small>
                  </span>
                ))}
              </div>
              <div className="context-budget" data-testid="text-context-budget">
                {contextPreview.sources.length} files included
                {contextPreview.omittedPaths.length ? ` · ${contextPreview.omittedPaths.length} omitted by the context limit` : ' · workspace fully represented'}
                <span>Reference files or folders with @path in your request. Shift-click explorer items to pin them.</span>
              </div>
            </div>
            <section className="worker-panel" data-testid="panel-ai-workers">
              <div className="worker-panel-head">
                <div>
                  <div className="worker-panel-title"><span className={`worker-status-dot ${visibleWorkerRun.state}`} /> AI Factory workers</div>
                  <p>{visibleWorkerRun.state === 'running' ? 'Workers are reviewing in the background. Copilot stays available.' : 'Run specialist workers beside Copilot when you want a deeper review.'}</p>
                </div>
                <button
                  className="worker-run-button"
                  onClick={runWorkerReview}
                  disabled={visibleWorkerRun.state === 'running' || !isActiveModelAvailable}
                  data-testid="button-run-ai-workers"
                >
                  {visibleWorkerRun.state === 'running' ? 'Running…' : 'Run workers'}
                </button>
              </div>
              {visibleWorkerRun.results && (
                <div className="worker-results" data-testid="region-worker-results">
                  {visibleWorkerRun.results.map((result) => (
                    <details className="worker-result" key={result.label}>
                      <summary><span>{result.label}</span><ChevronRight size={12} /></summary>
                      <p>{result.content}</p>
                    </details>
                  ))}
                </div>
              )}
            </section>
            <div className="chat-stream" data-testid="region-chat-messages">
              {visibleEditProposal && (
                <section className="edit-review-card" data-testid="panel-edit-review">
                  <div className="edit-review-heading">
                    <div>
                      <div className="message-label">Review proposed changes</div>
                      <p>{visibleEditProposal.summary}</p>
                    </div>
                    <div className="edit-review-heading-actions">
                      <button onClick={() => setEditProposal(null)} data-testid="button-reject-edit-proposal">Reject all</button>
                      <button onClick={acceptAllEditProposal} data-testid="button-accept-all-edit-proposal">Accept all</button>
                    </div>
                  </div>
                  <div className="edit-review-files">
                    {visibleEditProposal.changes.map((change, index) => (
                      <article className="edit-review-file" key={change.path}>
                        <label className="edit-review-file-head">
                          <input
                            type="checkbox"
                            checked={change.hunks.every((hunk) => hunk.selected)}
                            onChange={() => setEditProposal((current) => current ? {
                              ...current,
                              changes: current.changes.map((item, itemIndex) => itemIndex === index
                                ? { ...item, hunks: item.hunks.map((hunk) => ({ ...hunk, selected: !change.hunks.every((currentHunk) => currentHunk.selected) })) }
                                : item),
                            } : current)}
                            data-testid={`checkbox-edit-change-${change.path.replace(/[/.]/g, '-')}`}
                          />
                          <span>{change.path} <small>{change.hunks.length} hunk{change.hunks.length === 1 ? '' : 's'}</small></span>
                        </label>
                        {change.hunks.map((hunk, hunkIndex) => (
                          <div className={`edit-hunk ${hunk.selected ? 'selected' : ''}`} key={hunk.id}>
                            <label className="edit-hunk-head">
                              <input
                                type="checkbox"
                                checked={hunk.selected}
                                onChange={() => setEditProposal((current) => current ? {
                                  ...current,
                                  changes: current.changes.map((item, itemIndex) => itemIndex === index
                                    ? { ...item, hunks: item.hunks.map((currentHunk, currentHunkIndex) => currentHunkIndex === hunkIndex ? { ...currentHunk, selected: !currentHunk.selected } : currentHunk) }
                                    : item),
                                } : current)}
                                data-testid={`checkbox-edit-hunk-${change.path.replace(/[/.]/g, '-')}-${hunkIndex}`}
                              />
                              <span>Lines {hunk.originalStart + 1}–{hunk.originalStart + Math.max(hunk.originalLines.length, 1)}</span>
                            </label>
                            <div className="edit-diff" aria-label={`Proposed hunk ${hunkIndex + 1} for ${change.path}`}>
                              {hunk.lines.map((line, lineIndex) => (
                                <code className={`edit-diff-line ${line.kind}`} key={`${line.kind}-${lineIndex}-${line.text}`}>
                                  <span>{line.kind === 'added' ? '+' : line.kind === 'removed' ? '−' : ' '}</span>{line.text || ' '}
                                </code>
                              ))}
                            </div>
                          </div>
                        ))}
                      </article>
                    ))}
                  </div>
                  <button className="edit-apply-button" onClick={() => applyEditProposal()} data-testid="button-apply-edit-proposal">
                    Apply selected changes
                  </button>
                </section>
              )}
              {visibleMessages.length === 0 ? (
                <div className="py-10 text-center text-[11px] text-[#8b877e]" data-testid="state-chat-empty">No messages yet. Ask about the current file.</div>
              ) : visibleMessages.map((message) => (
                <div className={`message ${message.role === 'model' ? 'model' : ''}`} key={message.id} data-testid={`message-${message.role}-${message.id}`}>
                  <div className="message-label">{message.role === 'model' ? (message.agentLabel ?? 'Local model') : 'You'}</div>
                  <p>{message.text}</p>
                </div>
              ))}
              {visibleIsModelThinking && <div className="message model" data-testid="state-model-loading"><div className="message-label">{selectedAiProvider === 'local' ? 'Local model' : 'Cloud model'}</div><div className="flex gap-1 py-1"><span className="h-1.5 w-1.5 animate-pulse rounded-full bg-[#e9a52b]" /><span className="h-1.5 w-1.5 animate-pulse rounded-full bg-[#e9a52b] [animation-delay:150ms]" /><span className="h-1.5 w-1.5 animate-pulse rounded-full bg-[#e9a52b] [animation-delay:300ms]" /></div></div>}
            </div>
            <div className="chat-composer">
              <textarea className="chat-input" value={visibleChatDraft} onChange={(event) => setChatDraft(event.target.value)} onKeyDown={(event) => { if (event.key === 'Enter' && !event.shiftKey) { event.preventDefault(); submitChat(); } }} placeholder={assistantMode === 'edit' ? 'Describe the change you want to review…' : 'Ask about this workspace…'} aria-label={assistantMode === 'edit' ? 'Describe an edit for the selected coding model' : 'Ask the selected coding model'} data-testid="input-chat-message" />
              <div className="composer-actions">
                <span className="composer-hint">{assistantMode === 'edit' ? 'Creates a proposal · Enter to review' : 'Enter to send · Shift + Enter'}</span>
                <button className="send-button" onClick={submitChat} disabled={!visibleChatDraft.trim() || visibleIsModelThinking || !isActiveModelAvailable} data-testid="button-send-chat"><Send size={12} /> {assistantMode === 'edit' ? 'Propose' : 'Send'}</button>
              </div>
            </div>
            <div className={`unlock-card ${isUnlocked ? 'unlocked' : ''}`} data-testid="card-ad-unlock">
              <div className="flex items-center gap-2 text-[11px] font-extrabold text-[#4d4e5a]">{isUnlocked ? <Check size={14} className="text-[#347a63]" /> : <LockKeyhole size={13} className="text-[#9b6511]" />} {isUnlocked ? 'Session unlocked' : 'Keep this session open'}</div>
              <p className="unlock-copy">{isUnlocked ? 'The workspace is unlocked for this session. You can keep building without another interruption.' : 'Watch a short sponsor message to unlock uninterrupted local model help for this session.'}</p>
              <button className="unlock-button" onClick={() => setIsUnlocked((value) => !value)} data-testid="button-unlock-session">{isUnlocked ? 'Lock session' : 'Watch to unlock'} <ChevronRight size={13} /></button>
            </div>
          </aside>
        </main> : workspacePage === 'preview' ? (
          <PreviewPage
            activePage={previewPage}
            onPageChange={setPreviewPage}
            previewState={previewState}
            onRun={runWorkspace}
            activeFile={activeFile}
            currentContent={currentContent}
          />
        ) : (
          <PublishPage
            previewState={previewState}
            saveState={saveState}
            releaseState={releaseState}
            canPrepareRelease={saveState === 'saved' && previewState === 'ready' && !securityNeedsAttention}
            securityNeedsAttention={securityNeedsAttention}
            onPrepareRelease={prepareRelease}
            onBackToBuild={() => setWorkspacePage('build')}
            onReviewSecurity={() => navigateSidebarArea('security')}
          />
        )}
          </div>
        </div>
      </div>
    </div>
  );
}

function PreviewPage({
  activePage,
  onPageChange,
  previewState,
  onRun,
  activeFile,
  currentContent,
}: {
  activePage: PreviewPage;
  onPageChange: (page: PreviewPage) => void;
  previewState: PreviewState;
  onRun: () => void;
  activeFile: FilePath;
  currentContent: string;
}) {
  const previewCopy: Record<PreviewPage, { eyebrow: string; title: string; copy: string }> = {
    home: { eyebrow: 'Local preview', title: 'Make the next idea real.', copy: 'A small, focused surface for turning a thought into something you can share.' },
    dashboard: { eyebrow: 'Workspace dashboard', title: 'Everything in one place.', copy: 'Keep the important signals close while you shape the next version.' },
    settings: { eyebrow: 'Project settings', title: 'Tune the workspace.', copy: 'Local-first preferences stay close to the project and ready for the next build.' },
  };
  const page = previewCopy[activePage];

  return (
    <main className="workspace-page preview-page" data-testid="page-preview">
      <div className="page-toolbar">
        <div>
          <div className="eyebrow">Workspace / Preview</div>
          <h1>See the product take shape.</h1>
          <p>Switch between app pages without leaving your build loop.</p>
        </div>
        <button className="run-button inline-flex h-[34px] items-center gap-2" onClick={onRun} disabled={previewState === 'running'} data-testid="button-run-preview">
          <Play size={13} fill="currentColor" /> {previewState === 'ready' ? 'Refresh preview' : 'Run preview'}
        </button>
      </div>
      <div className="preview-workbench">
        <aside className="preview-page-list" aria-label="Preview pages">
          <div className="eyebrow px-2">Pages</div>
          {([
            ['home', 'Home', '/'],
            ['dashboard', 'Dashboard', '/dashboard'],
            ['settings', 'Settings', '/settings'],
          ] as const).map(([pageId, label, route]) => (
            <button className={`preview-page-item ${activePage === pageId ? 'active' : ''}`} key={pageId} onClick={() => onPageChange(pageId)} data-testid={`button-preview-page-${pageId}`}>
              <span>{label}</span><span className="font-mono text-[10px]">{route}</span>
            </button>
          ))}
          <div className="preview-source-note">
            <div className="eyebrow">Source</div>
            <div className="mt-2 truncate font-mono text-[11px] text-[#4d4e5a]">{activeFile}</div>
            <div className="mt-1 text-[10px] text-[#8a8579]">{currentContent.split('\n').length} lines in editor</div>
          </div>
        </aside>
        <section className="preview-browser" aria-label={`${page.title} preview`}>
          <div className="browser-chrome">
            <span className="browser-dot red" /><span className="browser-dot yellow" /><span className="browser-dot green" />
            <span className="browser-address">localhost:5173{activePage === 'home' ? '/' : `/${activePage}`}</span>
            <span className={`preview-state-label ${previewState === 'ready' ? 'ready' : ''}`}>{previewState === 'ready' ? 'Live' : 'Not running'}</span>
          </div>
          <div className="preview-viewport">
            <div className="preview-app-nav"><span className="preview-brand">LANA DEV</span><span className="preview-nav-link active">Workspace</span><span className="preview-nav-link">Docs</span><span className="preview-nav-link">Account</span></div>
            <div className="preview-app-content">
              <span className="preview-kicker">{page.eyebrow}</span>
              <h2>{page.title}</h2>
              <p>{page.copy}</p>
              <button className="preview-primary-action" onClick={onRun}>{previewState === 'ready' ? 'Preview is live' : 'Start local preview'} <ChevronRight size={14} /></button>
              <div className="preview-stat-row"><div><strong>04</strong><span>open notes</span></div><div><strong>12m</strong><span>focus time</span></div><div><strong>01</strong><span>local branch</span></div></div>
            </div>
          </div>
        </section>
      </div>
    </main>
  );
}

function PublishPage({
  previewState,
  saveState,
  releaseState,
  canPrepareRelease,
  securityNeedsAttention,
  onPrepareRelease,
  onBackToBuild,
  onReviewSecurity,
}: {
  previewState: PreviewState;
  saveState: 'saved' | 'saving' | 'error' | 'sign-in';
  releaseState: 'idle' | 'building' | 'ready';
  canPrepareRelease: boolean;
  securityNeedsAttention: boolean;
  onPrepareRelease: () => void;
  onBackToBuild: () => void;
  onReviewSecurity: () => void;
}) {
  const isReady = releaseState === 'ready' && !securityNeedsAttention;
  const releaseAction = securityNeedsAttention ? onReviewSecurity : onPrepareRelease;
  return (
    <main className="workspace-page publish-page" data-testid="page-publish">
      <div className="page-toolbar">
        <div>
          <div className="eyebrow">Workspace / Publish</div>
          <h1>{securityNeedsAttention ? 'Review before you share.' : 'Ship when it feels ready.'}</h1>
          <p>{securityNeedsAttention ? 'Resolve the security checks below before preparing a release.' : 'A calm release checklist for your local-first build.'}</p>
        </div>
        <button className="run-button inline-flex h-[34px] items-center gap-2" onClick={releaseAction} disabled={releaseState === 'building' || (!canPrepareRelease && !securityNeedsAttention)} title={securityNeedsAttention ? 'Open the security review' : canPrepareRelease ? 'Prepare release checklist' : 'Save changes and run the preview first'} data-testid={securityNeedsAttention ? 'button-review-security' : 'button-prepare-release'}>
          {securityNeedsAttention ? <ShieldCheck size={13} /> : <Rocket size={13} />} {releaseState === 'building' ? 'Preparing…' : securityNeedsAttention ? 'Review security' : isReady ? 'Checklist ready' : 'Prepare release'}
        </button>
      </div>
      {securityNeedsAttention && (
        <div className="publish-security-alert" role="alert" data-testid="alert-publish-security">
          <AlertTriangle size={16} />
          <div>
            <strong>Security review needs attention</strong>
            <p>Review the highlighted request, credential, preview, or save check before you publish.</p>
          </div>
          <button className="text-link-button" onClick={onReviewSecurity} data-testid="button-publish-security-review">Open review <ChevronRight size={13} /></button>
        </div>
      )}
      <div className="publish-grid">
        <section className="release-card release-summary">
          <div className="release-card-top"><span className={`release-icon ${isReady ? 'ready' : ''}`}><Rocket size={17} /></span><span className="font-mono text-[10px] text-[#8b877e]">LANA DEV / 1.0.0</span></div>
          <h2>{isReady ? 'Your release checklist is ready.' : securityNeedsAttention ? 'Security comes before sharing.' : 'Your workspace is almost ready.'}</h2>
          <p>{isReady ? 'The current save, preview, and security checks have passed. Review the notes below before sharing it.' : securityNeedsAttention ? 'The release is blocked until the Security area confirms what can leave the browser.' : 'Save changes and run the preview before preparing the release checklist.'}</p>
          <button className="text-link-button" onClick={onBackToBuild} data-testid="button-back-to-build">Back to Build <ChevronRight size={13} /></button>
        </section>
        <section className="release-card checklist-card">
          <div className="eyebrow">Release checklist</div>
          <div className="checklist">
            <div className="checklist-row"><span className={`checklist-mark ${saveState === 'saved' ? 'complete' : ''}`}>{saveState === 'saved' ? <Check size={13} /> : <span>1</span>}</span><span><strong>Workspace saved</strong><small>{saveState === 'saved' ? 'All changes are persisted.' : 'Sign in to persist changes.'}</small></span></div>
            <div className="checklist-row"><span className={`checklist-mark ${previewState === 'ready' ? 'complete' : ''}`}>{previewState === 'ready' ? <Check size={13} /> : <span>2</span>}</span><span><strong>Preview checked</strong><small>{previewState === 'ready' ? 'Local preview is live.' : 'Run the workspace before releasing.'}</small></span></div>
            <div className="checklist-row"><span className={`checklist-mark ${!securityNeedsAttention ? 'complete' : ''}`}>{!securityNeedsAttention ? <Check size={13} /> : <span>3</span>}</span><span><strong>Security review</strong><small>{securityNeedsAttention ? 'Open Security to resolve the highlighted checks.' : 'No security checks are blocking this release.'}</small></span></div>
            <div className="checklist-row"><span className={`checklist-mark ${isReady ? 'complete' : ''}`}>{isReady ? <Check size={13} /> : <span>4</span>}</span><span><strong>Release checklist</strong><small>{isReady ? 'Checks are current and ready for review.' : 'Prepare it after saving, previewing, and reviewing security.'}</small></span></div>
          </div>
        </section>
      </div>
    </main>
  );
}

function SecurityReviewPage({
  review,
  onBackToBuild,
  onNavigateWorkspace,
  onOpenIntegrations,
  onOpenRequestReview,
  onApproveRequestReview,
  onSignIn,
  onRetrySave,
}: {
  review: SecurityReview;
  onBackToBuild: () => void;
  onNavigateWorkspace: (page: WorkspacePage) => void;
  onOpenIntegrations: () => void;
  onOpenRequestReview: () => void;
  onApproveRequestReview: () => void;
  onSignIn: () => void;
  onRetrySave: () => void;
}) {
  const readyCount = review.checks.filter((check) => check.status === 'ready').length;
  const attentionCount = review.checks.filter((check) => check.status === 'attention').length;
  const checkingCount = review.checks.filter((check) => check.status === 'checking').length;
  const headline = review.securityReady ? 'Your workspace is guarded.' : 'Review before you share.';
  const statusLabel = review.securityReady
    ? `${readyCount} checks ready`
    : [
      `${readyCount} checks ready`,
      attentionCount ? `${attentionCount} needs attention` : null,
      checkingCount ? `${checkingCount} checking` : null,
    ].filter(Boolean).join(' · ');

  const actionForCheck = (check: SecurityReview['checks'][number]) => {
    if (check.id === 'requests' && check.status === 'attention') {
      return <button className="security-check-action" onClick={onApproveRequestReview} data-testid="button-security-approve-requests">Approve reviewed code <Check size={12} /></button>;
    }
    if (check.id === 'credentials' && check.status !== 'ready') {
      return <button className="security-check-action" onClick={onOpenIntegrations} data-testid="button-security-review-credentials">Open Integrations <ChevronRight size={12} /></button>;
    }
    if (check.id === 'preview' && check.status === 'attention') {
      return <button className="security-check-action" onClick={() => onNavigateWorkspace('preview')} data-testid="button-security-review-preview">Run preview <ChevronRight size={12} /></button>;
    }
    if (check.id === 'publish') {
      const saveIssue = review.issues.find((issue) => issue.id === 'save');
      if (saveIssue?.action === 'sign-in') {
        return <button className="security-check-action" onClick={onSignIn} data-testid="button-security-sign-in">Sign in to save <ChevronRight size={12} /></button>;
      }
      if (saveIssue) {
        return <button className="security-check-action" onClick={onRetrySave} data-testid="button-security-retry-save">Retry save <ChevronRight size={12} /></button>;
      }
      return <button className="security-check-action" onClick={() => onNavigateWorkspace('publish')} data-testid="button-security-review-publish">Open Publish <ChevronRight size={12} /></button>;
    }
    return null;
  };

  const statusIcon = (status: SecurityReview['checks'][number]['status']) => {
    if (status === 'ready') return <Check size={13} />;
    if (status === 'checking') return <CircleDot size={13} className="animate-pulse" />;
    return <AlertTriangle size={13} />;
  };

  return (
    <main className="workspace-area-page security-page" data-testid="page-sidebar-security">
      <div className="workspace-area-heading">
        <div className="eyebrow">Security</div>
        <div className={`workspace-area-status ${review.securityReady ? '' : 'attention'}`}><span className="sidebar-status-dot" /> {statusLabel}</div>
        <h1>Review what leaves your workspace.</h1>
        <p>See the browser request boundary, credential handling, preview state, and the checks that still stand between this build and a release.</p>
      </div>

      <div className="security-review-grid">
        <section className={`security-summary-card ${review.securityReady ? 'ready' : 'attention'}`}>
          <div className="security-summary-top">
            <span className="security-summary-icon">{review.securityReady ? <ShieldCheck size={19} /> : <AlertTriangle size={19} />}</span>
            <span className="font-mono text-[10px] text-[#aeb2c0]">LANA DEV / PREFLIGHT</span>
          </div>
          <h2>{headline}</h2>
          <p>{review.securityReady ? 'No security check is blocking the current release path. Keep the request boundary explicit as you build.' : 'A few checks need a deliberate action before this workspace is ready to publish.'}</p>
          <div className="security-rollup">
            {review.checks.map((check) => (
              <div key={check.id}><span>{check.label}</span><strong className={check.status}>{check.status === 'ready' ? 'Ready' : check.status === 'checking' ? 'Checking' : 'Review'}</strong></div>
            ))}
          </div>
          <button className="security-summary-action" onClick={review.issues.some((issue) => issue.id === 'requests') ? onApproveRequestReview : () => onNavigateWorkspace('publish')} data-testid="button-security-primary-action">
            {review.issues.some((issue) => issue.id === 'requests') ? 'Approve reviewed request code' : 'Open Publish'} <ChevronRight size={14} />
          </button>
          <button className="text-link-button" onClick={onBackToBuild} data-testid="button-security-back-to-build">Back to Build <ChevronRight size={13} /></button>
        </section>

        <section className="security-checks-card">
          <div className="eyebrow">Security checklist</div>
          <div className="security-check-list">
            {review.checks.map((check) => (
              <article className={`security-check-row ${check.status}`} key={check.id} data-testid={`security-check-${check.id}`}>
                <span className={`security-check-mark ${check.status}`}>{statusIcon(check.status)}</span>
                <div className="security-check-copy">
                  <div className="security-check-heading"><strong>{check.label}</strong><span>{check.summary}</span></div>
                  <p>{check.detail}</p>
                  {check.evidence.length > 0 && (
                    <ul className="security-evidence" aria-label={`${check.label} evidence`}>
                      {check.evidence.map((item) => <li key={item}>{item}</li>)}
                    </ul>
                  )}
                  {actionForCheck(check)}
                </div>
              </article>
            ))}
          </div>
        </section>
      </div>

      <section className="security-request-panel">
        <div className="security-request-icon"><LockKeyhole size={16} /></div>
        <div>
          <div className="eyebrow">Browser request policy</div>
          <h2>Nothing leaves without a review.</h2>
          <p>API Tester shows the resolved destination, method, headers, and body before sending. Browser credentials are omitted by default; sensitive headers are marked without displaying their values.</p>
        </div>
        <button className="text-link-button" onClick={onOpenRequestReview} data-testid="button-security-open-api-tester">Open API Tester <ExternalLink size={13} /></button>
      </section>
    </main>
  );
}

type TemplateCategory = 'All' | 'SaaS' | 'Dashboards' | 'Marketing' | 'Tools' | 'Ecommerce' | 'Social';

interface Template {
  id: string;
  title: string;
  description: string;
  category: TemplateCategory;
  tags: string[];
}

const TEMPLATES: Template[] = [
  { id: 'saas-starter', title: 'SaaS Starter', description: 'A product foundation with an account area, billing-ready copy, and an empty dashboard.', category: 'SaaS', tags: ['Auth', 'Billing', 'Dashboard'] },
  { id: 'ai-copilot', title: 'AI Copilot', description: 'A focused assistant workspace with prompt history, task context, and response states.', category: 'SaaS', tags: ['AI', 'Prompts', 'History'] },
  { id: 'customer-portal', title: 'Customer Portal', description: 'A signed-in home for account details, invoices, support, and saved preferences.', category: 'SaaS', tags: ['Accounts', 'Support', 'Settings'] },
  { id: 'admin-dashboard', title: 'Admin Dashboard', description: 'Data-heavy tables, team controls, and operational metrics for an internal product.', category: 'Dashboards', tags: ['Tables', 'Charts', 'Analytics'] },
  { id: 'metrics-tracker', title: 'Metrics Tracker', description: 'KPI cards, trend reports, and export-ready views for a growing business.', category: 'Dashboards', tags: ['KPI', 'Trends', 'Export'] },
  { id: 'ops-console', title: 'Operations Console', description: 'A high-signal workspace for queues, exceptions, alerts, and daily decisions.', category: 'Dashboards', tags: ['Operations', 'Alerts', 'Queues'] },
  { id: 'launch-page', title: 'Launch Page', description: 'A clear product story with a waitlist, proof points, and conversion-ready calls to action.', category: 'Marketing', tags: ['Waitlist', 'Hero', 'Conversion'] },
  { id: 'portfolio-showcase', title: 'Portfolio Showcase', description: 'A polished project gallery for a creator, studio, or independent consultant.', category: 'Marketing', tags: ['Gallery', 'About', 'Contact'] },
  { id: 'documentation-hub', title: 'Documentation Hub', description: 'A searchable knowledge base layout for onboarding, guides, and API references.', category: 'Marketing', tags: ['Docs', 'Search', 'Guides'] },
  { id: 'internal-tool', title: 'Internal Tool', description: 'A form-first interface for managing records, approvals, and settings.', category: 'Tools', tags: ['Forms', 'Validation', 'Records'] },
  { id: 'api-playground', title: 'API Playground', description: 'An interactive client for composing requests, inspecting responses, and saving examples.', category: 'Tools', tags: ['API', 'Requests', 'JSON'] },
  { id: 'form-builder', title: 'Form Builder', description: 'A configurable submission flow with field previews, validation, and response handling.', category: 'Tools', tags: ['Forms', 'Builder', 'Validation'] },
  { id: 'storefront', title: 'Storefront', description: 'A product-led shop with collection browsing, a cart, and a checkout-ready flow.', category: 'Ecommerce', tags: ['Cart', 'Products', 'Checkout'] },
  { id: 'booking-studio', title: 'Booking Studio', description: 'A service booking flow for availability, appointment details, and confirmations.', category: 'Ecommerce', tags: ['Bookings', 'Calendar', 'Payments'] },
  { id: 'marketplace', title: 'Marketplace', description: 'A catalog and discovery experience for listings, saved items, and seller profiles.', category: 'Ecommerce', tags: ['Listings', 'Search', 'Profiles'] },
  { id: 'social-feed', title: 'Social Feed', description: 'A lively community feed with posts, profile snapshots, and engagement controls.', category: 'Social', tags: ['Feed', 'Profiles', 'Interactions'] },
  { id: 'community-space', title: 'Community Space', description: 'A discussion home for members, topics, events, and resource sharing.', category: 'Social', tags: ['Community', 'Topics', 'Events'] },
  { id: 'link-page', title: 'Creator Link Page', description: 'A compact public profile that brings social links, work, and newsletter sign-up together.', category: 'Social', tags: ['Creator', 'Links', 'Newsletter'] },
];

const TEMPLATE_CATEGORIES: TemplateCategory[] = ['All', 'SaaS', 'Dashboards', 'Marketing', 'Tools', 'Ecommerce', 'Social'];

function createTemplateFiles(template: Template): Record<FilePath, string> {
  const tags = template.tags.map((tag) => `'${tag}'`).join(', ');

  return {
    ...defaultFileContents,
    'src/App.tsx': `import './index.css';

const project = {
  name: '${template.title}',
  category: '${template.category}',
  tags: [${tags}],
};

export default function App() {
  return (
    <main className="template-app">
      <nav className="template-nav">
        <span>{project.name}</span>
        <button>Get started</button>
      </nav>
      <section className="template-hero">
        <p>{project.category} starter</p>
        <h1>Make this starter your own.</h1>
        <span>${template.description}</span>
        <div className="template-tags">
          {project.tags.map((tag) => <small key={tag}>{tag}</small>)}
        </div>
      </section>
    </main>
  );
}`,
    'src/index.css': `:root {
  color: #24283c;
  background: #f3f0e9;
  font-family: Inter, system-ui, sans-serif;
}

* { box-sizing: border-box; }
body { margin: 0; }
button { font: inherit; cursor: pointer; }

.template-app { min-height: 100dvh; padding: 24px; background: #f3f0e9; }
.template-nav { display: flex; align-items: center; justify-content: space-between; max-width: 980px; margin: 0 auto; font-weight: 800; }
.template-nav button { padding: 10px 14px; border: 0; border-radius: 6px; color: #fff8e8; background: #24283c; }
.template-hero { max-width: 760px; margin: 18vh auto 0; }
.template-hero p { color: #9b6511; font: 700 12px/1.4 ui-monospace, monospace; letter-spacing: .08em; text-transform: uppercase; }
.template-hero h1 { max-width: 620px; margin: 12px 0; font-size: clamp(48px, 8vw, 90px); line-height: .92; letter-spacing: -.07em; }
.template-hero > span { display: block; max-width: 540px; color: #777267; font-size: 18px; line-height: 1.6; }
.template-tags { display: flex; flex-wrap: wrap; gap: 8px; margin-top: 28px; }
.template-tags small { padding: 7px 10px; border: 1px solid #ded8cc; border-radius: 99px; background: #faf8f2; }`,
    'README.md': `# ${template.title}

${template.description}

## Starter focus

- Category: ${template.category}
- Building blocks: ${template.tags.join(', ')}

Open \`src/App.tsx\` to begin tailoring this LANA DEV starter.`,
  };
}

function TemplatesCatalog({ onUseTemplate }: { onUseTemplate: (template: Template) => void }) {
  const [searchQuery, setSearchQuery] = useState('');
  const [activeCategory, setActiveCategory] = useState<TemplateCategory>('All');

  const filteredTemplates = useMemo(() => {
    return TEMPLATES.filter((template) => {
      const matchesCategory = activeCategory === 'All' || template.category === activeCategory;
      const matchesSearch =
        template.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        template.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
        template.tags.some(tag => tag.toLowerCase().includes(searchQuery.toLowerCase()));
      return matchesCategory && matchesSearch;
    });
  }, [searchQuery, activeCategory]);

  return (
    <div className="templates-catalog">
      <div className="templates-catalog-summary">
        <span>{filteredTemplates.length} of {TEMPLATES.length} starters</span>
        <p>Choose a foundation, then tailor the source files in your workspace.</p>
      </div>
      <div className="templates-toolbar">
        <div className="templates-search">
          <Search size={15} className="templates-search-icon" />
          <input
            type="text"
            className="templates-search-input"
            placeholder="Search templates..."
            aria-label="Search templates"
            data-testid="input-template-search"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
        <div className="templates-filters">
          {TEMPLATE_CATEGORIES.map((cat) => (
             <button
              key={cat}
              className={`templates-filter-btn ${activeCategory === cat ? 'active' : ''}`}
              onClick={() => setActiveCategory(cat)}
                aria-pressed={activeCategory === cat}
                data-testid={`button-template-category-${cat.toLowerCase()}`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {filteredTemplates.length > 0 ? (
        <div className="templates-grid">
          {filteredTemplates.map((template) => (
            <div className="template-card" key={template.id}>
              <div className="template-card-header">
                <h3 className="template-card-title">{template.title}</h3>
                <span className="template-card-category">{template.category}</span>
              </div>
              <p className="template-card-description">{template.description}</p>
              <div className="template-card-tags">
                {template.tags.map((tag) => (
                  <span className="template-card-tag" key={tag}>{tag}</span>
                ))}
              </div>
              <button
                className="template-card-action"
                onClick={() => onUseTemplate(template)}
                data-testid={`button-use-template-${template.id}`}
              >
                Use Template
              </button>
            </div>
          ))}
        </div>
      ) : (
        <div className="templates-empty">
          <PackageSearch size={32} className="templates-empty-icon" />
          <h3 className="templates-empty-title">No templates found</h3>
          <p className="templates-empty-desc">We couldn't find any templates matching "{searchQuery}". Try changing your filters.</p>
        </div>
      )}
    </div>
  );
}

function WorkspaceAreaPage({
  area,
  onBackToBuild,
  onApplyTemplate,
  isSignedIn,
  selectedAiProvider,
  onSelectAiProvider,
  securityReview,
  onNavigateWorkspace,
  onOpenIntegrations,
  onOpenRequestReview,
  onApproveRequestReview,
  onRetrySave,
}: {
  area: WorkspaceArea;
  onBackToBuild: () => void;
  onApplyTemplate: (template: Template) => void;
  isSignedIn: boolean;
  selectedAiProvider: AiProvider | 'local';
  onSelectAiProvider: (provider: AiProvider | 'local') => void;
  securityReview: SecurityReview;
  onNavigateWorkspace: (page: WorkspacePage) => void;
  onOpenIntegrations: () => void;
  onOpenRequestReview: () => void;
  onApproveRequestReview: () => void;
  onRetrySave: () => void;
}) {
  const areaContent: Record<WorkspaceArea, {
    eyebrow: string;
    title: string;
    description: string;
    detail: string;
    items: string[];
  }> = {
    templates: {
      eyebrow: 'Templates',
      title: 'Start with a strong first shape.',
      description: 'Keep reusable starting points close to the projects they help create.',
      detail: 'Templates will give idea-first builders a faster way to begin without taking control away from the code.',
      items: ['Reusable project foundations', 'Frontend-first starting points', 'Local files you can customize'],
    },
    routines: {
      eyebrow: 'Project routines',
      title: 'Make the build loop repeatable.',
      description: 'Collect the steps you use again and again while shaping a project.',
      detail: 'Routines will connect the AI Factory, preview checks, and release habits into a consistent workflow.',
      items: ['Saved build sequences', 'Preview and release checks', 'Team-ready working habits'],
    },
    library: {
      eyebrow: 'Library',
      title: 'Keep your best project pieces nearby.',
      description: 'A home for saved components, snippets, and local assets you want to reuse.',
      detail: 'The library will make useful work portable across projects while keeping the source visible and editable.',
      items: ['Saved components and snippets', 'Reusable local assets', 'Searchable project knowledge'],
    },
    integrations: {
      eyebrow: 'Integrations',
      title: 'Connect the tools your project needs.',
      description: 'Keep external services discoverable without losing the local-first build loop.',
      detail: 'Cloud AI providers such as xAI/Grok can be connected deliberately, with clear permissions and no hidden cloud fallback for local AI.',
      items: ['Explicit service connections', 'Visible permission boundaries', 'Local-first defaults'],
    },
    security: {
      eyebrow: 'Security',
      title: 'Know what leaves the workspace.',
      description: 'Review the guardrails around code, requests, credentials, and release readiness.',
      detail: 'This area will collect the checks that help you understand and control your project’s security posture.',
      items: ['Request and credential boundaries', 'Release readiness checks', 'Clear local model behavior'],
    },
  };
  const content = areaContent[area];

  if (area === 'integrations') {
    return (
      <main className="workspace-area-page ai-integrations-page" data-testid="page-sidebar-integrations">
        <div className="workspace-area-heading">
          <div className="eyebrow">{content.eyebrow}</div>
          <div className="workspace-area-status"><span className="sidebar-status-dot" /> AI request controls</div>
          <h1>{content.title}</h1>
          <p>{content.description}</p>
          <button className="text-link-button" onClick={onBackToBuild} data-testid="button-area-back-to-build">Back to Build <ChevronRight size={13} /></button>
        </div>
        <AiConnectorPanel isSignedIn={isSignedIn} selectedProvider={selectedAiProvider} onSelectProvider={onSelectAiProvider} />
      </main>
    );
  }

  if (area === 'templates') {
    return (
      <main className="workspace-area-page" data-testid={`page-sidebar-${area}`}>
        <div className="workspace-area-heading">
          <div className="eyebrow">{content.eyebrow}</div>
          <div className="workspace-area-status"><span className="sidebar-status-dot" /> Workspace area</div>
          <h1>{content.title}</h1>
          <p>{content.description}</p>
        </div>
        <TemplatesCatalog onUseTemplate={onApplyTemplate} />
      </main>
    );
  }

  if (area === 'security') {
    return (
      <SecurityReviewPage
        review={securityReview}
        onBackToBuild={onBackToBuild}
        onNavigateWorkspace={onNavigateWorkspace}
        onOpenIntegrations={onOpenIntegrations}
        onOpenRequestReview={onOpenRequestReview}
        onApproveRequestReview={onApproveRequestReview}
        onRetrySave={onRetrySave}
        onSignIn={() => {
          window.location.href = `${basePath}/sign-in`;
        }}
      />
    );
  }

  return (
    <main className="workspace-area-page" data-testid={`page-sidebar-${area}`}>
      <div className="workspace-area-heading">
        <div className="eyebrow">{content.eyebrow}</div>
        <div className="workspace-area-status"><span className="sidebar-status-dot" /> Workspace area</div>
        <h1>{content.title}</h1>
        <p>{content.description}</p>
      </div>
      <div className="workspace-area-grid">
        <section className="workspace-area-card workspace-area-card-primary">
          <div className="eyebrow">LANA DEV / {content.eyebrow}</div>
          <h2>Designed for the next build.</h2>
          <p>{content.detail}</p>
          <button className="text-link-button" onClick={onBackToBuild} data-testid="button-area-back-to-build">
            Back to Build <ChevronRight size={13} />
          </button>
        </section>
        <section className="workspace-area-card">
          <div className="eyebrow">What belongs here</div>
          <div className="workspace-area-list">
            {content.items.map((item) => (
              <div className="workspace-area-list-item" key={item}>
                <Check size={14} />
                <span>{item}</span>
              </div>
            ))}
          </div>
        </section>
      </div>
    </main>
  );
}

function Router() {
  return (
    <RoutedErrorBoundary>
      <Switch>
        <Route path="/" component={Home} />
        <Route path="/sign-in/*?" component={SignInPage} />
        <Route path="/sign-up/*?" component={SignUpPage} />
        <Route component={NotFound} />
      </Switch>
    </RoutedErrorBoundary>
  );
}

function SignInPage() {
  return (
    <div className="auth-page">
      <SignIn routing="path" path={`${basePath}/sign-in`} signUpUrl={`${basePath}/sign-up`} />
    </div>
  );
}

function SignUpPage() {
  return (
    <div className="auth-page">
      <SignUp routing="path" path={`${basePath}/sign-up`} signInUrl={`${basePath}/sign-in`} />
    </div>
  );
}

function RoutedErrorBoundary({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>;
}

function App() {
  return (
    <ClerkProvider
      publishableKey={clerkPubKey}
      proxyUrl={clerkProxyUrl}
      appearance={clerkAppearance}
      signInUrl={`${basePath}/sign-in`}
      signUpUrl={`${basePath}/sign-up`}
    >
      <QueryClientProvider client={queryClient}>
        <TooltipProvider>
          <WouterRouter base={basePath}>
            <Router />
          </WouterRouter>
          <Toaster />
        </TooltipProvider>
      </QueryClientProvider>
    </ClerkProvider>
  );
}

export default App;

# LANA DEV Platform Architecture

This is the top-level structure for LANA DEV. The current product already has
the Software IDE, AI Copilot, project tree, local model paths, preview, publish,
templates, routines, library, and browser-safe tool foundations. The remaining
areas should extend these shared foundations instead of creating parallel
project systems.

```text
YOUR_APP_PLATFORM/
├── SOFTWARE_IDE/
│   ├── Code_Editor_Core/
│   │   ├── Syntax_Highlighter
│   │   ├── Multi_Language_Parser
│   │   └── LSP_Engine
│   ├── AI_Copilot/
│   │   ├── Code_Generation
│   │   ├── Debugging_Agent
│   │   └── Refactor_Agent
│   └── Execution_Sandbox/
│       ├── WASM_VM
│       ├── Safe_Runtime_Validator
│       └── Resource_Limiter
│
├── APP_WEB_BUILDER/
│   ├── Vibe_UI_Builder/
│   │   ├── Drag_Drop_Components
│   │   ├── Style_Engine
│   │   └── Responsive_Layout_System
│   ├── Pro_Logic_Editor/
│   │   ├── Visual_Flow_Editor
│   │   ├── Event_Triggers
│   │   └── Data_Bindings
│   └── App_Sandbox/
│       ├── Browser_WASM_Runtime
│       └── Permission_Guard
│
├── ROBOTICS_IDE/
│   ├── Simulation_Engine/
│   │   ├── WebGPU_Physics
│   │   ├── Sensor_Simulators
│   │   └── Environment_Builder
│   ├── Hardware_Tools/
│   │   ├── WebSerial_Flasher
│   │   ├── WebUSB_Programmer
│   │   └── MicroPython_REPL
│   ├── Telemetry_Tools/
│   │   ├── ROS2_Zenoh_Bridge
│   │   ├── Topic_Inspector
│   │   └── MCAP_Player
│   └── AI_Robotics_Agents/
│       ├── Kinematics_Planner
│       ├── PID_Tuning_Agent
│       └── Crash_Log_Fixer
│
├── SHARED_AI_ENGINE/
│   ├── Llama_Runtime
│   ├── Prompt_Router
│   └── Multi_Agent_Orchestrator
│
├── SHARED_SANDBOX/
│   ├── WASM_VM
│   ├── Python_WASM
│   └── C++_WASM
│
└── SHARED_PROJECT_TREE/
    ├── File_System
    ├── Git_Integration
    └── Cloud_Sync
```

## Build boundaries

- **Software IDE** and **App Web Builder** share the project tree, Copilot
  context, reviewable edits, preview, security review, and publish flow.
- **Robotics IDE** is the third feature and starts with simulation-only URDF,
  kinematics, scene rendering, and deterministic runtime status.
- **Shared AI Engine** owns model selection, prompt routing, and worker
  orchestration; feature areas provide domain-specific context and tools.
- **Shared Sandbox** owns browser execution boundaries and resource limits.
  WebGPU is an acceleration path, never the only runtime path.
- **Shared Project Tree** remains the single source of truth for files,
  persistence, templates, routines, library items, and future Git/cloud sync.
- Hardware tools, ROS2 transport, and real-device commands require separate
  safety validation before they can move beyond clearly labelled future
  modules.
import { Router, type IRouter, type Request } from "express";
import { getAuth } from "@clerk/express";
import { eq } from "drizzle-orm";
import { db, projectsTable } from "@workspace/db";
import {
  GetProjectResponse,
  SaveProjectBody,
  SaveProjectResponse,
} from "@workspace/api-zod";

const router: IRouter = Router();

function getUserId(req: Request): string | null {
  const auth = getAuth(req);
  return auth?.userId ?? null;
}

router.get("/project", async (req, res): Promise<void> => {
  const userId = getUserId(req);
  if (!userId) {
    res.status(401).json({ error: "Authentication required" });
    return;
  }

  const [project] = await db
    .select()
    .from(projectsTable)
    .where(eq(projectsTable.userId, userId));

  if (!project) {
    res.status(404).json({ error: "Project not found" });
    return;
  }

  res.json(
    GetProjectResponse.parse({
      id: project.userId,
      name: project.name,
      files: project.files,
      updatedAt: project.updatedAt,
    }),
  );
});

router.put("/project", async (req, res): Promise<void> => {
  const userId = getUserId(req);
  if (!userId) {
    res.status(401).json({ error: "Authentication required" });
    return;
  }

  const parsed = SaveProjectBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const [project] = await db
    .insert(projectsTable)
    .values({
      userId,
      name: parsed.data.name,
      files: parsed.data.files,
    })
    .onConflictDoUpdate({
      target: projectsTable.userId,
      set: {
        name: parsed.data.name,
        files: parsed.data.files,
        updatedAt: new Date(),
      },
    })
    .returning();

  res.json(
    SaveProjectResponse.parse({
      id: project.userId,
      name: project.name,
      files: project.files,
      updatedAt: project.updatedAt,
    }),
  );
});

export default router;
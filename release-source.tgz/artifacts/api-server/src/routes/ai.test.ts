import assert from "node:assert/strict";
import { createServer } from "node:http";
import express from "express";
import test, { mock } from "node:test";
import { decryptCredential } from "../lib/aiCredentials";

process.env.SESSION_SECRET ??= "ai-route-test-session-secret";

type Connection = {
  userId: string;
  provider: string;
  encryptedApiKey: string;
  keyHint: string;
  state: string;
  lastTestedAt: Date | null;
  error: string | null;
  updatedAt: Date;
};

const connections: Connection[] = [];
const aiConnectionsTable = {
  userId: "userId",
  provider: "provider",
  encryptedApiKey: "encryptedApiKey",
};

const db = {
  select() {
    return {
      from() {
        return {
          where: async () => connections.map((connection) => ({ ...connection })),
        };
      },
    };
  },
  insert() {
    return {
      values(values: Connection) {
        return {
          onConflictDoUpdate({ set }: { set: Partial<Connection> }) {
            return {
              returning: async () => {
                const existingIndex = connections.findIndex(
                  (connection) => connection.userId === values.userId && connection.provider === values.provider,
                );
                const saved = {
                  ...values,
                  ...set,
                  updatedAt: set.updatedAt ?? new Date(),
                };
                if (existingIndex === -1) connections.push(saved);
                else connections[existingIndex] = saved;
                return [{ ...saved }];
              },
            };
          },
        };
      },
    };
  },
  update() {
    return {
      set(values: Partial<Connection>) {
        return {
          where: async () => {
            for (const connection of connections) Object.assign(connection, values);
          },
        };
      },
    };
  },
  delete() {
    return {
      where: async () => {
        connections.splice(0, connections.length);
      },
    };
  },
};

mock.module("@workspace/db", {
  namedExports: { db, aiConnectionsTable },
});
mock.module("@clerk/express", {
  namedExports: {
    getAuth: () => ({ userId: "ai-route-test-user" }),
  },
});

const { default: aiRouter } = await import("./ai.ts");
const app = express();
app.use(express.json());
app.use(aiRouter);
const server = createServer(app);
server.listen(0, "127.0.0.1");
await new Promise<void>((resolve) => server.once("listening", () => resolve()));
const address = server.address();
assert.ok(address && typeof address === "object");
const baseUrl = `http://127.0.0.1:${address.port}`;
const realFetch = globalThis.fetch.bind(globalThis);

async function request(path: string, init: RequestInit = {}) {
  const response = await realFetch(`${baseUrl}${path}`, init);
  const text = await response.text();
  return {
    response,
    body: text ? JSON.parse(text) as Record<string, unknown> | Array<unknown> : null,
  };
}

test.after(() => server.close());
test.beforeEach(() => {
  connections.splice(0, connections.length);
});

test("stores credentials encrypted and returns only a redacted hint after a successful provider test", async (t) => {
  const apiKey = "sk-test-success-7890";
  const providerFetch = t.mock.method(globalThis, "fetch", async (input, init) => {
    assert.equal(String(input), "https://api.openai.com/v1/models");
    assert.equal(new Headers(init?.headers).get("authorization"), `Bearer ${apiKey}`);
    return new Response("{}", { status: 200 });
  });

  const saved = await request("/ai/connections/openai", {
    method: "PUT",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ apiKey }),
  });
  assert.equal(saved.response.status, 200);
  assert.deepEqual(saved.body, {
    provider: "openai",
    label: "OpenAI",
    connected: true,
    state: "connected",
    keyHint: "••••7890",
    lastTestedAt: null,
    error: null,
  });
  assert.notEqual(connections[0]?.encryptedApiKey, apiKey);
  assert.equal(decryptCredential(connections[0]?.encryptedApiKey ?? ""), apiKey);

  const listed = await request("/ai/connections");
  assert.equal(listed.response.status, 200);
  assert.equal((listed.body as Array<Record<string, unknown>>)[0]?.keyHint, "••••7890");
  assert.doesNotMatch(JSON.stringify(listed.body), new RegExp(apiKey));

  const tested = await request("/ai/connections/openai/test", { method: "POST" });
  assert.equal(tested.response.status, 200);
  assert.equal((tested.body as Record<string, unknown>).success, true);
  assert.match(String((tested.body as Record<string, unknown>).message), /working/);
  assert.equal(connections[0]?.state, "connected");
  assert.equal(providerFetch.mock.calls.length, 1);
});

test("records an invalid-key failure without exposing the provider error body or allowing chat", async (t) => {
  const apiKey = "sk-test-invalid-4567";
  const providerErrorBody = "provider-secret-error-body";
  const providerFetch = t.mock.method(globalThis, "fetch", async () => new Response(
    JSON.stringify({ error: providerErrorBody }),
    { status: 401, headers: { "content-type": "application/json" } },
  ));

  await request("/ai/connections/openai", {
    method: "PUT",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ apiKey }),
  });
  const tested = await request("/ai/connections/openai/test", { method: "POST" });
  assert.equal(tested.response.status, 200);
  assert.equal((tested.body as Record<string, unknown>).success, false);
  assert.match(String((tested.body as Record<string, unknown>).message), /rejected this API key/);
  assert.doesNotMatch(JSON.stringify(tested.body), new RegExp(providerErrorBody));

  const listed = await request("/ai/connections");
  assert.equal((listed.body as Array<Record<string, unknown>>)[0]?.state, "error");
  assert.equal((listed.body as Array<Record<string, unknown>>)[0]?.keyHint, "••••4567");
  assert.doesNotMatch(JSON.stringify(listed.body), new RegExp(apiKey));
  assert.doesNotMatch(JSON.stringify(listed.body), new RegExp(providerErrorBody));

  const chat = await request("/ai/chat", {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({
      provider: "openai",
      messages: [{ role: "user", content: "Do not send this to the provider." }],
    }),
  });
  assert.equal(chat.response.status, 409);
  assert.match(String((chat.body as Record<string, unknown>).error), /Test or replace OpenAI/);
  assert.equal(providerFetch.mock.calls.length, 1, "chat must not contact a connection that failed its test");
});

test("removes a stored connection and clears its ability to send chat", async () => {
  await request("/ai/connections/openai", {
    method: "PUT",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ apiKey: "sk-test-remove-1234" }),
  });

  const removed = await request("/ai/connections/openai", { method: "DELETE" });
  assert.equal(removed.response.status, 204);
  assert.equal(connections.length, 0);

  const listed = await request("/ai/connections");
  const openAi = (listed.body as Array<Record<string, unknown>>).find(
    (connection) => connection.provider === "openai",
  );
  assert.deepEqual(openAi, {
    provider: "openai",
    label: "OpenAI",
    connected: false,
    state: "not_configured",
    keyHint: null,
    lastTestedAt: null,
    error: null,
  });

  const chat = await request("/ai/chat", {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({
      provider: "openai",
      messages: [{ role: "user", content: "There is no connection." }],
    }),
  });
  assert.equal(chat.response.status, 404);
  assert.match(String((chat.body as Record<string, unknown>).error), /Connect OpenAI/);
});
import { Router, type IRouter } from "express";
import healthRouter from "./health";
import projectRouter from "./project";
import resourcesRouter from "./resources";
import aiRouter from "./ai";

const router: IRouter = Router();

router.use(healthRouter);
router.use(projectRouter);
router.use(resourcesRouter);
router.use(aiRouter);

export default router;

import { Router, type IRouter, type Request } from "express";
import { getAuth } from "@clerk/express";
import { and, eq, sql } from "drizzle-orm";
import { db, projectsTable } from "@workspace/db";
import {
  GetProjectResourcesResponse,
  SaveProjectResourcesBody,
} from "@workspace/api-zod";

const router: IRouter = Router();
const emptyResources = { revision: 0, templates: [], routines: [], library: [] };

function getUserId(req: Request): string | null {
  const auth = getAuth(req);
  return auth?.userId ?? null;
}

function normalizeResources(value: unknown) {
  const candidate = value && typeof value === "object"
    ? (value as Record<string, unknown>)
    : {};
  return GetProjectResourcesResponse.parse({
    revision: Number.isInteger(candidate.revision) && Number(candidate.revision) >= 0
      ? candidate.revision
      : 0,
    templates: Array.isArray(candidate.templates) ? candidate.templates : [],
    routines: Array.isArray(candidate.routines) ? candidate.routines : [],
    library: Array.isArray(candidate.library) ? candidate.library : [],
  });
}

router.get("/project/resources", async (req, res): Promise<void> => {
  const userId = getUserId(req);
  if (!userId) {
    res.status(401).json({ error: "Authentication required" });
    return;
  }

  const [project] = await db
    .select({ resources: projectsTable.resources })
    .from(projectsTable)
    .where(eq(projectsTable.userId, userId));

  const resources = normalizeResources(project?.resources ?? emptyResources);
  res.json(GetProjectResourcesResponse.parse(resources));
});

router.put("/project/resources", async (req, res): Promise<void> => {
  const userId = getUserId(req);
  if (!userId) {
    res.status(401).json({ error: "Authentication required" });
    return;
  }

  const parsed = SaveProjectResourcesBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  if (!Number.isInteger(parsed.data.expectedRevision)) {
    res.status(400).json({ error: "expectedRevision must be an integer" });
    return;
  }

  const [existingProject] = await db
    .select({ name: projectsTable.name, files: projectsTable.files, resources: projectsTable.resources })
    .from(projectsTable)
    .where(eq(projectsTable.userId, userId));

  const currentResources = normalizeResources(existingProject?.resources ?? emptyResources);
  if (parsed.data.expectedRevision !== currentResources.revision) {
    res.status(409).json({
      error: "These resources changed in another workspace. Reload and try again.",
      resources: currentResources,
    });
    return;
  }

  const resources = {
    ...currentResources,
    [parsed.data.category]: parsed.data.resources[parsed.data.category],
    revision: currentResources.revision + 1,
  };

  await db
    .insert(projectsTable)
    .values({
      userId,
      name: existingProject?.name ?? "lana-dev",
      files: existingProject?.files ?? [],
      resources: currentResources,
    })
    .onConflictDoNothing();

  const [project] = await db
    .update(projectsTable)
    .set({ resources, updatedAt: new Date() })
    .where(
      and(
        eq(projectsTable.userId, userId),
        sql`coalesce((${projectsTable.resources}->>'revision')::integer, 0) = ${parsed.data.expectedRevision}`,
      ),
    )
    .returning({ resources: projectsTable.resources });

  if (!project) {
    res.status(409).json({
      error: "These resources changed in another workspace. Reload and try again.",
    });
    return;
  }

  res.json(normalizeResources(project.resources));
});

export default router;
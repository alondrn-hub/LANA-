import { Router, type IRouter, type Request } from "express";
import { getAuth } from "@clerk/express";
import { and, eq } from "drizzle-orm";
import { db, aiConnectionsTable } from "@workspace/db";
import {
  ListAiConnectionsResponse,
  SaveAiConnectionBody,
  SaveAiConnectionParams,
  SaveAiConnectionResponse,
  RemoveAiConnectionParams,
  TestAiConnectionParams,
  TestAiConnectionResponse,
  SendAiChatBody,
  SendAiChatResponse,
} from "@workspace/api-zod";
import {
  credentialHint,
  decryptCredential,
  encryptCredential,
} from "../lib/aiCredentials";

const router: IRouter = Router();
type Provider = "openai" | "anthropic" | "xai";

const providerMetadata: Record<Provider, {
  label: string;
  baseUrl: string;
  defaultModel: string;
}> = {
  openai: {
    label: "OpenAI",
    baseUrl: "https://api.openai.com",
    defaultModel: "gpt-4o-mini",
  },
  anthropic: {
    label: "Anthropic",
    baseUrl: "https://api.anthropic.com",
    defaultModel: "claude-3-5-haiku-latest",
  },
  xai: {
    label: "xAI",
    baseUrl: "https://api.x.ai",
    defaultModel: "grok-3-mini",
  },
};

function getUserId(req: Request): string | null {
  return getAuth(req)?.userId ?? null;
}

function isProvider(value: string): value is Provider {
  return value in providerMetadata;
}

function parseProvider(req: Request) {
  const parsed = SaveAiConnectionParams.safeParse(req.params);
  return parsed.success && isProvider(parsed.data.provider) ? parsed.data.provider : null;
}

function connectionResponse(
  provider: Provider,
  connection?: typeof aiConnectionsTable.$inferSelect,
) {
  return {
    provider,
    label: providerMetadata[provider].label,
    connected: Boolean(connection),
    state: connection?.state === "error"
      ? "error" as const
      : connection
        ? "connected" as const
        : "not_configured" as const,
    keyHint: connection?.keyHint ?? null,
    lastTestedAt: connection?.lastTestedAt ?? null,
    error: connection?.error ?? null,
  };
}

function providerError(status: number) {
  if (status === 401 || status === 403) return "The provider rejected this API key. Check the key and its API access permissions.";
  if (status === 429) return "The provider rate limit was reached. Wait a moment and try again.";
  if (status >= 500) return "The provider is temporarily unavailable. Try again shortly.";
  return "The provider rejected the request. Check the API account, key permissions, and selected model.";
}

async function providerFetch(
  provider: Provider,
  apiKey: string,
  path: string,
  init: RequestInit = {},
  parentSignal?: AbortSignal,
) {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 30_000);
  const abortFromParent = () => controller.abort();
  if (parentSignal?.aborted) controller.abort();
  parentSignal?.addEventListener("abort", abortFromParent, { once: true });
  const headers = new Headers(init.headers);
  headers.set("Content-Type", "application/json");
  if (provider === "anthropic") {
    headers.set("x-api-key", apiKey);
    headers.set("anthropic-version", "2023-06-01");
  } else {
    headers.set("Authorization", `Bearer ${apiKey}`);
  }

  try {
    const response = await fetch(`${providerMetadata[provider].baseUrl}${path}`, {
      ...init,
      headers,
      signal: controller.signal,
    });
    if (!response.ok) {
      throw new Error(providerError(response.status));
    }
    return response;
  } catch (error) {
    if (error instanceof Error && error.message !== "fetch failed" && error.name !== "AbortError") {
      throw error;
    }
    throw new Error("The provider could not be reached. Check your connection and try again.");
  } finally {
    clearTimeout(timeout);
    parentSignal?.removeEventListener("abort", abortFromParent);
  }
}

async function testProvider(provider: Provider, apiKey: string) {
  await providerFetch(provider, apiKey, "/v1/models");
}

function modelMessages(messages: Array<{ role: string; content: string }>) {
  return messages.filter((message) => message.role !== "system").map((message) => ({
    role: message.role === "assistant" ? "assistant" : "user",
    content: message.content,
  }));
}

async function requestProviderChat(
  provider: Provider,
  apiKey: string,
  model: string,
  messages: Array<{ role: "system" | "user" | "assistant"; content: string }>,
  signal?: AbortSignal,
) {
  const system = messages.filter((message) => message.role === "system").map((message) => message.content).join("\n\n");
  const response = await providerFetch(provider, apiKey, "/v1/" + (provider === "anthropic" ? "messages" : "chat/completions"), {
    method: "POST",
    body: JSON.stringify(provider === "anthropic"
      ? {
          model,
          max_tokens: 1200,
          ...(system ? { system } : {}),
          messages: modelMessages(messages),
        }
      : {
          model,
          messages,
          stream: false,
        }),
  }, signal);
  const payload = await response.json().catch(() => null) as Record<string, unknown> | null;
  if (provider === "anthropic") {
    const content = Array.isArray(payload?.content) && payload.content[0] && typeof payload.content[0] === "object"
      ? (payload.content[0] as Record<string, unknown>).text
      : null;
    if (typeof content !== "string") throw new Error("The provider returned an unreadable response.");
    return content;
  }
  const choices = Array.isArray(payload?.choices) ? payload.choices : [];
  const firstChoice = choices[0] && typeof choices[0] === "object" ? choices[0] as Record<string, unknown> : null;
  const message = firstChoice?.message && typeof firstChoice.message === "object"
    ? firstChoice.message as Record<string, unknown>
    : null;
  if (typeof message?.content !== "string") throw new Error("The provider returned an unreadable response.");
  return message.content;
}

router.get("/ai/connections", async (req, res): Promise<void> => {
  const userId = getUserId(req);
  if (!userId) {
    res.status(401).json({ error: "Authentication required" });
    return;
  }
  const connections = await db.select().from(aiConnectionsTable).where(eq(aiConnectionsTable.userId, userId));
  const byProvider = new Map(connections.map((connection) => [connection.provider, connection]));
  const response = (Object.keys(providerMetadata) as Provider[]).map((provider) => connectionResponse(provider, byProvider.get(provider)));
  res.json(ListAiConnectionsResponse.parse(response));
});

router.put("/ai/connections/:provider", async (req, res): Promise<void> => {
  const userId = getUserId(req);
  if (!userId) {
    res.status(401).json({ error: "Authentication required" });
    return;
  }
  const provider = parseProvider(req);
  const parsed = SaveAiConnectionBody.safeParse(req.body);
  if (!provider || !parsed.success) {
    res.status(400).json({ error: "Choose a supported provider and enter a valid API key." });
    return;
  }
  const [connection] = await db.insert(aiConnectionsTable).values({
    userId,
    provider,
    encryptedApiKey: encryptCredential(parsed.data.apiKey.trim()),
    keyHint: credentialHint(parsed.data.apiKey.trim()),
    state: "connected",
    error: null,
    lastTestedAt: null,
  }).onConflictDoUpdate({
    target: [aiConnectionsTable.userId, aiConnectionsTable.provider],
    set: {
      encryptedApiKey: encryptCredential(parsed.data.apiKey.trim()),
      keyHint: credentialHint(parsed.data.apiKey.trim()),
      state: "connected",
      error: null,
      lastTestedAt: null,
      updatedAt: new Date(),
    },
  }).returning();
  res.json(SaveAiConnectionResponse.parse(connectionResponse(provider, connection)));
});

router.post("/ai/connections/:provider/test", async (req, res): Promise<void> => {
  const userId = getUserId(req);
  if (!userId) {
    res.status(401).json({ error: "Authentication required" });
    return;
  }
  const provider = parseProvider(req);
  if (!provider) {
    res.status(400).json({ error: "Unsupported provider." });
    return;
  }
  const [connection] = await db.select().from(aiConnectionsTable).where(and(
    eq(aiConnectionsTable.userId, userId),
    eq(aiConnectionsTable.provider, provider),
  ));
  if (!connection) {
    res.status(404).json({ error: "Connect this provider before testing it." });
    return;
  }
  let success = false;
  let message = "Connection test failed.";
  try {
    await testProvider(provider, decryptCredential(connection.encryptedApiKey));
    success = true;
    message = `${providerMetadata[provider].label} API connection is working.`;
  } catch (error) {
    message = error instanceof Error ? error.message : "The provider connection could not be tested.";
  }
  const testedAt = new Date();
  await db.update(aiConnectionsTable).set({
    state: success ? "connected" : "error",
    error: success ? null : message,
    lastTestedAt: testedAt,
    updatedAt: testedAt,
  }).where(and(eq(aiConnectionsTable.userId, userId), eq(aiConnectionsTable.provider, provider)));
  res.json(TestAiConnectionResponse.parse({
    provider,
    success,
    message,
    testedAt,
  }));
});

router.delete("/ai/connections/:provider", async (req, res): Promise<void> => {
  const userId = getUserId(req);
  if (!userId) {
    res.status(401).json({ error: "Authentication required" });
    return;
  }
  const parsed = RemoveAiConnectionParams.safeParse(req.params);
  if (!parsed.success || !isProvider(parsed.data.provider)) {
    res.status(400).json({ error: "Unsupported provider." });
    return;
  }
  await db.delete(aiConnectionsTable).where(and(
    eq(aiConnectionsTable.userId, userId),
    eq(aiConnectionsTable.provider, parsed.data.provider),
  ));
  res.sendStatus(204);
});

router.post("/ai/chat", async (req, res): Promise<void> => {
  const userId = getUserId(req);
  if (!userId) {
    res.status(401).json({ error: "Authentication required" });
    return;
  }
  const parsed = SendAiChatBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [connection] = await db.select().from(aiConnectionsTable).where(and(
    eq(aiConnectionsTable.userId, userId),
    eq(aiConnectionsTable.provider, parsed.data.provider),
  ));
  if (!connection) {
    res.status(404).json({ error: `Connect ${providerMetadata[parsed.data.provider].label} before selecting cloud AI.` });
    return;
  }
  if (connection.state !== "connected") {
    res.status(409).json({ error: `Test or replace ${providerMetadata[parsed.data.provider].label} before sending cloud requests.` });
    return;
  }
  const model = parsed.data.model?.trim() || providerMetadata[parsed.data.provider].defaultModel;
  const controller = new AbortController();
  const abortProviderRequest = () => controller.abort();
  req.once("aborted", abortProviderRequest);
  try {
    const content = await requestProviderChat(
      parsed.data.provider,
      decryptCredential(connection.encryptedApiKey),
      model,
      parsed.data.messages as Array<{ role: "system" | "user" | "assistant"; content: string }>,
      controller.signal,
    );
    if (req.aborted) return;
    res.json(SendAiChatResponse.parse({
      provider: parsed.data.provider,
      model,
      content: content.trim(),
      done: true,
    }));
  } catch (error) {
    if (req.aborted) return;
    const message = error instanceof Error ? error.message : "The provider request failed.";
    res.status(502).json({ error: message });
  } finally {
    req.removeListener("aborted", abortProviderRequest);
  }
});

export default router;
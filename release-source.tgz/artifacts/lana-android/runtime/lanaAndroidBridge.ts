import { LanaLlama, type RuntimeStatus } from '@lana/lana-llama';

export type LocalMessage = {
  role: 'system' | 'user';
  content: string;
};

export type LocalModelRequest = {
  messages: LocalMessage[];
  signal?: AbortSignal;
};

export type LocalModelResponse = {
  content: string;
  model: string;
  done: boolean;
};

export type LanaAndroidBridge = {
  isAndroid: true;
  getRuntimeStatus(): Promise<RuntimeStatus>;
  retrySetup(): Promise<RuntimeStatus>;
  chat(request: LocalModelRequest): Promise<LocalModelResponse>;
};

declare global {
  interface Window {
    lanaAndroid?: LanaAndroidBridge;
  }
}

let bridge: LanaAndroidBridge | null = null;
let sequence = 0;

function nextRequestId() {
  sequence += 1;
  return `lana-${Date.now()}-${sequence}`;
}

export function installLanaAndroidBridge(): LanaAndroidBridge {
  if (bridge) return bridge;

  bridge = {
    isAndroid: true,
    getRuntimeStatus: LanaLlama.getRuntimeStatus,
    retrySetup: LanaLlama.retrySetup,
    async chat({ messages, signal }) {
      if (signal?.aborted) throw new Error('The local model request was cancelled.');
      const requestId = nextRequestId();
      const abort = () => LanaLlama.cancel(requestId);
      signal?.addEventListener('abort', abort, { once: true });
      try {
        const response = await LanaLlama.chat({ requestId, messages });
        if (signal?.aborted) throw new Error('The local model request was cancelled.');
        return response;
      } finally {
        signal?.removeEventListener('abort', abort);
      }
    },
  };

  const host = globalThis as typeof globalThis & { window?: Window };
  const target = host.window ?? (host as unknown as Window);
  target.lanaAndroid = bridge;
  return bridge;
}

export function getLanaAndroidBridge() {
  return bridge ?? installLanaAndroidBridge();
}
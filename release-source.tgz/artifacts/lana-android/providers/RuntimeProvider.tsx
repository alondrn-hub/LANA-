import React, { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import { Platform } from 'react-native';
import { LanaLlama, type RuntimeStatus } from '@lana/lana-llama';
import { getLanaAndroidBridge, installLanaAndroidBridge, type LanaAndroidBridge } from '@/runtime/lanaAndroidBridge';

type RuntimeContextValue = {
  bridge: LanaAndroidBridge;
  status: RuntimeStatus;
  retry(): Promise<void>;
};

const initialStatus: RuntimeStatus = {
  state: 'starting',
  message: 'Checking the local Android runtime…',
  model: 'Llama-3.2-3B-Instruct-Q4_K_M.gguf',
  acceleration: 'cpu',
};

const RuntimeContext = createContext<RuntimeContextValue | null>(null);

export function RuntimeProvider({ children }: { children: React.ReactNode }) {
  const bridge = useMemo(installLanaAndroidBridge, []);
  const [status, setStatus] = useState<RuntimeStatus>(initialStatus);

  const retry = useCallback(async () => {
    setStatus((current) => ({ ...current, state: 'starting', message: 'Preparing the verified local model…' }));
    setStatus(await bridge.retrySetup());
  }, [bridge]);

  useEffect(() => {
    const subscription = LanaLlama.addStatusListener(setStatus);
    bridge.getRuntimeStatus().then(setStatus).catch((error: unknown) => {
      setStatus({
        ...initialStatus,
        state: 'error',
        message: error instanceof Error ? error.message : 'The Android runtime could not be checked.',
      });
    });
    if (Platform.OS === 'android' && LanaLlama.isNativeAvailable) {
      retry().catch((error: unknown) => {
        setStatus((current) => ({
          ...current,
          state: 'error',
          message: error instanceof Error ? error.message : 'The local model could not be prepared.',
        }));
      });
    }
    return () => subscription?.remove();
  }, [bridge, retry]);

  return (
    <RuntimeContext.Provider value={{ bridge: getLanaAndroidBridge(), status, retry }}>
      {children}
    </RuntimeContext.Provider>
  );
}

export function useRuntime() {
  const value = useContext(RuntimeContext);
  if (!value) throw new Error('useRuntime must be used inside RuntimeProvider.');
  return value;
}
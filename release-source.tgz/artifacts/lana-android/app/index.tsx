import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  ActivityIndicator,
  FlatList,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import * as Haptics from 'expo-haptics';
import { Feather } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { KeyboardAvoidingView } from 'react-native-keyboard-controller';
import { KeyboardAwareScrollViewCompat } from '@/components/KeyboardAwareScrollViewCompat';
import { useColors } from '@/hooks/useColors';
import { useRuntime } from '@/providers/RuntimeProvider';

type Mode = 'build' | 'copilot' | 'factory';
type ChatMessage = { id: string; role: 'user' | 'assistant'; content: string };
type WorkerResult = { id: string; label: string; content: string };
type WorkspaceFiles = Record<'App.tsx' | 'styles.ts', string>;

const STORAGE_KEY = 'lana-android-workspace-v1';
const initialFiles: WorkspaceFiles = {
  'App.tsx': `import { View, Text } from 'react-native';

export default function App() {
  return (
    <View>
      <Text>Build something local.</Text>
    </View>
  );
}
`,
  'styles.ts': `import { StyleSheet } from 'react-native';

export const styles = StyleSheet.create({
  screen: {
    flex: 1,
  },
});
`,
};

const modes: Array<{ id: Mode; label: string; icon: React.ComponentProps<typeof Feather>['name'] }> = [
  { id: 'build', label: 'Build', icon: 'code' },
  { id: 'copilot', label: 'Copilot', icon: 'message-square' },
  { id: 'factory', label: 'Factory', icon: 'cpu' },
];

function statusTone(state: string, colors: ReturnType<typeof useColors>) {
  if (state === 'ready') return colors.success;
  if (state === 'downloading' || state === 'starting') return colors.primary;
  return colors.destructive;
}

function runtimeProgress(downloaded?: number, total?: number) {
  if (!downloaded || !total) return null;
  return Math.min(100, Math.round((downloaded / total) * 100));
}

export default function WorkspaceScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { bridge, status, retry } = useRuntime();
  const [mode, setMode] = useState<Mode>('build');
  const [files, setFiles] = useState<WorkspaceFiles>(initialFiles);
  const [activeFile, setActiveFile] = useState<keyof WorkspaceFiles>('App.tsx');
  const [suggestion, setSuggestion] = useState('');
  const [chatDraft, setChatDraft] = useState('');
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [factoryPrompt, setFactoryPrompt] = useState('');
  const [workerResults, setWorkerResults] = useState<WorkerResult[]>([]);
  const [busy, setBusy] = useState<'suggestion' | 'chat' | 'factory' | null>(null);
  const [notice, setNotice] = useState('');
  const requestController = useRef<AbortController | null>(null);
  const isReady = status.state === 'ready';
  const progress = runtimeProgress(status.modelDownloadedBytes, status.modelSizeBytes);
  const busyLabel = busy === 'suggestion' ? 'Generating suggestion' : busy === 'chat' ? 'Copilot is thinking' : 'Factory workers are running';

  useEffect(() => {
    AsyncStorage.getItem(STORAGE_KEY).then((stored) => {
      if (!stored) return;
      try {
        setFiles({ ...initialFiles, ...JSON.parse(stored) });
      } catch {
        setNotice('The saved mobile workspace could not be restored.');
      }
    });
  }, []);

  useEffect(() => {
    const timer = setTimeout(() => {
      AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(files)).catch(() => {
        setNotice('Changes are local, but this save could not be completed.');
      });
    }, 300);
    return () => clearTimeout(timer);
  }, [files]);

  useEffect(() => () => requestController.current?.abort(), []);

  const context = useMemo(
    () => Object.entries(files).map(([path, content]) => `FILE: ${path}\n${content}`).join('\n\n'),
    [files],
  );

  function requireRuntime() {
    if (isReady) return true;
    setNotice('The verified local model must be ready first.');
    return false;
  }

  function startLocalRequest() {
    const controller = new AbortController();
    requestController.current = controller;
    return controller;
  }

  function finishLocalRequest(controller: AbortController) {
    if (requestController.current === controller) requestController.current = null;
  }

  function cancelLocalRequest() {
    if (!requestController.current || requestController.current.signal.aborted) return;
    requestController.current.abort();
    setNotice('Cancelling the local model request…');
  }

  async function requestSuggestion() {
    if (!requireRuntime() || busy) return;
    setBusy('suggestion');
    setSuggestion('');
    const controller = startLocalRequest();
    try {
      const response = await bridge.chat({
        signal: controller.signal,
        messages: [
          {
            role: 'system',
            content: 'You are LANA DEV inline suggestions. Return only a concise code continuation with no markdown fences or explanation.',
          },
          {
            role: 'user',
            content: `Complete ${activeFile} after the existing code:\n\n${files[activeFile]}`,
          },
        ],
      });
      setSuggestion(response.content.trim());
      await Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    } catch (error) {
      setNotice(error instanceof Error ? error.message : 'The local suggestion failed.');
    } finally {
      setBusy(null);
      finishLocalRequest(controller);
    }
  }

  async function sendChat() {
    const prompt = chatDraft.trim();
    if (!prompt || !requireRuntime() || busy) return;
    const userMessage: ChatMessage = { id: `${Date.now()}-user`, role: 'user', content: prompt };
    setMessages((current) => [...current, userMessage]);
    setChatDraft('');
    setBusy('chat');
    const controller = startLocalRequest();
    try {
      const response = await bridge.chat({
        signal: controller.signal,
        messages: [
          {
            role: 'system',
            content: 'You are LANA DEV Copilot. Help with the local workspace. Be concise, practical, and never claim to have used cloud tools.',
          },
          { role: 'user', content: `Workspace:\n${context}\n\nRequest:\n${prompt}` },
        ],
      });
      setMessages((current) => [
        ...current,
        { id: `${Date.now()}-assistant`, role: 'assistant', content: response.content },
      ]);
    } catch (error) {
      setNotice(error instanceof Error ? error.message : 'Copilot could not answer locally.');
    } finally {
      setBusy(null);
      finishLocalRequest(controller);
    }
  }

  async function runFactory() {
    const prompt = factoryPrompt.trim();
    if (!prompt || !requireRuntime() || busy) return;
    setBusy('factory');
    setWorkerResults([]);
    const controller = startLocalRequest();
    const workers = [
      { id: 'nova', label: 'Plan', instruction: 'Break the request into an implementation plan.' },
      { id: 'core', label: 'Build', instruction: 'Propose the smallest correct code change.' },
      { id: 'shield', label: 'Review', instruction: 'Identify reliability, privacy, and release risks.' },
    ];
    try {
      const results = await Promise.all(workers.map(async (worker) => {
        const response = await bridge.chat({
          signal: controller.signal,
          messages: [
            {
              role: 'system',
              content: `You are the ${worker.id} LANA DEV Factory worker. ${worker.instruction} Return a short, actionable result.`,
            },
            { role: 'user', content: `Workspace:\n${context}\n\nTask:\n${prompt}` },
          ],
        });
        return { id: worker.id, label: worker.label, content: response.content };
      }));
      setWorkerResults(results);
      await Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    } catch (error) {
      controller.abort();
      setNotice(error instanceof Error ? error.message : 'The local Factory run failed.');
    } finally {
      setBusy(null);
      finishLocalRequest(controller);
    }
  }

  const headerInset = Platform.OS === 'web' ? Math.max(insets.top, 67) : insets.top;
  const footerInset = Platform.OS === 'web' ? 34 : insets.bottom;

  return (
    <View style={[styles.screen, { backgroundColor: colors.background, paddingTop: headerInset }]}>
      <View style={[styles.header, { backgroundColor: colors.secondary, borderBottomColor: colors.border }]}>
        <View>
          <Text style={[styles.brand, { color: colors.secondaryForeground }]}>LANA DEV</Text>
          <Text style={[styles.kicker, { color: colors.mutedForeground }]}>ANDROID · LOCAL WORKSPACE</Text>
        </View>
        <View style={[styles.runtimePill, { borderColor: statusTone(status.state, colors) }]}>
          <View style={[styles.statusDot, { backgroundColor: statusTone(status.state, colors) }]} />
          <Text style={[styles.runtimeText, { color: colors.secondaryForeground }]}>
            {status.state === 'ready' ? 'LOCAL' : status.state.toUpperCase()}
          </Text>
        </View>
      </View>

      <View style={[styles.runtimeBar, { backgroundColor: colors.card, borderBottomColor: colors.border }]}>
        <View style={styles.runtimeCopy}>
          <Text numberOfLines={1} style={[styles.runtimeMessage, { color: colors.cardForeground }]}>
            {progress !== null ? `${status.message} ${progress}%` : status.message}
          </Text>
          <Text style={[styles.runtimeMeta, { color: colors.mutedForeground }]}>
            {status.threads ? `${status.threads} threads · ` : ''}{status.acceleration.toUpperCase()} · no cloud fallback
          </Text>
        </View>
        {status.state === 'starting' || status.state === 'downloading' ? (
          <ActivityIndicator color={colors.primary} />
        ) : status.state !== 'ready' ? (
          <Pressable testID="runtime-retry" onPress={() => retry()} style={styles.iconButton}>
            <Feather name="refresh-cw" size={18} color={colors.primary} />
          </Pressable>
        ) : (
          <Feather name="shield" size={18} color={colors.success} />
        )}
      </View>

      <View style={[styles.modeBar, { borderBottomColor: colors.border }]}>
        {modes.map((item) => {
          const active = item.id === mode;
          return (
            <Pressable
              key={item.id}
              testID={`mode-${item.id}`}
              onPress={() => setMode(item.id)}
              style={[styles.modeItem, active && { borderBottomColor: colors.primary }]}
            >
              <Feather name={item.icon} size={16} color={active ? colors.foreground : colors.mutedForeground} />
              <Text style={[styles.modeLabel, { color: active ? colors.foreground : colors.mutedForeground }]}>
                {item.label}
              </Text>
            </Pressable>
          );
        })}
      </View>

      {busy ? (
        <View style={[styles.activeRunBar, { backgroundColor: colors.card, borderBottomColor: colors.border }]}>
          <ActivityIndicator size="small" color={colors.primary} />
          <Text style={[styles.activeRunText, { color: colors.cardForeground }]}>{busyLabel}</Text>
          <Pressable testID="cancel-local-run" onPress={cancelLocalRequest} style={[styles.cancelButton, { borderColor: colors.destructive }]}>
            <Text style={[styles.cancelButtonText, { color: colors.destructive }]}>Cancel</Text>
          </Pressable>
        </View>
      ) : null}

      {mode === 'build' ? (
        <KeyboardAwareScrollViewCompat
          style={styles.content}
          contentContainerStyle={[styles.contentBody, { paddingBottom: footerInset + 24 }]}
          bottomOffset={24}
          keyboardShouldPersistTaps="handled"
        >
          <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.fileTabs}>
            {(Object.keys(files) as Array<keyof WorkspaceFiles>).map((file) => (
              <Pressable
                key={file}
                testID={`file-${file}`}
                onPress={() => setActiveFile(file)}
                style={[
                  styles.fileTab,
                  { backgroundColor: activeFile === file ? colors.secondary : colors.muted },
                ]}
              >
                <Text style={[styles.fileLabel, { color: activeFile === file ? colors.secondaryForeground : colors.mutedForeground }]}>
                  {file}
                </Text>
              </Pressable>
            ))}
          </ScrollView>
          <TextInput
            testID="workspace-editor"
            value={files[activeFile]}
            onChangeText={(content) => {
              setFiles((current) => ({ ...current, [activeFile]: content }));
              setSuggestion('');
            }}
            multiline
            autoCapitalize="none"
            autoCorrect={false}
            textAlignVertical="top"
            style={[styles.editor, { backgroundColor: colors.code, color: colors.codeForeground, borderColor: colors.border }]}
          />
          {suggestion ? (
            <View style={[styles.suggestionCard, { backgroundColor: colors.card, borderColor: colors.primary }]}>
              <View style={styles.cardTitleRow}>
                <Feather name="zap" size={15} color={colors.primary} />
                <Text style={[styles.cardTitle, { color: colors.cardForeground }]}>Inline suggestion</Text>
              </View>
              <Text style={[styles.suggestionCode, { color: colors.mutedForeground }]}>{suggestion}</Text>
              <View style={styles.actionRow}>
                <Pressable
                  testID="apply-suggestion"
                  onPress={() => {
                    setFiles((current) => ({ ...current, [activeFile]: `${current[activeFile]}\n${suggestion}` }));
                    setSuggestion('');
                  }}
                  style={[styles.primaryButton, { backgroundColor: colors.primary }]}
                >
                  <Text style={[styles.primaryButtonText, { color: colors.primaryForeground }]}>Apply</Text>
                </Pressable>
                <Pressable onPress={() => setSuggestion('')} style={styles.secondaryButton}>
                  <Text style={[styles.secondaryButtonText, { color: colors.mutedForeground }]}>Dismiss</Text>
                </Pressable>
              </View>
            </View>
          ) : null}
          <Pressable
            testID="request-suggestion"
            disabled={!isReady || busy !== null}
            onPress={requestSuggestion}
            style={[styles.fullButton, { backgroundColor: colors.secondary, opacity: !isReady || busy ? 0.45 : 1 }]}
          >
            {busy === 'suggestion' ? <ActivityIndicator color={colors.secondaryForeground} /> : <Feather name="zap" size={17} color={colors.primary} />}
            <Text style={[styles.fullButtonText, { color: colors.secondaryForeground }]}>Suggest locally</Text>
          </Pressable>
        </KeyboardAwareScrollViewCompat>
      ) : mode === 'copilot' ? (
        <KeyboardAvoidingView style={styles.content} behavior="padding" keyboardVerticalOffset={0}>
          <FlatList
            data={messages}
            keyExtractor={(item) => item.id}
            keyboardDismissMode="interactive"
            keyboardShouldPersistTaps="handled"
            contentContainerStyle={[styles.chatList, { paddingBottom: 18 }]}
            ListEmptyComponent={
              <View style={styles.emptyState}>
                <Feather name="message-square" size={24} color={colors.primary} />
                <Text style={[styles.emptyTitle, { color: colors.foreground }]}>Ask against this workspace</Text>
                <Text style={[styles.emptyText, { color: colors.mutedForeground }]}>Code and prompts remain on this device.</Text>
              </View>
            }
            renderItem={({ item }) => (
              <View
                style={[
                  styles.message,
                  { backgroundColor: item.role === 'user' ? colors.secondary : colors.card, borderColor: colors.border },
                ]}
              >
                <Text style={[styles.messageRole, { color: item.role === 'user' ? colors.primary : colors.accent }]}>
                  {item.role === 'user' ? 'YOU' : 'COPILOT'}
                </Text>
                <Text style={[styles.messageText, { color: item.role === 'user' ? colors.secondaryForeground : colors.cardForeground }]}>
                  {item.content}
                </Text>
              </View>
            )}
          />
          <View style={[styles.composer, { paddingBottom: footerInset + 10, borderTopColor: colors.border, backgroundColor: colors.background }]}>
            <TextInput
              testID="copilot-input"
              value={chatDraft}
              onChangeText={setChatDraft}
              placeholder="Ask Copilot…"
              placeholderTextColor={colors.mutedForeground}
              multiline
              style={[styles.composerInput, { color: colors.foreground, backgroundColor: colors.card, borderColor: colors.input }]}
            />
            <Pressable testID="send-copilot" disabled={!chatDraft.trim() || !isReady || busy !== null} onPress={sendChat} style={styles.sendButton}>
              {busy === 'chat' ? <ActivityIndicator color={colors.primary} /> : <Feather name="arrow-up-circle" size={28} color={colors.primary} />}
            </Pressable>
          </View>
        </KeyboardAvoidingView>
      ) : (
        <KeyboardAwareScrollViewCompat
          style={styles.content}
          contentContainerStyle={[styles.contentBody, { paddingBottom: footerInset + 24 }]}
          bottomOffset={24}
          keyboardShouldPersistTaps="handled"
        >
          <View style={[styles.factoryHero, { backgroundColor: colors.secondary }]}>
            <Text style={[styles.factoryKicker, { color: colors.primary }]}>LOCAL MULTI-WORKER RUN</Text>
            <Text style={[styles.factoryTitle, { color: colors.secondaryForeground }]}>Plan, build, and review in one pass.</Text>
            <Text style={[styles.factoryDescription, { color: colors.mutedForeground }]}>
              Workers launch together. llama.cpp queues inference without sending workspace data off-device.
            </Text>
          </View>
          <TextInput
            testID="factory-input"
            value={factoryPrompt}
            onChangeText={setFactoryPrompt}
            placeholder="Describe the change to build…"
            placeholderTextColor={colors.mutedForeground}
            multiline
            textAlignVertical="top"
            style={[styles.factoryInput, { backgroundColor: colors.card, color: colors.foreground, borderColor: colors.input }]}
          />
          <Pressable
            testID="run-factory"
            disabled={!factoryPrompt.trim() || !isReady || busy !== null}
            onPress={runFactory}
            style={[styles.fullButton, { backgroundColor: colors.primary, opacity: !factoryPrompt.trim() || !isReady || busy ? 0.45 : 1 }]}
          >
            {busy === 'factory' ? <ActivityIndicator color={colors.primaryForeground} /> : <Feather name="play" size={17} color={colors.primaryForeground} />}
            <Text style={[styles.fullButtonText, { color: colors.primaryForeground }]}>Run local Factory</Text>
          </Pressable>
          {workerResults.map((result) => (
            <View key={result.id} style={[styles.workerCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
              <Text style={[styles.workerLabel, { color: colors.accent }]}>{result.label.toUpperCase()}</Text>
              <Text style={[styles.workerText, { color: colors.cardForeground }]}>{result.content}</Text>
            </View>
          ))}
        </KeyboardAwareScrollViewCompat>
      )}

      {notice ? (
        <Pressable onPress={() => setNotice('')} style={[styles.notice, { backgroundColor: colors.destructive }]}>
          <Text numberOfLines={2} style={[styles.noticeText, { color: colors.destructiveForeground }]}>{notice}</Text>
          <Feather name="x" size={16} color={colors.destructiveForeground} />
        </Pressable>
      ) : null}
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1 },
  header: { minHeight: 60, paddingHorizontal: 18, paddingVertical: 11, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', borderBottomWidth: 1 },
  brand: { fontFamily: 'Manrope_700Bold', fontSize: 18, letterSpacing: 0.8 },
  kicker: { fontFamily: 'Manrope_600SemiBold', fontSize: 8, letterSpacing: 1.2, marginTop: 2 },
  runtimePill: { flexDirection: 'row', alignItems: 'center', gap: 6, paddingHorizontal: 9, paddingVertical: 5, borderWidth: 1, borderRadius: 20 },
  runtimeText: { fontFamily: 'Manrope_700Bold', fontSize: 9, letterSpacing: 0.8 },
  statusDot: { width: 6, height: 6, borderRadius: 3 },
  runtimeBar: { minHeight: 58, paddingHorizontal: 18, paddingVertical: 10, flexDirection: 'row', alignItems: 'center', gap: 12, borderBottomWidth: 1 },
  runtimeCopy: { flex: 1 },
  runtimeMessage: { fontFamily: 'Manrope_600SemiBold', fontSize: 12 },
  runtimeMeta: { fontFamily: 'Manrope_500Medium', fontSize: 9, marginTop: 3 },
  iconButton: { padding: 8 },
  modeBar: { height: 49, flexDirection: 'row', borderBottomWidth: 1 },
  modeItem: { flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 7, borderBottomWidth: 2, borderBottomColor: 'transparent' },
  modeLabel: { fontFamily: 'Manrope_700Bold', fontSize: 11 },
  activeRunBar: { minHeight: 42, paddingHorizontal: 16, flexDirection: 'row', alignItems: 'center', gap: 9, borderBottomWidth: 1 },
  activeRunText: { flex: 1, fontFamily: 'Manrope_600SemiBold', fontSize: 11 },
  cancelButton: { borderWidth: 1, borderRadius: 7, paddingHorizontal: 10, paddingVertical: 5 },
  cancelButtonText: { fontFamily: 'Manrope_700Bold', fontSize: 10 },
  content: { flex: 1 },
  contentBody: { padding: 16, gap: 12 },
  fileTabs: { gap: 7 },
  fileTab: { paddingHorizontal: 12, paddingVertical: 8, borderRadius: 7 },
  fileLabel: { fontFamily: 'monospace', fontSize: 11 },
  editor: { minHeight: 330, borderWidth: 1, borderRadius: 10, padding: 14, fontFamily: 'monospace', fontSize: 12, lineHeight: 19 },
  suggestionCard: { padding: 13, borderWidth: 1, borderRadius: 10, gap: 10 },
  cardTitleRow: { flexDirection: 'row', alignItems: 'center', gap: 7 },
  cardTitle: { fontFamily: 'Manrope_700Bold', fontSize: 12 },
  suggestionCode: { fontFamily: 'monospace', fontSize: 11, lineHeight: 17 },
  actionRow: { flexDirection: 'row', gap: 8 },
  primaryButton: { paddingHorizontal: 14, paddingVertical: 8, borderRadius: 7 },
  primaryButtonText: { fontFamily: 'Manrope_700Bold', fontSize: 11 },
  secondaryButton: { paddingHorizontal: 10, paddingVertical: 8 },
  secondaryButtonText: { fontFamily: 'Manrope_600SemiBold', fontSize: 11 },
  fullButton: { minHeight: 48, borderRadius: 9, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 9 },
  fullButtonText: { fontFamily: 'Manrope_700Bold', fontSize: 13 },
  chatList: { padding: 16, gap: 10, flexGrow: 1 },
  emptyState: { flex: 1, minHeight: 280, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 28 },
  emptyTitle: { fontFamily: 'Manrope_700Bold', fontSize: 18, marginTop: 14, textAlign: 'center' },
  emptyText: { fontFamily: 'Manrope_400Regular', fontSize: 13, lineHeight: 19, textAlign: 'center', marginTop: 6 },
  message: { padding: 13, borderWidth: 1, borderRadius: 10 },
  messageRole: { fontFamily: 'Manrope_700Bold', fontSize: 8, letterSpacing: 1.1, marginBottom: 5 },
  messageText: { fontFamily: 'Manrope_400Regular', fontSize: 13, lineHeight: 20 },
  composer: { flexDirection: 'row', alignItems: 'flex-end', gap: 8, paddingHorizontal: 12, paddingTop: 10, borderTopWidth: 1 },
  composerInput: { flex: 1, minHeight: 44, maxHeight: 110, borderWidth: 1, borderRadius: 10, paddingHorizontal: 12, paddingVertical: 10, fontFamily: 'Manrope_400Regular', fontSize: 13 },
  sendButton: { padding: 7 },
  factoryHero: { padding: 18, borderRadius: 12 },
  factoryKicker: { fontFamily: 'Manrope_700Bold', fontSize: 9, letterSpacing: 1.1 },
  factoryTitle: { fontFamily: 'Manrope_700Bold', fontSize: 22, lineHeight: 28, marginTop: 7 },
  factoryDescription: { fontFamily: 'Manrope_400Regular', fontSize: 12, lineHeight: 18, marginTop: 8 },
  factoryInput: { minHeight: 120, borderWidth: 1, borderRadius: 10, padding: 13, fontFamily: 'Manrope_400Regular', fontSize: 13, lineHeight: 20 },
  workerCard: { padding: 14, borderWidth: 1, borderRadius: 10 },
  workerLabel: { fontFamily: 'Manrope_700Bold', fontSize: 9, letterSpacing: 1 },
  workerText: { fontFamily: 'Manrope_400Regular', fontSize: 12, lineHeight: 19, marginTop: 7 },
  notice: { position: 'absolute', left: 14, right: 14, bottom: 14, minHeight: 46, paddingHorizontal: 14, paddingVertical: 10, borderRadius: 9, flexDirection: 'row', alignItems: 'center', gap: 10 },
  noticeText: { flex: 1, fontFamily: 'Manrope_600SemiBold', fontSize: 11, lineHeight: 16 },
});
# LANA DEV Android APK

The companion is an Android arm64 build with an Expo Modules API bridge and a
pinned llama.cpp JNI library. It does not call the API server or any cloud AI
provider.

## What ships

- `window.lanaAndroid` is installed by `runtime/lanaAndroidBridge.ts`.
- `@lana/lana-llama` is a local Expo module compiled into the APK.
- llama.cpp `v0.2.0` is fetched at immutable commit
  `bb4caa7540188872173c44d161602d9271386413` and compiled for `arm64-v8a`.
- The approved `Llama-3.2-3B-Instruct-Q4_K_M.gguf` model is provisioned on
  first launch into `noBackupFilesDir/models`.
- The model download resumes from a partial file, then must match the exact
  size and SHA-256 in `runtime/model-manifest.json` before llama.cpp loads it.
- Available memory, free storage, Android API, and ABI are checked first.
- Setup, model lifecycle, and native requests are serialized with one lifecycle
  mutex. Abort signals reject active or queued work as cancelled while queued
  Factory requests remain isolated.

## Device requirements

- Android 8.0 / API 26 or newer for local inference. API 24–25 devices can
  install the shell but receive an explicit `unsupported` runtime state.
- 64-bit ARM (`arm64-v8a`)
- At least 2.6 GB of free app storage for first-run provisioning
- At least 3.0 GB of currently available memory before inference starts
- Network access for the one-time model download

Devices outside these limits return `unsupported`, `memory-pressure`, or
`error`; they never route requests to a cloud model.

## Verify the package contract

```sh
pnpm --filter @workspace/lana-android run typecheck
pnpm --filter @workspace/lana-android run verify:android-runtime
```

## Build the installable verification APK

The Android SDK, NDK, CMake, Java 17, and Git must be installed. Then run:

```sh
pnpm --filter @workspace/lana-android run android:apk
```

The script verifies the sealed runtime manifest, generates the Android native
project, and compiles only the verified `arm64-v8a` optimized APK in a bounded
two-worker Gradle process before writing:

```text
artifacts/lana-android/dist/android/LANA-DEV-Android.apk
artifacts/lana-android/dist/android/LANA-DEV-Android.apk.sha256
```

This repository intentionally uses Expo's generated debug keystore so the APK
is installable for device verification without committing or requesting a
private production signing key. It is not a Play Store/publishable signing
configuration. Before public distribution, configure an owner-controlled
release keystore outside the repository and retain it for future app updates.

Expo Go and the browser preview cannot load custom JNI modules. They show the
complete workspace shell with an explicit “installed Android APK required”
runtime state; local inference is verified in a development or release APK.
import { createHash } from 'node:crypto';
import { readFile, stat } from 'node:fs/promises';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const manifestPath = resolve(root, 'runtime/model-manifest.json');
const manifestSource = await readFile(manifestPath, 'utf8');
const manifest = JSON.parse(manifestSource);
const appConfig = JSON.parse(await readFile(resolve(root, 'app.json'), 'utf8'));

function assert(condition, message) {
  if (!condition) throw new Error(message);
}

assert(manifest.runtime === 'llama.cpp', 'Android runtime must be llama.cpp.');
assert(/^v\d+\.\d+\.\d+$/.test(manifest.runtimeVersion), 'llama.cpp release must be pinned.');
assert(/^[a-f0-9]{40}$/.test(manifest.runtimeCommit), 'llama.cpp commit must be pinned.');
assert(manifest.model === 'Llama-3.2-3B-Instruct-Q4_K_M.gguf', 'Unexpected approved model.');
assert(/^[a-f0-9]{64}$/.test(manifest.modelSha256), 'Model SHA-256 must be sealed.');
assert(manifest.modelSizeBytes > 1_000_000_000, 'Model size must be explicit.');
assert(manifest.requiredMemoryBytes > manifest.modelSizeBytes, 'Memory gate must exceed model size.');
assert(manifest.minimumFreeDiskBytes > manifest.modelSizeBytes, 'Disk gate must exceed model size.');
assert(manifest.cloudFallback === false, 'Android companion may not enable cloud fallback.');
assert(manifest.supportedAbis.length === 1 && manifest.supportedAbis[0] === 'arm64-v8a', 'Only verified arm64 ABI may ship.');
assert(
  await readFile(resolve(root, 'modules/lana-llama/android/src/main/assets/lana-model-manifest.json'), 'utf8') === manifestSource,
  'The Android asset must exactly match the sealed runtime manifest.'
);
for (const permission of [
  'android.permission.READ_EXTERNAL_STORAGE',
  'android.permission.WRITE_EXTERNAL_STORAGE',
  'android.permission.SYSTEM_ALERT_WINDOW',
]) {
  assert(
    appConfig.expo.android.blockedPermissions?.includes(permission),
    `${permission} must remain blocked.`
  );
}

const requiredFiles = [
  'modules/lana-llama/android/CMakeLists.txt',
  'modules/lana-llama/android/src/main/cpp/lana_llama_jni.cpp',
  'modules/lana-llama/android/src/main/java/dev/lana/llama/LanaLlamaModule.kt',
  'runtime/lanaAndroidBridge.ts'
];

for (const relative of requiredFiles) {
  const info = await stat(resolve(root, relative));
  assert(info.isFile() && info.size > 0, `Missing Android runtime file: ${relative}`);
}

const cmake = await readFile(resolve(root, requiredFiles[0]), 'utf8');
assert(cmake.includes(`GIT_TAG ${manifest.runtimeCommit}`), 'CMake llama.cpp commit differs from the manifest.');

const kotlin = await readFile(resolve(root, requiredFiles[2]), 'utf8');
for (const contractMethod of ['getRuntimeStatus', 'retrySetup', 'chat', 'cancel']) {
  assert(kotlin.includes(`"${contractMethod}"`), `Native bridge is missing ${contractMethod}().`);
}
assert(kotlin.includes('MessageDigest.getInstance("SHA-256")'), 'Native provisioning must verify SHA-256.');
assert(kotlin.includes('noBackupFilesDir'), 'Model must live in app-private storage.');
assert(kotlin.includes('lifecycleMutex.withLock'), 'Setup and inference must share one lifecycle mutex.');
assert(kotlin.includes('nativeTakeCancellation'), 'Queued native requests must reject cancellation before inference.');

const jni = await readFile(resolve(root, requiredFiles[1]), 'utf8');
assert(jni.includes('std::unique_lock<std::mutex> lifecycle_lock(runtime_mutex)'), 'JNI must retain the model lifecycle lock through inference.');
assert(jni.includes('std::mutex cancellation_mutex'), 'JNI cancellation must not share the blocking lifecycle mutex.');
assert(jni.includes('java/util/concurrent/CancellationException'), 'Native cancellation must reject instead of returning partial success.');

const workspace = await readFile(resolve(root, 'app/index.tsx'), 'utf8');
assert(workspace.includes('testID="cancel-local-run"'), 'Active local work must expose a cancel action.');
assert((workspace.match(/signal: controller\.signal/g) ?? []).length >= 3, 'Suggestions, Copilot, and Factory must all propagate cancellation.');

const apkBuild = await readFile(resolve(root, 'scripts/build-android-apk.mjs'), 'utf8');
assert(
  apkBuild.includes('-PreactNativeArchitectures=arm64-v8a'),
  'Release packaging must stay restricted to the verified arm64 ABI.'
);
assert(
  apkBuild.includes('--max-workers=2') && apkBuild.includes('kotlin.compiler.execution.strategy=in-process'),
  'Release packaging must keep Gradle memory bounded in constrained builders.'
);

const manifestDigest = createHash('sha256').update(await readFile(manifestPath)).digest('hex');
console.log(`Verified Android llama.cpp contract (${manifest.runtimeVersion}, manifest ${manifestDigest.slice(0, 12)}…).`);
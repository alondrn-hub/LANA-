import { createHash } from 'node:crypto';
import { createReadStream } from 'node:fs';
import { copyFile, mkdir, readFile, writeFile } from 'node:fs/promises';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { spawn } from 'node:child_process';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');

function run(command, args, cwd = root) {
  return new Promise((resolveRun, reject) => {
    const child = spawn(command, args, { cwd, stdio: 'inherit', env: process.env });
    child.on('error', reject);
    child.on('exit', (code) => code === 0
      ? resolveRun()
      : reject(new Error(`${command} ${args.join(' ')} exited with ${code}`)));
  });
}

async function sha256(path) {
  const hash = createHash('sha256');
  for await (const chunk of createReadStream(path)) hash.update(chunk);
  return hash.digest('hex');
}

await run('node', ['scripts/verify-android-runtime.mjs']);
await run('pnpm', ['exec', 'expo', 'prebuild', '--platform', 'android', '--clean', '--no-install']);
await run(
  process.platform === 'win32' ? 'gradlew.bat' : './gradlew',
  [
    'assembleRelease',
    '-PreactNativeArchitectures=arm64-v8a',
    '--no-daemon',
    '--max-workers=2',
    '-Pkotlin.compiler.execution.strategy=in-process',
  ],
  resolve(root, 'android')
);

const source = resolve(root, 'android/app/build/outputs/apk/release/app-release.apk');
const outputDir = resolve(root, 'dist/android');
const output = resolve(outputDir, 'LANA-DEV-Android.apk');
await mkdir(outputDir, { recursive: true });
await copyFile(source, output);
const digest = await sha256(output);
await writeFile(`${output}.sha256`, `${digest}  LANA-DEV-Android.apk\n`);

const manifest = JSON.parse(await readFile(resolve(root, 'runtime/model-manifest.json'), 'utf8'));
console.log(`APK ready: ${output}`);
console.log(`APK SHA-256: ${digest}`);
console.log(`First launch provisions ${manifest.model} into app-private storage and verifies ${manifest.modelSha256}.`);
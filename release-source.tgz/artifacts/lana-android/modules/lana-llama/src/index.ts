import { requireOptionalNativeModule } from 'expo';

export type RuntimeState =
  | 'starting'
  | 'downloading'
  | 'ready'
  | 'memory-pressure'
  | 'offline'
  | 'unsupported'
  | 'error';

export type RuntimeStatus = {
  state: RuntimeState;
  message: string;
  model: string;
  modelSizeBytes?: number;
  modelDownloadedBytes?: number;
  availableMemoryBytes?: number;
  requiredMemoryBytes?: number;
  threads?: number;
  acceleration: 'cpu';
};

export type NativeChatRequest = {
  requestId: string;
  messages: Array<{ role: 'system' | 'user'; content: string }>;
};

type EventSubscription = { remove(): void };

type LanaLlamaNativeModule = {
  getRuntimeStatus(): Promise<RuntimeStatus>;
  retrySetup(): Promise<RuntimeStatus>;
  chat(request: NativeChatRequest): Promise<{ content: string; model: string; done: boolean }>;
  cancel(requestId: string): void;
  addListener(eventName: 'onRuntimeStatus', listener: (status: RuntimeStatus) => void): EventSubscription;
};

const nativeModule = requireOptionalNativeModule<LanaLlamaNativeModule>('LanaLlama');

const unavailableStatus: RuntimeStatus = {
  state: 'unsupported',
  message: 'The native llama.cpp runtime is available in the installed Android APK.',
  model: 'Llama-3.2-3B-Instruct-Q4_K_M.gguf',
  acceleration: 'cpu',
};

export const LanaLlama = {
  isNativeAvailable: Boolean(nativeModule),
  getRuntimeStatus: () => nativeModule?.getRuntimeStatus() ?? Promise.resolve(unavailableStatus),
  retrySetup: () => nativeModule?.retrySetup() ?? Promise.resolve(unavailableStatus),
  chat: (request: NativeChatRequest) => {
    if (!nativeModule) {
      return Promise.reject(new Error('Install the Android APK to use the local llama.cpp runtime.'));
    }
    return nativeModule.chat(request);
  },
  cancel: (requestId: string) => nativeModule?.cancel(requestId),
  addStatusListener(listener: (status: RuntimeStatus) => void): EventSubscription | null {
    return nativeModule?.addListener('onRuntimeStatus', listener) ?? null;
  },
};
#include <jni.h>
#include <android/log.h>
#include <llama.h>
#include <algorithm>
#include <mutex>
#include <stdexcept>
#include <string>
#include <unordered_set>
#include <vector>

namespace {
constexpr const char * TAG = "LanaLlama";
std::mutex runtime_mutex;
std::mutex cancellation_mutex;
llama_model * model = nullptr;
std::unordered_set<std::string> cancelled;
bool backend_initialized = false;

std::string from_jstring(JNIEnv * env, jstring value) {
  if (value == nullptr) return {};
  const char * chars = env->GetStringUTFChars(value, nullptr);
  std::string result(chars);
  env->ReleaseStringUTFChars(value, chars);
  return result;
}

void throw_java(JNIEnv * env, const std::string & message, const char * class_name = "java/lang/IllegalStateException") {
  jclass error = env->FindClass(class_name);
  env->ThrowNew(error, message.c_str());
}

bool is_cancelled(const std::string & request_id) {
  std::lock_guard<std::mutex> lock(cancellation_mutex);
  return cancelled.find(request_id) != cancelled.end();
}

bool take_cancelled(const std::string & request_id) {
  std::lock_guard<std::mutex> lock(cancellation_mutex);
  const auto found = cancelled.find(request_id);
  if (found == cancelled.end()) return false;
  cancelled.erase(found);
  return true;
}

void clear_cancelled(const std::string & request_id) {
  std::lock_guard<std::mutex> lock(cancellation_mutex);
  cancelled.erase(request_id);
}

void throw_cancelled(JNIEnv * env) {
  throw_java(env, "The local model request was cancelled.", "java/util/concurrent/CancellationException");
}
}

extern "C" JNIEXPORT void JNICALL
Java_dev_lana_llama_LanaLlamaModule_nativeLoadModel(
  JNIEnv * env,
  jobject,
  jstring model_path,
  jint threads,
  jint context_size
) {
  std::lock_guard<std::mutex> lock(runtime_mutex);
  if (!backend_initialized) {
    llama_backend_init();
    backend_initialized = true;
  }
  if (model != nullptr) {
    llama_model_free(model);
    model = nullptr;
  }
  llama_model_params params = llama_model_default_params();
  params.n_gpu_layers = 0;
  model = llama_model_load_from_file(from_jstring(env, model_path).c_str(), params);
  if (model == nullptr) {
    throw_java(env, "llama.cpp could not load the approved GGUF model.");
    return;
  }
  __android_log_print(ANDROID_LOG_INFO, TAG, "Loaded model with %d threads and %d context tokens", threads, context_size);
}

extern "C" JNIEXPORT jstring JNICALL
Java_dev_lana_llama_LanaLlamaModule_nativeComplete(
  JNIEnv * env,
  jobject,
  jstring prompt_value,
  jint max_tokens,
  jint threads,
  jint context_size,
  jstring request_id_value
) {
  std::unique_lock<std::mutex> lifecycle_lock(runtime_mutex);
  llama_model * active_model = model;
  const std::string request_id = from_jstring(env, request_id_value);
  if (take_cancelled(request_id)) {
    throw_cancelled(env);
    return nullptr;
  }
  if (active_model == nullptr) {
    throw_java(env, "The approved local model is not loaded.");
    return nullptr;
  }

  const std::string prompt = from_jstring(env, prompt_value);
  const llama_vocab * vocab = llama_model_get_vocab(active_model);
  int token_count = -llama_tokenize(vocab, prompt.c_str(), prompt.size(), nullptr, 0, true, true);
  if (token_count <= 0 || token_count + max_tokens >= context_size) {
    clear_cancelled(request_id);
    throw_java(env, "The request exceeds the local model context window.");
    return nullptr;
  }

  std::vector<llama_token> tokens(token_count);
  if (llama_tokenize(vocab, prompt.c_str(), prompt.size(), tokens.data(), tokens.size(), true, true) < 0) {
    clear_cancelled(request_id);
    throw_java(env, "llama.cpp could not tokenize the request.");
    return nullptr;
  }

  llama_context_params context_params = llama_context_default_params();
  context_params.n_ctx = context_size;
  context_params.n_batch = std::min(context_size, 512);
  context_params.n_threads = std::max(1, static_cast<int>(threads));
  context_params.n_threads_batch = context_params.n_threads;
  context_params.no_perf = true;
  llama_context * context = llama_init_from_model(active_model, context_params);
  if (context == nullptr) {
    clear_cancelled(request_id);
    throw_java(env, "llama.cpp could not allocate an inference context.");
    return nullptr;
  }

  llama_sampler * sampler = llama_sampler_chain_init(llama_sampler_chain_default_params());
  llama_sampler_chain_add(sampler, llama_sampler_init_min_p(0.05f, 1));
  llama_sampler_chain_add(sampler, llama_sampler_init_temp(0.2f));
  llama_sampler_chain_add(sampler, llama_sampler_init_dist(LLAMA_DEFAULT_SEED));

  std::string output;
  bool did_cancel = false;
  llama_batch batch = llama_batch_get_one(tokens.data(), tokens.size());
  for (int generated = 0; generated < max_tokens; ++generated) {
    if (is_cancelled(request_id)) {
      did_cancel = true;
      break;
    }
    if (llama_decode(context, batch) != 0) {
      llama_sampler_free(sampler);
      llama_free(context);
      clear_cancelled(request_id);
      throw_java(env, "llama.cpp failed while decoding the request.");
      return nullptr;
    }
    llama_token token = llama_sampler_sample(sampler, context, -1);
    if (llama_vocab_is_eog(vocab, token)) break;

    std::vector<char> piece(256);
    int size = llama_token_to_piece(vocab, token, piece.data(), piece.size(), 0, true);
    if (size < 0) {
      piece.resize(-size);
      size = llama_token_to_piece(vocab, token, piece.data(), piece.size(), 0, true);
    }
    if (size > 0) output.append(piece.data(), size);
    batch = llama_batch_get_one(&token, 1);
  }

  llama_sampler_free(sampler);
  llama_free(context);
  if (did_cancel) {
    take_cancelled(request_id);
    throw_cancelled(env);
    return nullptr;
  }
  clear_cancelled(request_id);
  return env->NewStringUTF(output.c_str());
}

extern "C" JNIEXPORT void JNICALL
Java_dev_lana_llama_LanaLlamaModule_nativeCancel(JNIEnv * env, jobject, jstring request_id_value) {
  std::lock_guard<std::mutex> lock(cancellation_mutex);
  cancelled.insert(from_jstring(env, request_id_value));
}

extern "C" JNIEXPORT jboolean JNICALL
Java_dev_lana_llama_LanaLlamaModule_nativeTakeCancellation(JNIEnv * env, jobject, jstring request_id_value) {
  return take_cancelled(from_jstring(env, request_id_value)) ? JNI_TRUE : JNI_FALSE;
}

extern "C" JNIEXPORT void JNICALL
Java_dev_lana_llama_LanaLlamaModule_nativeRelease(JNIEnv *, jobject) {
  std::lock_guard<std::mutex> lock(runtime_mutex);
  if (model != nullptr) {
    llama_model_free(model);
    model = nullptr;
  }
  if (backend_initialized) {
    llama_backend_free();
    backend_initialized = false;
  }
  {
    std::lock_guard<std::mutex> cancellation_lock(cancellation_mutex);
    cancelled.clear();
  }
}
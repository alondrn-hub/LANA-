package dev.lana.llama

import android.app.ActivityManager
import android.content.Context
import android.os.Build
import android.os.StatFs
import expo.modules.kotlin.functions.Coroutine
import expo.modules.kotlin.modules.Module
import expo.modules.kotlin.modules.ModuleDefinition
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import java.util.concurrent.CancellationException
import kotlin.math.max
import kotlin.math.min

class LanaLlamaModule : Module() {
  private val lifecycleMutex = Mutex()
  private var state = "starting"
  private var message = "Checking the Android local runtime…"
  private var downloadedBytes = 0L
  private var loaded = false
  private val manifest by lazy { loadManifest() }

  init {
    System.loadLibrary("lana_llama")
  }

  override fun definition() = ModuleDefinition {
    Name("LanaLlama")
    Events("onRuntimeStatus")

    AsyncFunction("getRuntimeStatus") Coroutine { ->
      statusMap()
    }

    AsyncFunction("retrySetup") Coroutine { ->
      lifecycleMutex.withLock {
        withContext(Dispatchers.IO) { setupRuntime() }
      }
    }

    AsyncFunction("chat") Coroutine { request: Map<String, Any?> ->
      val requestId = request["requestId"] as? String
        ?: throw IllegalArgumentException("requestId is required.")
      @Suppress("UNCHECKED_CAST")
      val messages = request["messages"] as? List<Map<String, Any?>>
        ?: throw IllegalArgumentException("messages are required.")

      lifecycleMutex.withLock {
        if (nativeTakeCancellation(requestId)) {
          throw CancellationException("The local model request was cancelled.")
        }
        if (!loaded) setupRuntime()
        if (nativeTakeCancellation(requestId)) {
          throw CancellationException("The local model request was cancelled.")
        }
        val availableMemory = availableMemoryBytes()
        if (availableMemory < manifest.requiredMemoryBytes) {
          updateStatus(
            "memory-pressure",
            "Close other apps before running the local model. ${formatBytes(manifest.requiredMemoryBytes)} is required."
          )
          throw IllegalStateException(message)
        }
        val prompt = formatPrompt(messages)
        val content = withContext(Dispatchers.Default) {
          nativeComplete(
            prompt,
            manifest.maximumOutputTokens,
            threadCount(),
            manifest.contextSize,
            requestId
          )
        }
        mapOf(
          "content" to content.trim(),
          "model" to manifest.model,
          "done" to true
        )
      }
    }

    Function("cancel") { requestId: String ->
      nativeCancel(requestId)
    }

    OnDestroy {
      nativeRelease()
    }
  }

  private suspend fun setupRuntime(): Map<String, Any?> {
    val unsupportedReason = unsupportedReason()
    if (unsupportedReason != null) {
      updateStatus("unsupported", unsupportedReason)
      return statusMap()
    }

    val availableMemory = availableMemoryBytes()
    if (availableMemory < manifest.requiredMemoryBytes) {
      updateStatus(
        "memory-pressure",
        "This device has ${formatBytes(availableMemory)} available; the local model needs ${formatBytes(manifest.requiredMemoryBytes)}."
      )
      return statusMap()
    }

    val context = requireNotNull(appContext.reactContext)
    val modelDir = File(context.noBackupFilesDir, "models").apply { mkdirs() }
    val modelFile = File(modelDir, manifest.model)
    if (!modelFile.exists() || modelFile.length() != manifest.modelSizeBytes || sha256(modelFile) != manifest.modelSha256) {
      loaded = false
      if (StatFs(modelDir.absolutePath).availableBytes < manifest.minimumFreeDiskBytes) {
        updateStatus("error", "Free ${formatBytes(manifest.minimumFreeDiskBytes)} of storage to install the local model.")
        return statusMap()
      }
      provisionModel(modelFile)
      if (modelFile.length() != manifest.modelSizeBytes || sha256(modelFile) != manifest.modelSha256) {
        modelFile.delete()
        updateStatus("error", "The downloaded model failed its integrity check and was removed.")
        return statusMap()
      }
    }

    updateStatus("starting", "Loading the verified model into llama.cpp…")
    nativeLoadModel(modelFile.absolutePath, threadCount(), manifest.contextSize)
    loaded = true
    updateStatus("ready", "Local model ready · prompts stay on this device.")
    return statusMap()
  }

  private fun provisionModel(modelFile: File) {
    val partial = File(modelFile.parentFile, "${modelFile.name}.part")
    downloadedBytes = if (partial.exists()) partial.length() else 0L
    updateStatus("downloading", "Downloading the approved local model…")

    val connection = URL(manifest.modelUrl).openConnection() as HttpURLConnection
    connection.instanceFollowRedirects = true
    connection.connectTimeout = 30_000
    connection.readTimeout = 60_000
    if (downloadedBytes > 0) connection.setRequestProperty("Range", "bytes=$downloadedBytes-")
    connection.connect()

    val append = downloadedBytes > 0 && connection.responseCode == HttpURLConnection.HTTP_PARTIAL
    if (!append) downloadedBytes = 0L
    connection.inputStream.use { input ->
      FileOutputStream(partial, append).use { output ->
        val buffer = ByteArray(1024 * 1024)
        var lastEventBytes = downloadedBytes
        while (true) {
          val count = input.read(buffer)
          if (count < 0) break
          output.write(buffer, 0, count)
          downloadedBytes += count
          if (downloadedBytes - lastEventBytes >= 8L * 1024 * 1024) {
            lastEventBytes = downloadedBytes
            emitStatus()
          }
        }
        output.fd.sync()
      }
    }
    connection.disconnect()
    if (!partial.renameTo(modelFile)) {
      partial.copyTo(modelFile, overwrite = true)
      partial.delete()
    }
  }

  private fun loadManifest(): ModelManifest {
    val context = requireNotNull(appContext.reactContext)
    val file = File(context.filesDir, "lana-model-manifest.json")
    if (!file.exists()) {
      context.assets.open("lana-model-manifest.json").use { input ->
        FileOutputStream(file).use { output -> input.copyTo(output) }
      }
    }
    val json = JSONObject(file.readText())
    return ModelManifest(
      runtimeVersion = json.getString("runtimeVersion"),
      model = json.getString("model"),
      modelUrl = json.getString("modelUrl"),
      modelSizeBytes = json.getLong("modelSizeBytes"),
      modelSha256 = json.getString("modelSha256"),
      minimumFreeDiskBytes = json.getLong("minimumFreeDiskBytes"),
      requiredMemoryBytes = json.getLong("requiredMemoryBytes"),
      minimumAndroidApi = json.getInt("minimumAndroidApi"),
      contextSize = json.getInt("contextSize"),
      maximumOutputTokens = json.getInt("maximumOutputTokens")
    )
  }

  private fun unsupportedReason(): String? {
    if (Build.VERSION.SDK_INT < manifest.minimumAndroidApi) {
      return "Android ${manifest.minimumAndroidApi} or newer is required."
    }
    if (!Build.SUPPORTED_ABIS.contains("arm64-v8a")) {
      return "This build requires a 64-bit ARM Android device."
    }
    return null
  }

  private fun availableMemoryBytes(): Long {
    val context = requireNotNull(appContext.reactContext)
    val manager = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
    return ActivityManager.MemoryInfo().also(manager::getMemoryInfo).availMem
  }

  private fun threadCount() = min(8, max(2, Runtime.getRuntime().availableProcessors() - 1))

  private fun formatPrompt(messages: List<Map<String, Any?>>): String {
    val builder = StringBuilder("<|begin_of_text|>")
    messages.forEach { item ->
      val role = item["role"] as? String ?: "user"
      val content = item["content"] as? String ?: ""
      builder.append("<|start_header_id|>")
        .append(role)
        .append("<|end_header_id|>\n\n")
        .append(content)
        .append("<|eot_id|>")
    }
    return builder.append("<|start_header_id|>assistant<|end_header_id|>\n\n").toString()
  }

  private fun sha256(file: File): String {
    val digest = MessageDigest.getInstance("SHA-256")
    FileInputStream(file).use { input ->
      val buffer = ByteArray(1024 * 1024)
      while (true) {
        val count = input.read(buffer)
        if (count < 0) break
        digest.update(buffer, 0, count)
      }
    }
    return digest.digest().joinToString("") { "%02x".format(it) }
  }

  private fun updateStatus(nextState: String, nextMessage: String) {
    state = nextState
    message = nextMessage
    emitStatus()
  }

  private fun emitStatus() {
    sendEvent("onRuntimeStatus", statusMap())
  }

  private fun statusMap(): Map<String, Any?> = mapOf(
    "state" to state,
    "message" to message,
    "model" to manifest.model,
    "modelSizeBytes" to manifest.modelSizeBytes,
    "modelDownloadedBytes" to downloadedBytes,
    "availableMemoryBytes" to availableMemoryBytes(),
    "requiredMemoryBytes" to manifest.requiredMemoryBytes,
    "threads" to threadCount(),
    "acceleration" to "cpu"
  )

  private fun formatBytes(bytes: Long) = String.format("%.1f GB", bytes / 1_000_000_000.0)

  private external fun nativeLoadModel(modelPath: String, threads: Int, contextSize: Int)
  private external fun nativeComplete(prompt: String, maxTokens: Int, threads: Int, contextSize: Int, requestId: String): String
  private external fun nativeCancel(requestId: String)
  private external fun nativeTakeCancellation(requestId: String): Boolean
  private external fun nativeRelease()
}

private data class ModelManifest(
  val runtimeVersion: String,
  val model: String,
  val modelUrl: String,
  val modelSizeBytes: Long,
  val modelSha256: String,
  val minimumFreeDiskBytes: Long,
  val requiredMemoryBytes: Long,
  val minimumAndroidApi: Int,
  val contextSize: Int,
  val maximumOutputTokens: Int
)
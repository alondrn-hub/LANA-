import { createServer } from 'node:http';

const port = Number(process.env.OLLAMA_FIXTURE_PORT ?? 11434);
const model = process.env.OLLAMA_FIXTURE_MODEL ?? 'qwen2.5-coder';

function corsHeaders(request) {
  const origin = request.headers.origin;
  return {
    'Access-Control-Allow-Origin': origin ?? '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
    Vary: 'Origin',
  };
}

const fixture = createServer(async (request, response) => {
  if (request.method === 'OPTIONS') {
    response.writeHead(204, corsHeaders(request)).end();
    return;
  }

  if (request.method === 'GET' && request.url === '/api/tags') {
    response.writeHead(200, { ...corsHeaders(request), 'Content-Type': 'application/json' });
    response.end(JSON.stringify({ models: [{ name: model }] }));
    return;
  }

  if (request.method === 'POST' && request.url === '/api/chat') {
    let body = '';
    for await (const chunk of request) body += chunk;
    const payload = JSON.parse(body);
    const systemPrompt = payload.messages?.find((message) => message.role === 'system')?.content ?? '';
    const label = systemPrompt.match(/^You are ([^,]+)/)?.[1] ?? 'Local agent';
    response.writeHead(200, { ...corsHeaders(request), 'Content-Type': 'application/json' });
    response.end(JSON.stringify({
      model: payload.model ?? model,
      message: {
        role: 'assistant',
        content: `Fixture response from ${label}: the local model received the workspace context.`,
      },
      done: true,
    }));
    return;
  }

  response.writeHead(404).end();
});

fixture.listen(port, '127.0.0.1', () => {
  console.log(`Ollama-compatible fixture listening on http://127.0.0.1:${port}`);
});
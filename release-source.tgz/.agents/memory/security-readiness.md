---
name: Security review readiness
description: Release readiness treats unknown credential state as unresolved, and review evidence never contains credential contents.
---

Security and publish readiness must fail closed while provider connection status is loading, unavailable, or errored. A release can be prepared only after request, credential, save, and preview checks have a known acceptable state.

**Why:** Treating a loading credential query as safe creates a race where a later connection error is discovered only after the release path has already been opened.

**How to apply:** New security signals should distinguish `ready`, `attention`, and `checking`; only `ready` can unblock a dependent publish action. Evidence shown in a review may name safe metadata such as files, providers, and signal types, but never values that could be credentials.
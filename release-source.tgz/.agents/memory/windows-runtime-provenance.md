---
name: Windows runtime provenance
description: Why Windows local-runtime releases use separate upstream approval and signed-bundle integrity records.
---

Approve the upstream llama.cpp executable and model hashes before code signing, then seal the signed executable's final hash into the installed bundle manifest.

**Why:** Authenticode changes the executable bytes, so one hash cannot simultaneously prove the reviewed upstream input and validate the signed installed output. Keeping both stages prevents arbitrary pipeline input while preserving launch-time tamper detection.

**How to apply:** On clean Windows release workers, verify unsigned inputs against the reviewed approval, sign the runtime, seal its new hash, and only then package, sign, verify, and checksum the installer.
---
name: Local model offline handling
description: Keep the optional Ollama health check quiet and explicit when no local daemon is available.
---

The local model is optional. When Ollama is unavailable, its health check must return a recognizable offline result to the client rather than failing the page-level request.

**Why:** A local daemon commonly is not running in browser-preview environments. Treating that as an HTTP failure creates misleading browser errors even though the rest of the IDE is usable.

**How to apply:** Preserve the explicit offline response for model discovery and show the local model as unavailable in the UI. Do not silently route a failed local request to a cloud provider; actual user-initiated chat requests should still explain the local connection failure.
---
name: Browser runtime compatibility
description: Browser-local inference must degrade from WebGPU to WASM, while Node strip-only imports need simple TypeScript syntax.
---

Prefer WebGPU for browser inference but keep a WASM path for browsers or hosted preview environments where WebGPU context creation fails. Avoid TypeScript parameter properties in shared modules imported by Node's strip-only test runner.

**Why:** Replit preview Chromium can expose `navigator.gpu` while still failing to create a WebGPU context, and Node's built-in TypeScript runner rejects parameter properties before tests execute.

**How to apply:** Treat capability detection and engine initialization as separate steps, retry WASM after WebGPU initialization errors, and use explicit class property assignments in shared runtime code.
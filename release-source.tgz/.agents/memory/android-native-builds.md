---
name: Android native builds on Replit
description: Non-obvious Java and Gradle constraints for Expo/NDK builds in the Nix workspace.
---

Use standard OpenJDK 17 for Android Gradle Plugin builds, and keep Gradle
concurrency bounded when compiling Expo plus NDK code.

**Why:** Graal/OpenJDK 19 failed AGP's `jlink` transform. Repeated timed build
clients also left Gradle daemons resident until concurrent native and Metro
work exhausted builder memory and killed the active daemon.

**How to apply:** Keep the standard JDK 17 package in the Replit environment.
For large native release assemblies, restrict ABIs to the supported target,
avoid reusable daemons, cap workers, and run Kotlin compilation in-process.
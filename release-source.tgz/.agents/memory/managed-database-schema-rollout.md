---
name: Managed database schema rollout
description: How this project's Replit-managed PostgreSQL schema reaches development and production safely.
---

Keep database schema changes declarative in the Drizzle schema and apply them through the managed development and Publish flows; do not add custom startup DDL or production migration scripts.

**Why:** Replit's Publish process compares development and production schemas, lets the publisher resolve renames, and applies the resulting schema change. Custom migration code would compete with that managed path.

**How to apply:** After adding a table or column, ensure the development schema is applied for testing. At release time, use Publish to carry the schema change to production and handle any rename prompt there.
---
name: Safe JSON resource migrations
description: Avoid destructive schema-push warnings when introducing a required JSON resource bundle to existing projects.
---

When adding a required JSON field to a populated project table, define both a database-level SQL default and an application-level default. A TypeScript/ORM-only default is not enough for an existing-row schema migration.

**Why:** The schema push tooling treats a new non-null column without a SQL default as a potentially destructive change for existing records, even if the application would provide a value for future writes.

**How to apply:** For future persisted JSON bundles, use a SQL JSON default for the database migration and retain an application default for new insert values; normalize legacy stored documents before validating them.
---
name: Playwright runtime on Replit
description: Requirements for running the project's Chromium browser tests in the Replit Nix environment.
---

Browser tests need the Playwright Chromium binary alongside the native GUI libraries declared in the Replit environment.

**Why:** The browser package deliberately does not bundle a browser binary, and a minimal Nix runtime can fail Chromium startup on missing shared libraries even after Chromium is downloaded.

**How to apply:** Keep the required native runtime libraries declared with the project, and make the browser test command provision Chromium before running the suite so a clean checkout does not rely on a prior browser cache.
---
name: Browser model lifecycle concurrency
description: Rules for keeping browser-local model progress and cache-control state truthful during overlapping async operations.
---

Browser-local model progress must support multiple subscribers, and every async detection result must be invalidated when a newer retry or cache mutation starts. Serialize cache clearing with active inference and initialization.

**Why:** A single-owner progress callback can be silently replaced by diagnostics, while a late startup result can overwrite an active clear/rebuild with stale “ready” cache state.

**How to apply:** Broadcast lifecycle events, generation-guard async UI commits, prevent cache mutation during setup, and test clear/rebuild progress with concurrent subscribers.